async function checkApiPools() {
  const response = await fetch('http://localhost:3000/api/pools');
  const pools = await response.json();
  const pool1 = pools.find((p: any) => p.id === 1);
  console.log("Pool 1 from API:", JSON.stringify(pool1, null, 2));
}
checkApiPools();
