
import Database from 'better-sqlite3';
const db = new Database('lp_analytics.db');

console.log("--- SNAPSHOTS WITH NON-ZERO FEES ---");
const nonZero = db.prepare("SELECT * FROM snapshots WHERE total_fees > 0 LIMIT 10").all();
console.table(nonZero);

console.log("\n--- ALL SNAPSHOTS (First 20) ---");
const all = db.prepare("SELECT * FROM snapshots LIMIT 20").all();
console.table(all);
