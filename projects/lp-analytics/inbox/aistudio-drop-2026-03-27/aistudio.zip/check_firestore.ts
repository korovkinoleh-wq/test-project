import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import firebaseConfig from './firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function checkFirestorePools() {
  const querySnapshot = await getDocs(collection(db, 'pools'));
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    console.log(`Pool: ${data.name}, Delta_1: ${data.delta_1}, Delta_3: ${data.delta_3}, Delta_7: ${data.delta_7}`);
  });
}

checkFirestorePools();
