import express, { Request, Response, NextFunction } from "express";
console.log("[SERVER] server.ts is being loaded at " + new Date().toISOString());
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import crypto from "crypto";
import admin from "firebase-admin";
import { getFirestore as getFirestoreAdmin } from "firebase-admin/firestore";
import { Firestore } from "@google-cloud/firestore";
import { initializeApp as initializeClientApp } from "firebase/app";
import { getFirestore as getClientFirestore, collection as clientCollection, doc as clientDoc, setDoc as clientSetDoc, updateDoc as clientUpdateDoc, getDocs as clientGetDocs, query as clientQuery, where as clientWhere, serverTimestamp as clientServerTimestamp } from "firebase/firestore";

// CRITICAL: Force project ID in environment at the very top
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let firebaseConfig: any = {};
try {
  const configPath = path.join(__dirname, "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    if (firebaseConfig.projectId) {
      process.env.GOOGLE_CLOUD_PROJECT = firebaseConfig.projectId;
      process.env.GCLOUD_PROJECT = firebaseConfig.projectId;
      process.env.DATASTORE_PROJECT_ID = firebaseConfig.projectId;
    }
  }
} catch (e) {}

// Initialize Firebase Admin
if (admin.apps.length) {
  console.log(`[FIREBASE] Cleaning up ${admin.apps.length} existing apps...`);
  admin.apps.forEach(app => {
    try { app?.delete(); } catch(e) {}
  });
}

const forcedProjectId = firebaseConfig.projectId || process.env.GOOGLE_CLOUD_PROJECT;
console.log(`[FIREBASE] Initializing with Project ID: ${forcedProjectId}`);

let appAdmin: admin.app.App | undefined;
try {
  // In AI Studio, we should prioritize explicit config if available
  if (forcedProjectId) {
    appAdmin = admin.initializeApp({
      projectId: forcedProjectId
    }, "admin-app-" + Date.now());
    console.log(`[FIREBASE] Initialized with explicit Project ID: ${forcedProjectId}`);
  } else {
    appAdmin = admin.initializeApp();
    console.log("[FIREBASE] Initialized with default environment credentials.");
  }
} catch (e) {
  console.error("[FIREBASE FATAL] Init failed:", e);
}

const authAdmin = appAdmin ? appAdmin.auth() : admin.auth();
let dbAdmin: any;
let clientDb: any;

// Initialize Client SDK as fallback
try {
  const clientApp = initializeClientApp({
    apiKey: firebaseConfig.apiKey,
    authDomain: firebaseConfig.authDomain,
    projectId: firebaseConfig.projectId,
    appId: firebaseConfig.appId
  }, "client-app-" + Date.now());
  clientDb = getClientFirestore(clientApp, firebaseConfig.firestoreDatabaseId);
  console.log("[FIREBASE] Client SDK initialized for fallback.");
} catch (e) {
  console.error("[FIREBASE] Client SDK init failed:", e);
}

try {
  const dbId = firebaseConfig.firestoreDatabaseId;
  // In AI Studio, we MUST use the named database if provided
  if (appAdmin) {
    if (dbId && dbId !== '(default)') {
      dbAdmin = getFirestoreAdmin(appAdmin, dbId);
      console.log(`[FIREBASE] Using named Firestore database: ${dbId}`);
    } else {
      dbAdmin = getFirestoreAdmin(appAdmin);
      console.log(`[FIREBASE] Using default Firestore database`);
    }
  } else {
    dbAdmin = getFirestoreAdmin();
  }
} catch (err) {
  console.error("[FIREBASE FATAL] Firestore Init failed:", err);
  // Fallback to direct client SDK from @google-cloud/firestore
  try {
    dbAdmin = new Firestore({
      projectId: forcedProjectId,
      databaseId: firebaseConfig.firestoreDatabaseId || '(default)',
      ignoreUndefinedProperties: true
    });
    console.log("[FIREBASE] Using direct @google-cloud/firestore Client.");
  } catch (e2) {
    console.error("[FIREBASE] Direct Firestore Client fallback failed:", e2);
  }
}

// Helper to get a stable ID for a pool to prevent duplicates in Firestore
function getPoolDocId(p: { name: string, network: string, pair: string }): string {
  const slug = `${p.network}-${p.pair}-${p.name}`.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
  return slug;
}

// Helper to get the working firestore instance
async function getWorkingFirestore() {
  // Try Admin SDK first
  if (dbAdmin) {
    try {
      const healthRef = dbAdmin.collection('_health').doc('check');
      await healthRef.set({ 
        last_check: new Date().toISOString(), 
        source: 'server_health_check',
        projectId: forcedProjectId,
        databaseId: firebaseConfig.firestoreDatabaseId || '(default)'
      }, { merge: true });
      return dbAdmin;
    } catch (e: any) {
      console.warn(`[FIREBASE] Admin SDK health check failed: ${e.message}. Trying Client SDK fallback...`);
    }
  }

  // Fallback to Client SDK
  if (clientDb) {
    try {
      const healthRef = clientDoc(clientDb, '_health', 'check');
      await clientSetDoc(healthRef, { 
        last_check: new Date().toISOString(), 
        source: 'client_fallback_check',
        projectId: forcedProjectId,
        databaseId: firebaseConfig.firestoreDatabaseId || '(default)'
      }, { merge: true });
      console.log("[FIREBASE] Using Client SDK for Firestore operations.");
      
      // Return a wrapper that mimics the Admin SDK collection() API for basic operations
      return {
        collection: (path: string) => ({
          doc: (id?: string) => {
            const docRef = id ? clientDoc(clientDb, path, id) : clientDoc(clientCollection(clientDb, path));
            return {
              set: (data: any, options?: any) => clientSetDoc(docRef, data, options),
              update: (data: any) => clientUpdateDoc(docRef, data),
              collection: (subPath: string) => ({
                doc: (subId: string) => {
                  const subDocRef = clientDoc(clientDb, path, id!, subPath, subId);
                  return {
                    set: (subData: any, subOptions?: any) => clientSetDoc(subDocRef, subData, subOptions)
                  };
                }
              })
            };
          },
          get: async () => {
             const snap = await clientGetDocs(clientCollection(clientDb, path));
             return {
               empty: snap.empty,
               docs: snap.docs.map(d => ({
                 id: d.id,
                 ref: d.ref,
                 data: () => d.data(),
                 collection: (subPath: string) => ({
                   get: () => clientGetDocs(clientCollection(clientDb, path, d.id, subPath))
                 })
               }))
             };
          }
        }),
        batch: () => {
          // Minimal batch implementation if needed, or just return null to trigger non-batch path
          return null;
        }
      };
    } catch (e) {
      console.error("[FIREBASE] Client SDK fallback also failed:", (e as Error).message);
    }
  }

  return null;
}


  





    



    

    


const JWT_SECRET = process.env.JWT_SECRET || "lp-analytics-secret-key-2026";
const ADMIN_EMAIL = "olegglasstrader@gmail.com";

const UNISWAP_V3_SUBGRAPHS: Record<string, string> = {
  'Ethereum': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3',
  'Arbitrum': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-arbitrum',
  'Base': 'https://api.studio.thegraph.com/proxy/68032/uniswap-v3-base/v0.0.1',
  'Polygon': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-polygon',
  'Optimism': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-optimism',
  'BNB': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-binance',
  'Avalanche': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-avalanche',
  'Celo': 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3-celo',
};

const AERODROME_SUBGRAPHS: Record<string, string> = {
  'Base': 'https://api.studio.thegraph.com/proxy/55375/aerodrome-slipstream/v0.0.1'
};

async function fetchWalletPositions(walletAddress: string, network: string): Promise<any[]> {
  const uniswapUrl = UNISWAP_V3_SUBGRAPHS[network];
  const aerodromeUrl = AERODROME_SUBGRAPHS[network];
  
  const query = `
    {
      positions(where: { owner: "${walletAddress.toLowerCase()}" }) {
        id
        pool {
          id
          token0 { symbol }
          token1 { symbol }
        }
        liquidity
        tickLower
        tickUpper
        depositedToken0
        depositedToken1
        collectedFeesToken0
        collectedFeesToken1
      }
    }
  `;

  const fetchFromSubgraph = async (url: string, source: string) => {
    try {
      console.log(`[SYNC] Fetching ${network} positions from ${source} for ${walletAddress}...`);
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
        signal: AbortSignal.timeout(10000)
      });
      
      const text = await res.text();
      if (!res.ok) {
        console.error(`[SYNC] ${source} error for ${network} (${res.status}):`, text.slice(0, 200));
        return [];
      }
      
      const { data } = JSON.parse(text);
      return data?.positions || [];
    } catch (err) {
      console.error(`[SYNC] ${source} network error for ${network}:`, err);
      return [];
    }
  };

  const results = await Promise.all([
    uniswapUrl ? fetchFromSubgraph(uniswapUrl, 'Uniswap') : Promise.resolve([]),
    aerodromeUrl ? fetchFromSubgraph(aerodromeUrl, 'Aerodrome') : Promise.resolve([])
  ]);

  return results.flat();
}

// Check for required environment variables
const requiredEnv = ['VITE_GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'];
requiredEnv.forEach(env => {
  if (!process.env[env]) {
    console.warn(`[WARNING] Missing environment variable: ${env}. Google Auth may not work.`);
  }
});

let db: Database.Database;
try {
  console.log("[DATABASE] Opening database...");
  db = new Database("lp_analytics.db");
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');
  console.log("[DATABASE] Database opened successfully.");
} catch (err) {
  console.error("[DATABASE FATAL] Failed to open database:", err);
  process.exit(1);
}

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS pools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE COLLATE NOCASE,
    network TEXT NOT NULL,
    pair TEXT NOT NULL,
    fee_percent REAL NOT NULL,
    min_range REAL NOT NULL,
    max_range REAL NOT NULL,
    start_liquidity_usd REAL NOT NULL,
    start_price REAL DEFAULT 0,
    start_date TEXT NOT NULL,
    latest_total_fees REAL DEFAULT 0,
    latest_snapshot_datetime TEXT,
    delta_1 REAL DEFAULT 0,
    delta_3 REAL DEFAULT 0,
    delta_7 REAL DEFAULT 0,
    stable_id TEXT UNIQUE
  );
`);

// Migration for existing pools table
try { db.prepare("ALTER TABLE pools ADD COLUMN start_price REAL DEFAULT 0").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN latest_total_fees REAL DEFAULT 0").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN stable_id TEXT").run(); } catch (e) {}
try { db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS idx_pools_stable_id ON pools(stable_id)").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN latest_snapshot_datetime TEXT").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN delta_1 REAL DEFAULT 0").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN delta_3 REAL DEFAULT 0").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN delta_7 REAL DEFAULT 0").run(); } catch (e) {}
try { db.prepare("ALTER TABLE pools ADD COLUMN snapshots_count INTEGER DEFAULT 0").run(); } catch (e) {}

// Populate stable_id for existing pools if missing
try {
  const poolsWithoutStableId = db.prepare("SELECT * FROM pools WHERE stable_id IS NULL OR stable_id = ''").all() as any[];
  if (poolsWithoutStableId.length > 0) {
    console.log(`[DATABASE] Migrating ${poolsWithoutStableId.length} pools to have stable_id...`);
    const updateStableId = db.prepare("UPDATE pools SET stable_id = ? WHERE id = ?");
    for (const p of poolsWithoutStableId) {
      const stableId = getPoolDocId(p);
      updateStableId.run(stableId, p.id);
    }
  }
} catch (e) {
  console.error("[DATABASE ERROR] Failed to migrate stable_id:", e);
}

db.exec(`
  CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pool_id INTEGER NOT NULL,
    snapshot_datetime TEXT NOT NULL,
    total_fees REAL NOT NULL,
    FOREIGN KEY (pool_id) REFERENCES pools (id) ON DELETE CASCADE,
    UNIQUE(pool_id, snapshot_datetime)
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT,
    picture TEXT,
    role TEXT DEFAULT 'approved',
    subscription_type TEXT DEFAULT 'free_test', -- 'none', 'monthly', 'yearly'
    wallet_address TEXT,
    subscription_expiry DATETIME,
    last_payment_at DATETIME,
    has_accepted_disclaimer INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT NOT NULL,
    network TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'failed'
    subscription_type TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT, -- Optional, can be null for guests
    user_email TEXT,
    topic TEXT NOT NULL,
    message TEXT NOT NULL,
    attachment_name TEXT,
    attachment_data TEXT, -- Base64 encoded
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS suggestion_replies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    suggestion_id INTEGER NOT NULL,
    admin_id TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (suggestion_id) REFERENCES suggestions (id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS historical_prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    open_time INTEGER NOT NULL,
    open REAL NOT NULL,
    high REAL NOT NULL,
    low REAL NOT NULL,
    close REAL NOT NULL,
    volume REAL NOT NULL,
    UNIQUE(symbol, open_time)
  );
`);

// Migration: start_price handled at startup

// Migration: Add has_accepted_disclaimer to users if it doesn't exist
try {
  const userInfo = db.prepare("PRAGMA table_info(users)").all() as any[];
  const hasAcceptedDisclaimer = userInfo.some(col => col.name === 'has_accepted_disclaimer');
  if (!hasAcceptedDisclaimer) {
    db.exec("ALTER TABLE users ADD COLUMN has_accepted_disclaimer INTEGER DEFAULT 0");
    console.log("[DATABASE] Added has_accepted_disclaimer column to users table");
  }
} catch (err) {
  console.error("[DATABASE ERROR] Users has_accepted_disclaimer migration failed:", err);
}

// Migration: Add wallet_address to users if it doesn't exist
try {
  const userInfo = db.prepare("PRAGMA table_info(users)").all() as any[];
  const hasWallet = userInfo.some(col => col.name === 'wallet_address');
  if (!hasWallet) {
    db.exec("ALTER TABLE users ADD COLUMN wallet_address TEXT");
    console.log("[DATABASE] Added wallet_address column to users table");
  }
  
  // Set specific wallet for admin if provided
  const admin = db.prepare("SELECT * FROM users WHERE email = ?").get(ADMIN_EMAIL) as any;
  if (admin) {
    if (!admin.wallet_address) {
      db.prepare("UPDATE users SET wallet_address = ? WHERE id = ?")
        .run('0x82314b43c82db46dded1ac180712c23b3375a682', admin.id);
      console.log(`[DATABASE] Set wallet address for admin: ${ADMIN_EMAIL}`);
    } else {
      console.log(`[DATABASE] Admin wallet already set: ${admin.wallet_address}`);
    }
  }
} catch (err) {
  console.error("[DATABASE ERROR] Users migration failed:", err);
}

// Migration for free test phase: set all pending users to approved
try {
  db.prepare("UPDATE users SET role = 'approved' WHERE role IN ('pending', 'pending_payment')").run();
} catch (e) {}

// Migration: Add user_email to suggestions if it doesn't exist
try {
  const suggestionInfo = db.prepare("PRAGMA table_info(suggestions)").all() as any[];
  const hasUserEmail = suggestionInfo.some(col => col.name === 'user_email');
  if (!hasUserEmail) {
    db.exec("ALTER TABLE suggestions ADD COLUMN user_email TEXT");
    console.log("[DATABASE] Added user_email column to suggestions table");
  }
  
  const hasAttachmentName = suggestionInfo.some(col => col.name === 'attachment_name');
  if (!hasAttachmentName) {
    db.exec("ALTER TABLE suggestions ADD COLUMN attachment_name TEXT");
    console.log("[DATABASE] Added attachment_name column to suggestions table");
  }

  const hasAttachmentData = suggestionInfo.some(col => col.name === 'attachment_data');
  if (!hasAttachmentData) {
    db.exec("ALTER TABLE suggestions ADD COLUMN attachment_data TEXT");
    console.log("[DATABASE] Added attachment_data column to suggestions table");
  }
} catch (err) {
  console.error("[DATABASE ERROR] Suggestions migration failed:", err);
}

async function syncPoolToFirestore(poolId: number | string) {
  try {
    const activeDb = await getWorkingFirestore();
    if (!activeDb) return;
    
    const pool = db.prepare("SELECT * FROM pools WHERE id = ? OR stable_id = ?").get(poolId, poolId) as any;
    if (pool) {
      const stableId = pool.stable_id || getPoolDocId(pool);
      await activeDb.collection('pools').doc(stableId).set({
        id: stableId,
        name: pool.name,
        network: pool.network,
        pair: pool.pair,
        fee_percent: pool.fee_percent,
        min_range: pool.min_range,
        max_range: pool.max_range,
        start_liquidity_usd: pool.start_liquidity_usd,
        start_price: pool.start_price,
        start_date: pool.start_date,
        latest_total_fees: pool.latest_total_fees || 0,
        latest_snapshot_datetime: pool.latest_snapshot_datetime || pool.start_date
      }, { merge: true });
      
      // If stable_id was not set in SQLite, update it now
      if (!pool.stable_id) {
        db.prepare("UPDATE pools SET stable_id = ? WHERE id = ?").run(stableId, pool.id);
      }
    }
  } catch (e) {
    console.error(`[FIRESTORE SYNC] Failed for pool ${poolId}:`, e);
  }
}

// Helper to calculate deltas for a pool based on its snapshots
function calculatePoolDeltas(snapshots: any[]) {
  if (!snapshots || snapshots.length < 2) {
    return { delta_1: 0, delta_3: 0, delta_7: 0 };
  }

  // snapshots is ordered DESC (index 0 is newest)
  const latest = snapshots[0];
  const latestTime = new Date(latest.snapshot_datetime).getTime();
  const latestFees = typeof latest.total_fees === 'number' ? latest.total_fees : parseFloat(String(latest.total_fees).replace(/\s/g, '').replace(',', '.'));

  const getDeltaForDays = (days: number) => {
    const targetTime = latestTime - (days * 24 * 60 * 60 * 1000);
    
    // Find the snapshot closest to targetTime
    // We want a snapshot that is at least some distance away from the latest to be meaningful
    let bestMatch = snapshots[1]; 
    let minDiff = Infinity;
    
    for (let i = 1; i < snapshots.length; i++) {
      const snapTime = new Date(snapshots[i].snapshot_datetime).getTime();
      const diff = Math.abs(snapTime - targetTime);
      
      // If we have many snapshots, try to avoid ones that are too close to the latest
      // (e.g. if user just added 5 snapshots in 5 minutes)
      const age = latestTime - snapTime;
      const minAge = (days * 24 * 60 * 60 * 1000) * 0.1; // At least 10% of the period away
      
      if (diff < minDiff && (age >= minAge || i === snapshots.length - 1)) {
        minDiff = diff;
        bestMatch = snapshots[i];
      }
    }

    if (!bestMatch) return 0;

    // If we have at least 2 snapshots, but the time gap is very small (e.g. just added)
    // we should still show the delta between them if the fees changed.
    const timeGap = Math.abs(latestTime - new Date(bestMatch.snapshot_datetime).getTime());
    
    // If we have more than 2 snapshots and the closest one is too recent (< 1h), 
    // try to find one that is actually older to get a more meaningful daily delta.
    if (timeGap < (60 * 60 * 1000) && snapshots.length > 2) {
      // Find the first snapshot that is at least 1h old
      for (let i = 1; i < snapshots.length; i++) {
        const gap = Math.abs(latestTime - new Date(snapshots[i].snapshot_datetime).getTime());
        if (gap >= (60 * 60 * 1000)) {
          bestMatch = snapshots[i];
          break;
        }
      }
    }

    const prevFees = typeof bestMatch.total_fees === 'number' ? bestMatch.total_fees : parseFloat(String(bestMatch.total_fees).replace(/\s/g, '').replace(',', '.'));
    
    if (isNaN(prevFees) || isNaN(latestFees)) return 0;
    if (prevFees === 0) return 0; // Fix: return 0 if previous is 0 (seed)
    
    const d = ((latestFees - prevFees) / prevFees) * 100;
    const res = isFinite(d) ? d : 0;
    
    console.log(`[DELTA DEBUG] ${days}D for pool: latest=${latestFees.toFixed(4)} (${new Date(latestTime).toLocaleTimeString()}), prev=${prevFees.toFixed(4)} (${new Date(bestMatch.snapshot_datetime).toLocaleTimeString()}), gap=${(timeGap/3600000).toFixed(2)}h, res=${res.toFixed(4)}%`);
    return res;
  };

  return {
    delta_1: getDeltaForDays(1),
    delta_3: getDeltaForDays(3),
    delta_7: getDeltaForDays(7)
  };
}

// Recalculate all deltas for all pools and sync to Firestore
async function recalculateAllPoolDeltas() {
  console.log("[ADMIN] Starting full delta recalculation and sync...");
  try {
    const pools = db.prepare("SELECT * FROM pools").all() as any[];
    const activeDb = await getWorkingFirestore();
    if (!activeDb) return;

    for (const pool of pools) {
      const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(pool.id) as any[];
      if (snapshots.length === 0) continue;

      const latestSnapshot = snapshots[0];
      const deltas = calculatePoolDeltas(snapshots);
      const stableId = pool.stable_id || getPoolDocId(pool);

      console.log(`[ADMIN] Pool ${pool.id} (${pool.name}) - Snaps: ${snapshots.length}, D1: ${deltas.delta_1.toFixed(2)}%`);

      // Update local SQLite
      db.prepare(`
        UPDATE pools 
        SET delta_1 = ?, delta_3 = ?, delta_7 = ?, 
            latest_total_fees = ?, latest_snapshot_datetime = ?,
            snapshots_count = ?
        WHERE id = ?
      `).run(deltas.delta_1, deltas.delta_3, deltas.delta_7, latestSnapshot.total_fees, latestSnapshot.snapshot_datetime, snapshots.length, pool.id);

      // Sync to Firestore
      activeDb.collection('pools').doc(stableId).set({
        latest_total_fees: latestSnapshot.total_fees,
        latest_snapshot_datetime: latestSnapshot.snapshot_datetime,
        delta_1: deltas.delta_1,
        delta_3: deltas.delta_3,
        delta_7: deltas.delta_7,
        snapshots_count: snapshots.length,
        lastUpdate: new Date().toISOString() // Fix: use camelCase consistent with other syncs
      }, { merge: true }).catch(e => console.error(`[ADMIN] Failed to sync pool ${stableId} to Firestore:`, e.message));
    }
    console.log(`[ADMIN] Recalculation complete for ${pools.length} pools.`);
  } catch (error) {
    console.error("[ADMIN] Recalculation failed:", error);
  }
}

// Sync data from Firestore BACK to SQLite (Restore from Cloud)
async function syncFromFirestoreToSQLite() {
  console.log("[ADMIN] Starting sync from Firestore to SQLite...");
  try {
    const activeDb = await getWorkingFirestore();
    if (!activeDb) throw new Error("Firestore not initialized");

    const poolsSnapshot = await activeDb.collection('pools').get();
    console.log(`[ADMIN] Found ${poolsSnapshot.size} pools in Firestore.`);

    // Sync Users first
    try {
      const usersSnapshot = await activeDb.collection('users').get();
      console.log(`[ADMIN] Found ${usersSnapshot.size} users in Firestore.`);
      for (const userDoc of usersSnapshot.docs) {
        const u = userDoc.data();
        const userId = userDoc.id;
        const existing = db.prepare("SELECT id FROM users WHERE id = ?").get(userId);
        if (existing) {
          db.prepare(`
            UPDATE users SET 
              email = ?, name = ?, picture = ?, role = ?, 
              subscription_type = ?, wallet_address = ?, 
              subscription_expiry = ?, last_payment_at = ?
            WHERE id = ?
          `).run(
            u.email || '', u.name || '', u.picture || '', u.role || 'approved',
            u.subscription_type || 'free_test', u.wallet_address || null,
            u.subscription_expiry || null, u.last_payment_at || null,
            userId
          );
        } else {
          db.prepare(`
            INSERT INTO users (id, email, name, picture, role, subscription_type, wallet_address, subscription_expiry, last_payment_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            userId, u.email || '', u.name || '', u.picture || '', u.role || 'approved',
            u.subscription_type || 'free_test', u.wallet_address || null,
            u.subscription_expiry || null, u.last_payment_at || null
          );
        }
      }
    } catch (userErr) {
      console.error("[ADMIN] Failed to sync users from Firestore:", userErr);
    }

    const transaction = db.transaction(() => {
      // We don't clear everything, we just update/insert
      for (const poolDoc of poolsSnapshot.docs) {
        const p = poolDoc.data();
        const stableId = poolDoc.id;
        
        // Find or create pool in SQLite
        let pool = db.prepare("SELECT * FROM pools WHERE stable_id = ? OR name = ?").get(stableId, p.name) as any;
        let poolId: number;

        if (pool) {
          poolId = pool.id;
          db.prepare(`
            UPDATE pools SET 
              network = ?, pair = ?, fee_percent = ?, min_range = ?, max_range = ?, 
              start_liquidity_usd = ?, start_price = ?, start_date = ?,
              latest_total_fees = ?, latest_snapshot_datetime = ?, stable_id = ?
            WHERE id = ?
          `).run(
            p.network || pool.network, p.pair || pool.pair, p.fee_percent || pool.fee_percent,
            p.min_range || pool.min_range, p.max_range || pool.max_range,
            p.start_liquidity_usd || pool.start_liquidity_usd, p.start_price || pool.start_price,
            p.start_date || pool.start_date, p.latest_total_fees || pool.latest_total_fees,
            p.latest_snapshot_datetime || pool.latest_snapshot_datetime, stableId, poolId
          );
        } else {
          const runResult = db.prepare(`
            INSERT INTO pools (name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date, latest_total_fees, latest_snapshot_datetime, stable_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `).run(
            p.name, p.network, p.pair, p.fee_percent || 0, p.min_range || 0, p.max_range || 0,
            p.start_liquidity_usd || 0, p.start_price || 0, p.start_date || new Date().toISOString(),
            p.latest_total_fees || 0, p.latest_snapshot_datetime || new Date().toISOString(), stableId
          );
          poolId = runResult.lastInsertRowid as number;
        }

        // Fetch snapshots for this pool
        // Note: This might be slow if there are many snapshots, but it's an admin tool
        // We use a separate async call outside the transaction for snapshots to avoid blocking
      }
    });

    transaction();

    // Now fetch snapshots outside the transaction because we need async/await
    for (const poolDoc of poolsSnapshot.docs) {
      const stableId = poolDoc.id;
      const pool = db.prepare("SELECT id FROM pools WHERE stable_id = ?").get(stableId) as any;
      if (!pool) continue;

      const snapshotsSnapshot = await activeDb.collection('pools').doc(stableId).collection('snapshots').get();
      console.log(`[ADMIN] Pool ${stableId}: Found ${snapshotsSnapshot.size} snapshots in Firestore.`);

      for (const snapDoc of snapshotsSnapshot.docs) {
        const s = snapDoc.data();
        const datetime = s.snapshot_datetime || s.timestamp;
        const fees = s.total_fees || s.fees || 0;

        // Check if snapshot exists
        const existing = db.prepare("SELECT id FROM snapshots WHERE pool_id = ? AND snapshot_datetime = ?").get(pool.id, datetime);
        if (!existing) {
          db.prepare("INSERT INTO snapshots (pool_id, snapshot_datetime, total_fees) VALUES (?, ?, ?)").run(pool.id, datetime, fees);
        } else {
          db.prepare("UPDATE snapshots SET total_fees = ? WHERE id = ?").run(fees, (existing as any).id);
        }
      }
    }

    console.log("[ADMIN] Sync from Firestore complete. Recalculating deltas...");
    await recalculateAllPoolDeltas();
    return { success: true };
  } catch (error) {
    console.error("[ADMIN] Sync from Firestore failed:", error);
    throw error;
  }
}

async function syncSnapshotToFirestore(poolId: number | string, snapshot: any) {
  try {
    const activeDb = await getWorkingFirestore();
    if (!activeDb) return;
    
    // Resolve poolId to both stableId and numericId
    let stableId = String(poolId);
    let numericId = typeof poolId === 'number' ? poolId : NaN;

    // Try to find the pool in SQLite to get both IDs
    const pool = db.prepare("SELECT id, stable_id, name FROM pools WHERE id = ? OR stable_id = ?").get(poolId, poolId) as any;
    if (pool) {
      stableId = pool.stable_id || String(pool.id);
      numericId = pool.id;
      console.log(`[FIRESTORE SYNC] Found pool in SQLite: ${pool.name} (Numeric: ${numericId}, Stable: ${stableId})`);
    } else if (isNaN(Number(poolId))) {
      // If poolId is a string but not found in SQLite, it might be a new pool or a mismatch
      console.warn(`[FIRESTORE SYNC] Pool ${poolId} not found in SQLite. Using as stableId.`);
    }

    const snapRef = activeDb.collection('pools').doc(stableId).collection('snapshots');
    // Use a deterministic ID based on timestamp to prevent duplicates
    const deterministicId = snapshot.snapshot_datetime.replace(/[^0-9]/g, '');
    
    await snapRef.doc(deterministicId).set({
      pool_id: stableId,
      total_fees: snapshot.total_fees,
      snapshot_datetime: snapshot.snapshot_datetime
    });
    
    // Recalculate deltas for this pool to ensure Firestore is up to date
    let delta_1 = 0, delta_3 = 0, delta_7 = 0;
    let snapshotsCount = 0;

    if (!isNaN(numericId)) {
      const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(numericId) as any[];
      snapshotsCount = snapshots.length;
      
      if (snapshots.length >= 2) {
        const deltas = calculatePoolDeltas(snapshots);
        delta_1 = deltas.delta_1;
        delta_3 = deltas.delta_3;
        delta_7 = deltas.delta_7;
        console.log(`[FIRESTORE SYNC] Calculated deltas for pool ${numericId}: D1=${delta_1.toFixed(2)}%, Snaps=${snapshotsCount}`);
      }

      // Update the pools table in SQLite with the latest fees and deltas
      db.prepare(`
        UPDATE pools 
        SET latest_total_fees = ?, 
            latest_snapshot_datetime = ?,
            delta_1 = ?,
            delta_3 = ?,
            delta_7 = ?,
            snapshots_count = ?
        WHERE id = ?
      `).run(snapshot.total_fees, snapshot.snapshot_datetime, delta_1, delta_3, delta_7, snapshotsCount, numericId);
    }

    // Also update the pool document in Firestore with the latest fees and deltas
    await activeDb.collection('pools').doc(stableId).set({
      latest_total_fees: snapshot.total_fees,
      latest_snapshot_datetime: snapshot.snapshot_datetime,
      delta_1,
      delta_3,
      delta_7,
      snapshots_count: snapshotsCount,
      lastUpdate: new Date().toISOString()
    }, { merge: true });
    
    console.log(`[FIRESTORE SYNC] Updated pool ${stableId} (Numeric: ${numericId}) with new snapshot and deltas: D1=${delta_1.toFixed(2)}%, Snaps: ${snapshotsCount}`);
  } catch (e) {
    console.error(`[FIRESTORE SYNC] Failed for snapshot in pool ${poolId}:`, e);
  }
}

// Seed/Sync system pools
// Clear all pools and snapshots from Firestore
async function clearFirestorePools() {
  try {
    const activeDb = await getWorkingFirestore();
    if (!activeDb) return;
    console.log("[FIREBASE] Clearing Firestore pools and snapshots...");
    const poolsSnap = await activeDb.collection('pools').get();
    
    if (poolsSnap.empty) {
      console.log("[FIREBASE] No pools found in Firestore to clear.");
      return;
    }

    let batch = activeDb.batch();
    let count = 0;

    for (const poolDoc of poolsSnap.docs) {
      // 1. Delete all snapshots for this pool
      const snapshotsSnap = await poolDoc.ref.collection('snapshots').get();
      for (const d of snapshotsSnap.docs) {
        batch.delete(d.ref);
        count++;
        if (count >= 450) {
          await batch.commit();
          batch = activeDb.batch();
          count = 0;
        }
      }
      
      // 2. Delete the pool document itself
      batch.delete(poolDoc.ref);
      count++;
      if (count >= 450) {
        await batch.commit();
        batch = activeDb.batch();
        count = 0;
      }
    }
    
    if (count > 0) await batch.commit();
    console.log("[FIREBASE] Firestore pools and snapshots cleared.");
  } catch (e) {
    console.error("[FIREBASE] Firestore clear failed:", e);
  }
}

// Sync all pools and snapshots from SQLite to Firestore
async function syncAllPoolsToFirestore() {
  try {
    const activeDb = await getWorkingFirestore();
    if (!activeDb) {
      console.error("[FIREBASE] Cannot sync: No working Firestore instance.");
      return;
    }

    const pools = db.prepare("SELECT * FROM pools").all() as any[];
    console.log(`[FIREBASE] Syncing ${pools.length} pools to Firestore using working instance...`);
    
    for (const p of pools) {
      // Use STABLE ID to prevent duplicates
      const stableId = getPoolDocId(p);
      const poolRef = activeDb.collection('pools').doc(stableId);
      
      const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC").all(p.id) as any[];
      const latestSnapshot = snapshots[0];
      console.log(`[FIREBASE] Syncing pool ${p.name} (Stable ID: ${stableId}) with ${snapshots.length} snapshots.`);
      
      // Calculate deltas for Firestore
      const { delta_1, delta_3, delta_7 } = calculatePoolDeltas(snapshots);

      // 1. Set pool document with latest stats for immediate dashboard display
      const firestoreData = {
        id: stableId, // Store stable ID as the id field too
        sqlite_id: p.id, // Keep reference to SQLite ID if needed
        name: p.name,
        network: p.network,
        pair: p.pair,
        fee_percent: p.fee_percent,
        min_range: p.min_range,
        max_range: p.max_range,
        start_liquidity_usd: p.start_liquidity_usd,
        start_price: p.start_price,
        start_date: p.start_date,
        latest_total_fees: latestSnapshot ? latestSnapshot.total_fees : (p.latest_total_fees || 0),
        latest_snapshot_datetime: latestSnapshot ? latestSnapshot.snapshot_datetime : (p.latest_snapshot_datetime || null),
        delta_1,
        delta_3,
        delta_7,
        last_update: admin.firestore.FieldValue.serverTimestamp()
      };

      await poolRef.set(firestoreData, { merge: true });

      const snapRef = poolRef.collection('snapshots');
      
      // 2. Sync snapshots
      if (snapshots.length > 0) {
        let batch = activeDb.batch();
        let count = 0;
        
        for (const s of snapshots) {
          const deterministicId = s.snapshot_datetime.replace(/[^0-9]/g, '');
          batch.set(snapRef.doc(deterministicId), {
            pool_id: stableId, // Use stable ID
            total_fees: s.total_fees,
            snapshot_datetime: s.snapshot_datetime
          }, { merge: true });
          
          count++;
          if (count >= 450) {
            await batch.commit();
            batch = activeDb.batch();
            count = 0;
          }
        }
        if (count > 0) await batch.commit();
        
        // 3. Mark sync as complete
        await poolRef.update({
          _sync_complete: true,
          last_update: admin.firestore.FieldValue.serverTimestamp()
        });
      }
    }
    console.log("[FIREBASE] Full sync completed.");
  } catch (e) {
    console.error("[FIREBASE] Full sync failed:", e);
  }
}

async function syncSystemPools() {
  const seedPools = [
    // Ethereum Pools
    { name: "Aerodrome ETH/USDC", network: "Base", pair: "ETH/USDC", fee_percent: 0.034, min_range: 1004.311, max_range: 6515.6585, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    { name: "Uniswap ETH/USDC", network: "Base", pair: "ETH/USDC", fee_percent: 0.05, min_range: 1004.311, max_range: 6515.6585, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    { name: "Uniswap ETH/USDC (Arb)", network: "Arbitrum", pair: "ETH/USDC", fee_percent: 0.05, min_range: 1004.311, max_range: 6515.6585, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    { name: "Uniswap WETH/USDC (Monad)", network: "Monad", pair: "WETH/USDC", fee_percent: 0.05, min_range: 1004.311, max_range: 6515.6585, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    { name: "Uniswap WETH/USDC (Monad 0.3%)", network: "Monad", pair: "WETH/USDC", fee_percent: 0.3, min_range: 1000.3, max_range: 6502.64, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    { name: "Uniswap WETH/USDT (BNB)", network: "BNB", pair: "WETH/USDT", fee_percent: 0.3, min_range: 1004.91, max_range: 6513.04, start_liquidity_usd: 52.7, start_price: 2500, start_date: "2025-12-26T11:08:00Z", initial_fees: 0 },
    
    // Bitcoin Pools
    { name: "Aerodrome USDC/cbBTC", network: "Base", pair: "USDC/cbBTC", fee_percent: 0.033, min_range: 58140, max_range: 117647, start_liquidity_usd: 52.06, start_price: 95000, start_date: "2025-12-27T22:50:00Z", initial_fees: 0 },
    { name: "Uniswap WBTC/USDC", network: "Arbitrum", pair: "WBTC/USDC", fee_percent: 0.05, min_range: 57806.3, max_range: 117573, start_liquidity_usd: 52.1, start_price: 95000, start_date: "2025-12-27T22:50:00Z", initial_fees: 0 },
    { name: "Uniswap AUSD/WBTC", network: "Monad", pair: "AUSD/WBTC", fee_percent: 0.05, min_range: 57806.3, max_range: 117573, start_liquidity_usd: 52.06, start_price: 95000, start_date: "2025-12-27T22:50:00Z", initial_fees: 0 },
    { name: "Uniswap BTC.B/USDC", network: "Avalanche", pair: "BTC.B/USDC", fee_percent: 0.3, min_range: 57806.3, max_range: 117338, start_liquidity_usd: 52.01, start_price: 95000, start_date: "2025-12-27T22:50:00Z", initial_fees: 0 },
    { name: "LFJ BTC.B/USDC", network: "LFJ", pair: "BTC.B/USDC", fee_percent: 0.05, min_range: 57814, max_range: 117434, start_liquidity_usd: 51.54, start_price: 95000, start_date: "2025-12-27T22:50:00Z", initial_fees: 0 },
    
    // Avalanche Pools
    { name: "Uniswap AVAX/USDC", network: "Avalanche", pair: "AVAX/USDC", fee_percent: 1.0, min_range: 6.02136, max_range: 90.0331, start_liquidity_usd: 600.0, start_price: 35, start_date: "2026-02-24T22:00:00Z", initial_fees: 0.0 }
  ];

  // Cleanup old incorrect LFJ pool if it exists
  const oldPool = db.prepare("SELECT id FROM pools WHERE name = 'LFJ AVAX/USDC'").get() as any;
  if (oldPool) {
    db.prepare("DELETE FROM snapshots WHERE pool_id = ?").run(oldPool.id);
    db.prepare("DELETE FROM pools WHERE id = ?").run(oldPool.id);
    console.log("[DATABASE] Cleaned up old LFJ AVAX/USDC pool");
  }

  for (const p of seedPools) {
    let poolId: number | string;
    const stableId = getPoolDocId(p);
    
    const existing = db.prepare("SELECT id, min_range, max_range, start_liquidity_usd, start_price, latest_total_fees FROM pools WHERE stable_id = ? OR name = ?").get(stableId, p.name) as any;
    if (!existing) {
      const result = db.prepare(`
        INSERT INTO pools (name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date, stable_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(p.name, p.network, p.pair, p.fee_percent, p.min_range, p.max_range, p.start_liquidity_usd, p.start_price, p.start_date, stableId);
      
      poolId = result.lastInsertRowid as number;
      
      const initialFees = p.initial_fees || 0;
      db.prepare(`
        INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
        VALUES (?, ?, ?)
      `).run(poolId, initialFees, p.start_date);
      
      // Update the pool with the latest fees for Firestore sync later
      db.prepare("UPDATE pools SET latest_total_fees = ?, latest_snapshot_datetime = ? WHERE id = ?").run(initialFees, p.start_date, poolId);
      
      console.log(`[DATABASE] Seeded system pool: ${p.name} (stable_id: ${stableId})`);
    } else {
      poolId = existing.id;
      // Ensure stable_id is set even for existing pools
      db.prepare("UPDATE pools SET stable_id = ? WHERE id = ?").run(stableId, poolId);
      
      // Only update if parameters are significantly different (to avoid overwriting user edits)
      const shouldUpdate = 
        Math.abs(existing.min_range - p.min_range) > 0.001 || 
        Math.abs(existing.max_range - p.max_range) > 0.001 || 
        Math.abs(existing.start_liquidity_usd - p.start_liquidity_usd) > 0.001;

      if (shouldUpdate) {
        db.prepare(`
          UPDATE pools 
          SET min_range = ?, max_range = ?, start_liquidity_usd = ?, start_price = ?, start_date = ?
          WHERE id = ?
        `).run(p.min_range, p.max_range, p.start_liquidity_usd, p.start_price, p.start_date, poolId);
        console.log(`[DATABASE] Updated system pool parameters: ${p.name}`);
      }

      // We no longer aggressively update the initial snapshot to avoid resetting user data
      // Only update if it's strictly necessary or if the user hasn't added any snapshots yet
      // AND if we don't already have a valid latest_total_fees from restoration
      const snapshotCount = db.prepare("SELECT COUNT(*) as count FROM snapshots WHERE pool_id = ?").get(poolId) as any;
      if (snapshotCount.count === 0 && (!existing.latest_total_fees || existing.latest_total_fees === 0)) {
        db.prepare(`
          INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
          VALUES (?, ?, ?)
        `).run(poolId, p.initial_fees, p.start_date);
      }
    }

    // Sync to Firestore
    try {
      const activeDb = await getWorkingFirestore();
      if (!activeDb) {
        console.warn(`[DATABASE] Skipping Firestore sync for ${p.name}: No working Firestore instance.`);
        continue;
      }

      const poolData = db.prepare("SELECT * FROM pools WHERE id = ?").get(poolId) as any;
      if (poolData) {
        const stableId = getPoolDocId(poolData);
        await activeDb.collection('pools').doc(stableId).set({
          id: stableId,
          name: poolData.name,
          network: poolData.network,
          pair: poolData.pair,
          fee_percent: poolData.fee_percent,
          min_range: poolData.min_range,
          max_range: poolData.max_range,
          start_liquidity_usd: poolData.start_liquidity_usd,
          start_price: poolData.start_price,
          start_date: poolData.start_date
        }, { merge: true });

        // Sync snapshots
        const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ?").all(poolId) as any[];
        for (const s of snapshots) {
          const snapRef = activeDb.collection('pools').doc(stableId).collection('snapshots');
          // Use a deterministic ID based on timestamp to prevent duplicates in Firestore
          const deterministicId = s.snapshot_datetime.replace(/[^0-9]/g, '');
          await snapRef.doc(deterministicId).set({
            pool_id: stableId,
            total_fees: s.total_fees,
            snapshot_datetime: s.snapshot_datetime
          }, { merge: true });
        }
      }
    } catch (e) {
      console.error(`[DATABASE] Firestore sync failed for ${p.name}:`, e);
    }
  }
  const count = db.prepare("SELECT COUNT(*) as count FROM pools").get() as any;
  console.log(`[SYNC] System pools sync finished. Total pools in DB: ${count.count}`);
}

async function syncHistoricalPrices() {
  const symbols = ['BTCUSDT', 'ETHUSDT', 'AVAXUSDT'];
  console.log("[SYNC] Starting historical price sync...");

  for (const symbol of symbols) {
    try {
      // Find the last open_time we have
      const last = db.prepare("SELECT MAX(open_time) as last_time FROM historical_prices WHERE symbol = ?").get(symbol) as any;
      let startTime = last?.last_time ? last.last_time + 1 : 0;
      
      // If we have no data, start from a reasonable point (e.g., 5 years ago)
      if (startTime === 0) {
        startTime = Date.now() - (5 * 365 * 24 * 60 * 60 * 1000);
      }

      let hasMore = true;
      let totalFetched = 0;

      while (hasMore) {
        const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1d&startTime=${startTime}&limit=1000`;
        const res = await fetch(url);
        if (!res.ok) {
          console.error(`[SYNC] Binance API error for ${symbol}: ${res.status}`);
          break;
        }

        const data = await res.json() as any[];
        if (data.length === 0) {
          hasMore = false;
          break;
        }

        const insert = db.prepare(`
          INSERT OR IGNORE INTO historical_prices (symbol, open_time, open, high, low, close, volume)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `);

        const transaction = db.transaction((rows) => {
          for (const row of rows) {
            insert.run(symbol, row[0], parseFloat(row[1]), parseFloat(row[2]), parseFloat(row[3]), parseFloat(row[4]), parseFloat(row[5]));
          }
        });

        transaction(data);
        totalFetched += data.length;
        startTime = data[data.length - 1][0] + 1;

        if (data.length < 1000) {
          hasMore = false;
        } else {
          // Small delay to avoid rate limits
          await new Promise(r => setTimeout(r, 200));
        }
      }
      console.log(`[SYNC] Synced ${totalFetched} new candles for ${symbol}`);
    } catch (err) {
      console.error(`[SYNC] Failed to sync ${symbol}:`, err);
    }
  }
  const count = db.prepare("SELECT COUNT(*) as count FROM historical_prices").get() as any;
  console.log(`[SYNC] Historical price sync finished. Total rows in DB: ${count.count}`);
}

async function autoSyncAllWallets() {
  console.log("[SYNC] Starting automated wallet sync for all users...");
  try {
    const users = db.prepare("SELECT * FROM users WHERE wallet_address IS NOT NULL").all() as any[];
    const pools = db.prepare("SELECT * FROM pools").all() as any[];
    const networks = Array.from(new Set(pools.map(p => p.network)));
    const now = new Date().toISOString();
    const today = now.split('T')[0] + 'T00:00:00Z';

    for (const user of users) {
      console.log(`[SYNC] Auto-syncing wallet for ${user.email} (${user.wallet_address})...`);
      const allPositions: any[] = [];

      for (const network of networks) {
        try {
          const positions = await fetchWalletPositions(user.wallet_address, network);
          allPositions.push(...positions.map(pos => ({ ...pos, network })));
        } catch (netErr) {
          console.error(`[SYNC] Error fetching positions for ${network}:`, netErr);
        }
      }

      if (allPositions.length === 0) continue;

      const symbols = ['ETHUSDT', 'BTCUSDT', 'AVAXUSDT'];
      const priceMap: Record<string, number> = {};
      
      try {
        const priceResults = await Promise.all(
          symbols.map(s => fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${s}`).then(r => r.json() as any))
        );
        priceResults.forEach(r => {
          if (r.symbol && r.price) {
            const asset = r.symbol.replace('USDT', '');
            priceMap[asset] = parseFloat(r.price);
          }
        });
      } catch (err) {
        console.error('[SYNC] Failed to fetch prices:', err);
      }

      const updates: Record<number, number> = {};
      for (const pos of allPositions) {
        const t0_pos = pos.pool.token0.symbol.toUpperCase().replace('W', '');
        const t1_pos = pos.pool.token1.symbol.toUpperCase().replace('W', '');
        
        for (const pool of pools) {
          const [t0_pool, t1_pool] = pool.pair.toUpperCase().replace('W', '').split('/');
          
          const isMatch = pos.network === pool.network &&
            ((t0_pos.includes(t0_pool) && t1_pos.includes(t1_pool)) ||
             (t0_pos.includes(t1_pool) && t1_pos.includes(t0_pool)));
          
          if (isMatch) {
            const fees0 = parseFloat(pos.collectedFeesToken0 || '0');
            const fees1 = parseFloat(pos.collectedFeesToken1 || '0');
            const price0 = priceMap[t0_pos] || (t0_pos === 'USDC' || t0_pos === 'USDT' ? 1 : 0);
            const price1 = priceMap[t1_pos] || (t1_pos === 'USDC' || t1_pos === 'USDT' ? 1 : 0);
            const totalFeesUsd = (fees0 * price0) + (fees1 * price1);
            
            updates[pool.id] = (updates[pool.id] || 0) + totalFeesUsd;
            console.log(`[SYNC] Matched position ${pos.id} to pool ${pool.name}. Fees: $${totalFeesUsd.toFixed(2)}`);
          }
        }
      }

      for (const poolId in updates) {
        const totalFeesUsd = updates[poolId];
        if (totalFeesUsd > 0) {
          // Check if we already have a snapshot for today
          const existing = db.prepare("SELECT id FROM snapshots WHERE pool_id = ? AND snapshot_datetime >= ?").get(poolId, today) as any;
          if (existing) {
            db.prepare("UPDATE snapshots SET total_fees = ?, snapshot_datetime = ? WHERE id = ?").run(totalFeesUsd, now, existing.id);
          } else {
            db.prepare("INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime) VALUES (?, ?, ?)").run(poolId, totalFeesUsd, now);
          }
          // Sync to Firestore
          await syncSnapshotToFirestore(parseInt(poolId), { total_fees: totalFeesUsd, snapshot_datetime: now });
        }
      }
    }
    console.log("[SYNC] Automated wallet sync completed.");
  } catch (err) {
    console.error("[SYNC] Automated wallet sync failed:", err);
  }
}

async function startServer() {
  console.log("[SERVER] startServer() called");
  const app = express();
  app.set('trust proxy', true);
  const PORT = 3000;

  console.log(`[SERVER] Starting LP Analytics Server v3.2 (Router Refactor) in ${process.env.NODE_ENV} mode`);

  app.use(express.json({ limit: '500mb' }));
  app.use(cookieParser());

  // Auth Middleware
  const authenticate = (req: Request, res: Response, next: NextFunction) => {
    try {
      let token = req.cookies.auth_token;
      
      // Also check Authorization header
      if (!token && req.headers.authorization?.startsWith('Bearer ')) {
        token = req.headers.authorization.split(' ')[1];
        console.log(`[AUTH DEBUG] Found token in Authorization header`);
      }

      if (!token) {
        (req as any).user = null;
        return next();
      }
      
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      if (!decoded || (!decoded.id && !decoded.uid)) {
        console.log(`[AUTH DEBUG] Invalid token payload:`, decoded);
        (req as any).user = null;
        return next();
      }

      const userId = decoded.id || decoded.uid;
      console.log(`[AUTH DEBUG] Token decoded for user ID: ${userId}, email: ${decoded.email}`);
      let user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId) as any;
      
      // If user is missing from DB but token says they are the system admin, re-create them
      if (!user && decoded.email === ADMIN_EMAIL) {
        console.log(`[AUTH] Re-creating missing admin from token: ${decoded.email}`);
        db.prepare("INSERT INTO users (id, email, name, picture, role, subscription_type) VALUES (?, ?, ?, ?, ?, ?)")
          .run(userId, decoded.email, 'Admin', null, 'admin', 'manual');
        user = db.prepare("SELECT * FROM users WHERE id = ?").get(userId) as any;
      }

      if (user) {
        console.log(`[AUTH DEBUG] Found user in DB: ${user.email}, role: ${user.role}`);
        if (user.role !== 'admin' && user.subscription_expiry) {
          const expiry = new Date(user.subscription_expiry);
          if (expiry < new Date()) {
            user.role = 'pending_payment';
            db.prepare("UPDATE users SET role = 'pending_payment' WHERE id = ?").run(user.id);
          }
        }
        (req as any).user = user;
      } else {
        console.log(`[AUTH DEBUG] User not found in DB for ID: ${userId}`);
        (req as any).user = null;
      }
      next();
    } catch (err) {
      console.error(`[AUTH DEBUG] Error in authenticate:`, err);
      (req as any).user = null;
      next();
    }
  };

  app.use(authenticate);

  const apiRouter = express.Router();

  // Request Logger for API
  apiRouter.use((req, res, next) => {
    console.log(`[API DEBUG] ${req.method} ${req.url} - User: ${(req as any).user?.email || 'none'}`);
    next();
  });

  const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    if (user?.role !== 'admin') {
      console.warn(`[AUTH] Admin access denied for ${user?.email || 'unauthenticated'} on ${req.method} ${req.url}. Role: ${user?.role || 'none'}`);
      return res.status(403).json({ error: "Admin access required" });
    }
    console.log(`[AUTH] Admin access granted for ${user.email} on ${req.method} ${req.url}`);
    next();
  };

  const requireApproved = (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    if (user?.role !== 'admin' && user?.role !== 'approved') {
      return res.status(403).json({ error: "Approved access required" });
    }
    next();
  };

  apiRouter.get("/health", (req, res) => {
    console.log("[HEALTH DEBUG] Request received at /api/health");
    res.json({ 
      status: "ok", 
      version: "3.3-DEBUG",
      mode: process.env.NODE_ENV, 
      user: (req as any).user?.email || 'none' 
    });
  });

  apiRouter.get("/ping", (req, res) => {
    res.json({ pong: true, time: new Date().toISOString() });
  });

  apiRouter.get("/ranges/analyze", async (req, res) => {
    const { symbol, lower, upper } = req.query;
    if (!symbol || !lower || !upper) {
      return res.status(400).json({ error: "Missing parameters" });
    }

    const l = parseFloat(lower as string);
    const u = parseFloat(upper as string);
    const sym = (symbol as string).toUpperCase();

    try {
      const prices = db.prepare("SELECT open_time, low, high FROM historical_prices WHERE symbol = ? ORDER BY open_time ASC").all(sym) as any[];
      
      if (prices.length === 0) {
        return res.json({ 
          daysInRange: 0, 
          totalDays: 0, 
          avgDaysPerYear: 0,
          allTimeDays: 0,
          lastYearDaysInRange: 0,
          lastYearTotalDays: 0
        });
      }

      const now = Date.now();
      const oneYearAgo = now - (365 * 24 * 60 * 60 * 1000);

      let daysInRange = 0;
      let lastYearDaysInRange = 0;
      let lastYearTotalDays = 0;

      prices.forEach(p => {
        const inRange = p.low >= l && p.high <= u;
        if (inRange) {
          daysInRange++;
          if (p.open_time >= oneYearAgo) {
            lastYearDaysInRange++;
          }
        }
        if (p.open_time >= oneYearAgo) {
          lastYearTotalDays++;
        }
      });

      const firstTime = prices[0].open_time;
      const totalDays = Math.ceil((now - firstTime) / (24 * 60 * 60 * 1000));
      const years = totalDays / 365.25;
      const avgDaysPerYear = years > 0 ? daysInRange / years : 0;

      res.json({
        daysInRange,
        totalDays,
        avgDaysPerYear,
        allTimeDays: daysInRange,
        lastYearDaysInRange,
        lastYearTotalDays: lastYearTotalDays || 365
      });
    } catch (err) {
      console.error("[API] Range analysis failed:", err);
      res.status(500).json({ error: "Analysis failed" });
    }
  });

  apiRouter.get("/ranges/summary", async (req, res) => {
    const { symbol } = req.query;
    if (!symbol) return res.status(400).json({ error: "Symbol required" });

    try {
      const stats = db.prepare(`
        SELECT 
          MIN(low) as min_price, 
          MAX(high) as max_price, 
          COUNT(*) as total_days,
          MIN(open_time) as first_time,
          MAX(open_time) as last_time
        FROM historical_prices 
        WHERE symbol = ?
      `).get(symbol) as any;

      if (!stats || stats.total_days === 0) {
        return res.json({
          min_price: 0,
          max_price: 0,
          total_days: 0,
          first_time: Date.now(),
          last_time: Date.now()
        });
      }

      res.json(stats);
    } catch (err) {
      res.status(500).json({ error: "Summary failed" });
    }
  });

  apiRouter.post("/ranges/sync-manual", requireAdmin, async (req, res) => {
    syncHistoricalPrices().catch(err => console.error("[SYNC] Manual historical sync failed:", err));
    res.json({ message: "Sync started in background" });
  });

  apiRouter.post("/pools/sync-manual", requireAdmin, async (req, res) => {
    syncSystemPools().catch(err => console.error("[SYNC] Manual pool sync failed:", err));
    res.json({ message: "Sync started in background" });
  });

  apiRouter.get("/wallet-sync-v3", async (req, res) => {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ error: "Unauthorized. Please log in again." });
    }
    
    if (!user.wallet_address) {
      return res.status(400).json({ error: "Wallet address not configured." });
    }

    try {
      const pools = db.prepare("SELECT * FROM pools").all() as any[];
      const networks = Array.from(new Set(pools.map(p => p.network)));
      const allPositions: any[] = [];

      for (const network of networks) {
        try {
          const positions = await fetchWalletPositions(user.wallet_address, network);
          allPositions.push(...positions.map(pos => ({ ...pos, network })));
        } catch (netErr) {
          console.error(`[SYNC] Error fetching positions for ${network}:`, netErr);
        }
      }

      const symbols = ['ETHUSDT', 'BTCUSDT', 'AVAXUSDT'];
      const priceMap: Record<string, number> = {};
      
      try {
        const priceResults = await Promise.all(
          symbols.map(s => fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${s}`).then(r => r.json() as any))
        );
        priceResults.forEach(r => {
          if (r.symbol && r.price) {
            const asset = r.symbol.replace('USDT', '');
            priceMap[asset] = parseFloat(r.price);
          }
        });
      } catch (err) {
        console.error('[SYNC] Failed to fetch prices:', err);
      }

      const updates: Record<number, number> = {};
      for (const pos of allPositions) {
        const t0_pos = pos.pool.token0.symbol.toUpperCase().replace('W', '');
        const t1_pos = pos.pool.token1.symbol.toUpperCase().replace('W', '');
        
        for (const pool of pools) {
          const [t0_pool, t1_pool] = pool.pair.toUpperCase().replace('W', '').split('/');
          
          const isMatch = pos.network === pool.network &&
            ((t0_pos.includes(t0_pool) && t1_pos.includes(t1_pool)) ||
             (t0_pos.includes(t1_pool) && t1_pos.includes(t0_pool)));
          
          if (isMatch) {
            const fees0 = parseFloat(pos.collectedFeesToken0 || '0');
            const fees1 = parseFloat(pos.collectedFeesToken1 || '0');
            const price0 = priceMap[t0_pos] || (t0_pos === 'USDC' || t0_pos === 'USDT' ? 1 : 0);
            const price1 = priceMap[t1_pos] || (t1_pos === 'USDC' || t1_pos === 'USDT' ? 1 : 0);
            const totalFeesUsd = (fees0 * price0) + (fees1 * price1);
            
            updates[pool.id] = (updates[pool.id] || 0) + totalFeesUsd;
            console.log(`[SYNC] Matched position ${pos.id} to pool ${pool.name}. Fees: $${totalFeesUsd.toFixed(2)}`);
          }
        }
      }

      const finalUpdates: Record<number, string> = {};
      for (const poolIdStr in updates) {
        const poolId = parseInt(poolIdStr);
        finalUpdates[poolId] = updates[poolId].toFixed(4);
      }

      res.json(finalUpdates);
    } catch (error) {
      console.error("[SYNC] Wallet sync error:", error);
      res.status(500).json({ error: "Internal server error: " + (error as Error).message });
    }
  });

  // Helper to get the correct redirect URI
  const getRedirectUri = (req: Request) => {
    // Priority 1: Use APP_URL if available (standard for this environment)
    if (process.env.APP_URL) {
      const uri = `${process.env.APP_URL.replace(/\/$/, '')}/auth/callback`;
      console.log(`[AUTH] Redirect URI (APP_URL): ${uri}`);
      return uri;
    }

    const host = req.get('host');
    
    // Priority 2: Forced domain for production if configured
    if (process.env.NODE_ENV === 'production' && !host?.includes('localhost')) {
      // Fallback to the custom domain if APP_URL is not set but we are in production
      const finalHost = 'www.lpanalytics.xyz';
      const uri = `https://${finalHost}/auth/callback`;
      console.log(`[AUTH] Production Redirect URI (Forced): ${uri}`);
      return uri;
    }
    
    // Priority 3: Local development fallback
    const protocol = req.protocol || 'http';
    return `${protocol}://${host || 'localhost:3000'}/auth/callback`;
  };

  apiRouter.post('/auth/firebase-sync', async (req, res) => {
    const { idToken } = req.body;
    if (!idToken) return res.status(400).json({ error: "Missing idToken" });

    try {
      const decodedToken = await authAdmin.verifyIdToken(idToken);
      const { uid, email, name, picture } = decodedToken;

      if (!email) return res.status(400).json({ error: "Email not provided by Firebase" });

      let user = db.prepare("SELECT * FROM users WHERE id = ?").get(uid) as any;
      const isSystemAdmin = email === ADMIN_EMAIL;
      const role = isSystemAdmin ? 'admin' : (user?.role || 'approved');

      if (!user) {
        console.log(`[AUTH] Creating new user from Firebase sync: ${email}`);
        db.prepare("INSERT INTO users (id, email, name, picture, role, subscription_type) VALUES (?, ?, ?, ?, ?, ?)")
          .run(uid, email, name || '', picture || '', role, 'free_test');
        user = { id: uid, email, role };
      } else {
        console.log(`[AUTH] Updating user from Firebase sync: ${email}`);
        db.prepare("UPDATE users SET email = ?, name = ?, picture = ?, role = ? WHERE id = ?")
          .run(email, name || user.name, picture || user.picture, role, uid);
        user.role = role;
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.cookie('auth_token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 7 * 24 * 60 * 60 * 1000
      });

      res.json({ success: true, user });
    } catch (err: any) {
      console.error("[AUTH ERROR] Firebase sync failed:", err);
      res.status(401).json({ error: "Invalid token" });
    }
  });

  apiRouter.get('/auth/url', (req, res) => {
    const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
    if (!clientId) {
      return res.status(500).json({ error: "Google Client ID not configured in environment variables." });
    }
    
    const redirectUri = getRedirectUri(req);
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'openid email profile',
      access_type: 'offline',
      prompt: 'consent'
    });
    res.json({ url: `https://accounts.google.com/o/oauth2/v2/auth?${params}` });
  });

  app.get('/auth/callback', async (req, res) => {
    const { code } = req.query;
    if (!code) {
      console.error("[AUTH ERROR] No code provided in callback");
      return res.status(400).send("No code provided");
    }

    try {
      const redirectUri = getRedirectUri(req);
      console.log(`[AUTH] Callback reached. Code present. Redirect URI: ${redirectUri}`);
      
      const tokenParams = new URLSearchParams({
        code: code as string,
        client_id: process.env.VITE_GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code'
      });

      console.log(`[AUTH] Exchanging code for tokens...`);
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: tokenParams
      });

      if (!tokenRes.ok) {
        const errorData = await tokenRes.text();
        console.error(`[AUTH ERROR] Token exchange failed (${tokenRes.status}):`, errorData);
        return res.status(500).send(`Authentication failed during token exchange: ${errorData}`);
      }

      const tokens = await tokenRes.json();
      console.log(`[AUTH] Tokens received successfully.`);

      const userRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${tokens.access_token}` }
      });

      if (!userRes.ok) {
        const errorData = await userRes.text();
        console.error(`[AUTH ERROR] User info fetch failed (${userRes.status}):`, errorData);
        return res.status(500).send(`Authentication failed during user info fetch: ${errorData}`);
      }

      const googleUser = await userRes.json();
      console.log(`[AUTH] Google user info retrieved: ${googleUser.email}`);

      let user = db.prepare("SELECT * FROM users WHERE id = ?").get(googleUser.sub) as any;
      const isSystemAdmin = googleUser.email === ADMIN_EMAIL;
      const role = isSystemAdmin ? 'admin' : (user?.role || 'approved');

      if (!user) {
        console.log(`[AUTH] Creating new user: ${googleUser.email}`);
        db.prepare("INSERT INTO users (id, email, name, picture, role, subscription_type) VALUES (?, ?, ?, ?, ?, ?)")
          .run(googleUser.sub, googleUser.email, googleUser.name, googleUser.picture, role, 'free_test');
        user = { id: googleUser.sub, email: googleUser.email, role };
      } else {
        console.log(`[AUTH] Updating existing user: ${googleUser.email}`);
        // Update user info and ensure admin role if email matches
        db.prepare("UPDATE users SET email = ?, name = ?, picture = ?, role = ? WHERE id = ?")
          .run(googleUser.email, googleUser.name, googleUser.picture, role, googleUser.sub);
        user.role = role;
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '7d' }
      );
      console.log(`[AUTH] JWT signed for ${user.email}. Setting cookie...`);
      
      res.cookie('auth_token', token, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });

      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Authentication successful. Closing window...</p>
          </body>
        </html>
      `);
    } catch (err: any) {
      console.error("[AUTH ERROR] Unexpected error in callback:", err);
      res.status(500).send(`Authentication failed: ${err.message}`);
    }
  });

  apiRouter.get('/auth/me', (req, res) => {
    if (!(req as any).user) {
      return res.status(401).json({ role: 'unauthenticated' });
    }
    const user = { ...(req as any).user };
    user.has_accepted_disclaimer = !!user.has_accepted_disclaimer;
    res.json(user);
  });

  apiRouter.post('/auth/accept-disclaimer', (req, res) => {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    try {
      db.prepare("UPDATE users SET has_accepted_disclaimer = 1 WHERE id = ?").run(user.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post('/auth/logout', (req, res) => {
    res.clearCookie('auth_token', { sameSite: 'none', secure: true });
    res.json({ success: true });
  });

  // Payment Routes
  apiRouter.post('/payments/create-invoice', (req, res) => {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { plan, currency, network } = req.body;
    if (!plan || !currency || !network) {
      return res.status(400).json({ error: 'Plan, currency, and network are required' });
    }

    const amount = plan === 'monthly' ? 11 : 97;
    const paymentId = crypto.randomUUID();

    // Recommendation: Use NowPayments.io for real crypto processing.
    // It supports USDC/USDT on multiple networks with ~0.5% fees.
    const mockAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"; // Placeholder

    db.prepare(`
      INSERT INTO payments (id, user_id, amount, currency, network, subscription_type, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(paymentId, user.id, amount, currency, network, plan, 'pending');

    res.json({
      paymentId,
      amount,
      currency,
      network,
      address: mockAddress,
      qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${mockAddress}`
    });
  });

  apiRouter.post('/payments/verify', (req, res) => {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { paymentId } = req.body;
    const payment = db.prepare("SELECT * FROM payments WHERE id = ? AND user_id = ?").get(paymentId, user.id) as any;

    if (!payment) return res.status(404).json({ error: 'Payment not found' });

    // Simulation: In production, you would verify the transaction on-chain or via webhook
    const expiryDate = new Date();
    if (payment.subscription_type === 'monthly') {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
    } else {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
    }

    db.prepare("UPDATE payments SET status = 'completed' WHERE id = ?").run(paymentId);
    db.prepare("UPDATE users SET role = 'approved', subscription_type = ?, subscription_expiry = ?, last_payment_at = CURRENT_TIMESTAMP WHERE id = ?")
      .run(payment.subscription_type, expiryDate.toISOString(), user.id);

    // Admin Notification
    console.log(`[ADMIN NOTIFICATION] New Payment: ${user.email} paid $${payment.amount} (${payment.subscription_type})`);
    
    res.json({ success: true, expiry: expiryDate });
  });

  // User Management (Admin only)
  apiRouter.get('/debug/users', (req, res) => {
    const users = db.prepare("SELECT * FROM users").all();
    res.json(users);
  });

  apiRouter.get('/admin/users', requireAdmin, (req, res) => {
    const users = db.prepare(`
      SELECT u.*, 
             (SELECT COUNT(*) FROM suggestions s WHERE s.user_id = u.id OR s.user_email = u.email) as suggestion_count
      FROM users u 
      ORDER BY created_at DESC
    `).all();
    console.log(`[ADMIN] Fetching users. Found: ${users.length}`);
    res.json(users);
  });

  apiRouter.get('/admin/suggestions', requireAdmin, (req, res) => {
    try {
      const suggestions = db.prepare(`
        SELECT s.*, u.name as user_name, u.picture as user_picture
        FROM suggestions s
        LEFT JOIN users u ON s.user_id = u.id
        ORDER BY s.created_at DESC
      `).all() as any[];

      const replies = db.prepare("SELECT * FROM suggestion_replies ORDER BY created_at ASC").all() as any[];
      
      const suggestionsWithReplies = suggestions.map(s => ({
        ...s,
        replies: replies.filter(r => r.suggestion_id === s.id)
      }));

      res.json(suggestionsWithReplies);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post('/admin/suggestions/:id/reply', requireAdmin, async (req, res) => {
    const { id } = req.params;
    const { message } = req.body;
    const adminUser = (req as any).user;

    if (!message) return res.status(400).json({ error: "Message is required" });

    try {
      const result = db.prepare("INSERT INTO suggestion_replies (suggestion_id, admin_id, message) VALUES (?, ?, ?)")
        .run(id, adminUser.id, message);
      
      const replyId = result.lastInsertRowid;
      
      // Sync to Firestore
      await dbAdmin.collection('suggestions').doc(String(id)).collection('replies').doc(String(replyId)).set({
        admin_id: adminUser.id,
        message,
        created_at: new Date().toISOString()
      });

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.get('/suggestions/my', (req, res) => {
    const user = (req as any).user;
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    try {
      const suggestions = db.prepare(`
        SELECT * FROM suggestions 
        WHERE user_id = ? OR user_email = ?
        ORDER BY created_at DESC
      `).all(user.id, user.email) as any[];

      const replies = db.prepare(`
        SELECT r.* FROM suggestion_replies r
        JOIN suggestions s ON r.suggestion_id = s.id
        WHERE s.user_id = ? OR s.user_email = ?
        ORDER BY r.created_at ASC
      `).all(user.id, user.email) as any[];

      const suggestionsWithReplies = suggestions.map(s => ({
        ...s,
        replies: replies.filter(r => r.suggestion_id === s.id)
      }));

      res.json(suggestionsWithReplies);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.get('/admin/users/:id/suggestions', requireAdmin, (req, res) => {
    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.params.id) as any;
    if (!user) return res.status(404).json({ error: "User not found" });

    const suggestions = db.prepare(`
      SELECT * FROM suggestions 
      WHERE user_id = ? OR user_email = ? 
      ORDER BY created_at DESC
    `).all(user.id, user.email);
    
    res.json(suggestions);
  });

  apiRouter.put('/admin/users/:id/role', requireAdmin, async (req, res) => {
    const { role } = req.body;
    if (!['admin', 'approved', 'pending', 'pending_payment'].includes(role)) {
      return res.status(400).json({ error: "Invalid role" });
    }
    db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, req.params.id);
    
    // Sync to Firestore
    await dbAdmin.collection('users').doc(String(req.params.id)).set({ role }, { merge: true });

    res.json({ success: true });
  });

  apiRouter.put('/admin/users/:id/subscription', requireAdmin, async (req, res) => {
    const { expiry, type, wallet_address } = req.body;
    db.prepare("UPDATE users SET subscription_expiry = ?, subscription_type = ?, wallet_address = ?, role = 'approved' WHERE id = ?")
      .run(expiry, type || 'manual', wallet_address || null, req.params.id);
    
    // Sync to Firestore
    await dbAdmin.collection('users').doc(String(req.params.id)).set({
      subscription_expiry: expiry,
      subscription_type: type || 'manual',
      wallet_address: wallet_address || null,
      role: 'approved'
    }, { merge: true });

    res.json({ success: true });
  });

  apiRouter.delete('/admin/users/:id', requireAdmin, async (req, res) => {
    try {
      db.prepare("DELETE FROM payments WHERE user_id = ?").run(req.params.id);
      db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
      
      // Sync to Firestore
      await dbAdmin.collection('users').doc(String(req.params.id)).delete();

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // API Routes (Protected)
  
  // Export full database

  // Export full database
  apiRouter.get("/export", requireAdmin, (req, res) => {
    try {
      const pools = db.prepare("SELECT * FROM pools").all();
      const snapshots = db.prepare("SELECT * FROM snapshots").all();
      const users = db.prepare("SELECT * FROM users").all();
      const payments = db.prepare("SELECT * FROM payments").all();
      const suggestions = db.prepare("SELECT * FROM suggestions").all();
      const suggestion_replies = db.prepare("SELECT * FROM suggestion_replies").all();
      
      res.json({ 
        pools, 
        snapshots, 
        users, 
        payments, 
        suggestions,
        suggestion_replies,
        exportDate: new Date().toISOString(),
        version: "1.1"
      });
    } catch (error) {
      console.error("[EXPORT ERROR]", error);
      res.status(500).json({ error: (error as Error).message });
    }
  });

  let isRestoreInProgress = false;

  // Restore database from backup
  // Clear all database data
  apiRouter.post("/clear-database", requireAdmin, async (req, res) => {
    try {
      console.log("[DATABASE] Manual database clear requested...");
      
      const currentUser = (req as any).user;
      const transaction = db.transaction(() => {
        db.prepare("DELETE FROM snapshots").run();
        db.prepare("DELETE FROM pools").run();
        db.prepare("DELETE FROM payments").run();
        
        // Preserve current user to maintain session
        if (currentUser && currentUser.id) {
          db.prepare("DELETE FROM users WHERE id != ?").run(currentUser.id);
          console.log(`[DATABASE] Cleared all users except current admin: ${currentUser.email}`);
        } else {
          db.prepare("DELETE FROM users").run();
        }

        db.prepare("DELETE FROM suggestion_replies").run();
        db.prepare("DELETE FROM suggestions").run();
        
        // Reset sequences
        db.prepare("DELETE FROM sqlite_sequence WHERE name IN ('snapshots', 'pools', 'payments', 'users', 'suggestion_replies', 'suggestions')").run();
      });

      transaction();
      console.log("[DATABASE] SQLite data cleared.");

      // Sync to Firestore (Clear everything)
      await clearFirestorePools();
      
      // Re-seed system pools as requested: "Базовые пулы должны сохраняться"
      await syncSystemPools();
      console.log("[DATABASE] System pools re-seeded.");
      
      res.json({ success: true, message: "Database cleared successfully. Base pools preserved." });
    } catch (error) {
      console.error("[DATABASE ERROR] Clear failed:", error);
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Endpoint to manually trigger recalculation
  apiRouter.post("/admin/recalculate-deltas", requireAdmin, async (req, res) => {
    // Fire and forget to avoid timeout
    recalculateAllPoolDeltas().catch(e => console.error("[ADMIN] Background recalculation failed:", e));
    res.json({ success: true, message: "Recalculation started in background" });
  });

  apiRouter.get("/admin/debug-sqlite", requireAdmin, async (req, res) => {
    try {
      const pools = db.prepare("SELECT * FROM pools").all();
      res.json({ pools });
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  apiRouter.get("/admin/debug-firestore/:id", async (req, res) => {
    try {
      const activeDb = await getWorkingFirestore();
      if (!activeDb) return res.status(500).json({ error: "Firestore not initialized" });
      
      const poolId = req.params.id;
      const poolDoc = await activeDb.collection('pools').doc(poolId).get();
      if (!poolDoc.exists) return res.status(404).json({ error: "Pool not found in Firestore" });
      
      const snapshotsSnap = await poolDoc.ref.collection('snapshots').orderBy('snapshot_datetime', 'desc').get();
      const snapshots = snapshotsSnap.docs.map((d: any) => ({ id: d.id, ...d.data() }));
      
      res.json({ pool: poolDoc.data(), snapshots });
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  apiRouter.get("/admin/debug-pool/:id", requireAdmin, (req, res) => {
    try {
      const pool = db.prepare("SELECT * FROM pools WHERE id = ? OR stable_id = ?").get(req.params.id, req.params.id) as any;
      if (!pool) return res.status(404).json({ error: "Pool not found" });
      const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(pool.id);
      const deltas = calculatePoolDeltas(snapshots);
      res.json({ pool, snapshots, deltas });
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  apiRouter.post("/restore", requireAdmin, async (req, res) => {
    console.log("[RESTORE] Handler started");
    if (isRestoreInProgress) {
      return res.status(429).json({ error: "A restore operation is already in progress. Please wait." });
    }

    const currentUser = (req as any).user;
    console.log(`[RESTORE] Request received from ${currentUser?.email}`);
    
    isRestoreInProgress = true;
    try {
      const performRestore = async () => {
        const getField = (obj: any, keys: string[]): any => {
          if (!obj || typeof obj !== 'object') return undefined;
          
          // Try direct keys first
          for (const key of keys) {
            if (obj[key] !== undefined && obj[key] !== null) {
              const val = obj[key];
              // If the value is a Firestore value type, unwrap it
              if (val && typeof val === 'object' && !Array.isArray(val)) {
                if (val.stringValue !== undefined) return val.stringValue;
                if (val.doubleValue !== undefined) return parseFloat(val.doubleValue);
                if (val.integerValue !== undefined) return parseInt(val.integerValue);
                if (val.timestampValue !== undefined) return val.timestampValue;
                if (val.booleanValue !== undefined) return val.booleanValue;
              }
              return val;
            }
          }

          // Try inside 'fields', 'data', '_data', 'value'
          const wrappers = ['fields', 'data', '_data', 'value'];
          for (const wrapper of wrappers) {
            if (obj[wrapper] && typeof obj[wrapper] === 'object') {
              const result = getField(obj[wrapper], keys);
              if (result !== undefined) return result;
            }
          }
          
          // Try case-insensitive top level
          const objKeys = Object.keys(obj);
          for (const key of keys) {
            const match = objKeys.find(k => k.toLowerCase() === key.toLowerCase());
            if (match && obj[match] !== undefined && obj[match] !== null) {
              const val = obj[match];
              if (val && typeof val === 'object' && !Array.isArray(val)) {
                if (val.stringValue !== undefined) return val.stringValue;
                if (val.doubleValue !== undefined) return parseFloat(val.doubleValue);
                if (val.integerValue !== undefined) return parseInt(val.integerValue);
                if (val.timestampValue !== undefined) return val.timestampValue;
                if (val.booleanValue !== undefined) return val.booleanValue;
              }
              return val;
            }
          }
          
          return undefined;
        };

        const normalizeDate = (dateStr: any) => {
          if (!dateStr) return new Date().toISOString();
          try {
            const d = new Date(dateStr);
            if (isNaN(d.getTime())) return String(dateStr);
            return d.toISOString();
          } catch (e) {
            return String(dateStr);
          }
        };

        const normalizeId = (id: any): string | null => {
          if (id === null || id === undefined) return null;
          
          // If it's a Firestore document path, extract the last part
          if (typeof id === 'string' && id.includes('/documents/')) {
            const parts = id.split('/');
            return parts[parts.length - 1];
          }

          if (typeof id === 'object') {
            const inner = getField(id, ['id', 'value', 'stringValue', 'integerValue']);
            if (inner !== undefined) return normalizeId(inner); // Recursive call to handle paths inside objects
            return JSON.stringify(id);
          }
          return String(id);
        };

        const parseNum = (val: any): number => {
          if (val === null || val === undefined) return 0;
          if (typeof val === 'number') return val;
          if (typeof val === 'string') {
            let cleaned = val.trim().replace(/[$\s]/g, '').replace(/[^\d.,-]/g, '');
            if (cleaned.includes(',') && cleaned.includes('.')) {
              if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
                cleaned = cleaned.replace(/\./g, '').replace(',', '.');
              } else {
                cleaned = cleaned.replace(/,/g, '');
              }
            } else if (cleaned.includes(',')) {
              const parts = cleaned.split(',');
              if (parts[1] && parts[1].length === 3) {
                cleaned = cleaned.replace(/,/g, '');
              } else {
                cleaned = cleaned.replace(',', '.');
              }
            }
            const parsed = parseFloat(cleaned);
            return isNaN(parsed) ? 0 : parsed;
          }
          if (typeof val === 'object' && !Array.isArray(val)) {
            const inner = getField(val, [
              'value', 'amount', 'val', 'total', 'total_fees', 'fees', 'fees_usd', 'total_fees_usd',
              'integerValue', 'doubleValue', 'numberValue', 'stringValue',
              'decimalValue', 'low', 'high', 'totalFees', 'accumulatedFees', 'total_fees_usd', 'fees_usd'
            ]);
            if (inner !== undefined && inner !== val) return parseNum(inner);
            if ('low' in val && 'high' in val) {
              return typeof val.high === 'number' && val.high !== 0 ? val.low + (val.high * 4294967296) : val.low;
            }
            for (const key in val) {
              if (typeof val[key] === 'number') return val[key];
              if (typeof val[key] === 'string' && !isNaN(parseFloat(val[key]))) return parseFloat(val[key]);
            }
          }
          return 0;
        };

        console.log(`[RESTORE] Raw request body preview (first 1000 chars): ${JSON.stringify(req.body).substring(0, 1000)}`);

        // Extract data with case-insensitive keys
        let backupPools = getField(req.body, ['pools', 'Pools', 'documents', 'data', 'pool_data']);
        let backupSnapshots = getField(req.body, ['snapshots', 'Snapshots', 'snapshots_data', 'snapshot_data', 'poolSnapshots', 'pool_snapshots']);
        let backupUsers = getField(req.body, ['users', 'Users', 'users_data', 'user_data']);
        let backupPayments = getField(req.body, ['payments', 'Payments', 'processedPayments', 'payments_data', 'processed_payments', 'payment_data']);
        let backupSuggestions = getField(req.body, ['suggestions', 'Suggestions', 'suggestions_data', 'suggestion_data']);
        let backupReplies = getField(req.body, ['suggestion_replies', 'replies', 'Replies', 'replies_data', 'reply_data']);

        // Fallback: If req.body is an array, it might be the pools array directly
        if (!backupPools && Array.isArray(req.body)) {
          console.log("[RESTORE] req.body is an array, treating as pools");
          backupPools = req.body;
        }

        // Fallback: If snapshots are missing but pools have snapshots nested
        if (!backupSnapshots && Array.isArray(backupPools)) {
          console.log("[RESTORE] Snapshots missing at top level, checking inside pools...");
          backupSnapshots = [];
          for (const p of backupPools) {
            const nested = getField(p, ['snapshots', 'Snapshots', 'poolSnapshots', 'pool_snapshots']);
            if (Array.isArray(nested)) {
              const poolId = getField(p, ['id', 'pool_id', 'PoolId', 'name']);
              for (const s of nested) {
                backupSnapshots.push({ ...s, _pool_id_ref: poolId });
              }
            }
          }
          if (backupSnapshots.length > 0) {
            console.log(`[RESTORE] Found ${backupSnapshots.length} nested snapshots.`);
          }
        }

        console.log(`[RESTORE] Backup contains: ${backupPools?.length || 0} pools, ${backupSnapshots?.length || 0} snapshots, ${backupUsers?.length || 0} users`);

        if (Array.isArray(backupPools) && backupPools.length > 0) {
          console.log("[RESTORE DEBUG] Sample pool 0 structure:", JSON.stringify(backupPools[0]).substring(0, 1000));
        }
        if (Array.isArray(backupSnapshots) && backupSnapshots.length > 0) {
          console.log("[RESTORE DEBUG] Sample snapshot 0 structure:", JSON.stringify(backupSnapshots[0]).substring(0, 1000));
        }

        if (!Array.isArray(backupPools) && !Array.isArray(backupUsers) && !Array.isArray(backupSuggestions) && !Array.isArray(backupPayments)) {
          console.error("[RESTORE ERROR] No recognizable data arrays found. Backup keys:", Object.keys(req.body));
          throw new Error("Invalid backup format: No recognizable data arrays found (pools, users, suggestions, or payments).");
        }

        if (backupPayments) {
          console.log(`[RESTORE DEBUG] Found backupPayments. Type: ${typeof backupPayments}, IsArray: ${Array.isArray(backupPayments)}, Length: ${Array.isArray(backupPayments) ? backupPayments.length : 'N/A'}`);
        } else {
          console.log("[RESTORE DEBUG] backupPayments is null/undefined. Keys checked: payments, Payments, processedPayments, payments_data, processed_payments");
        }

        // Pre-process backup data to handle admin ID mismatch
        let processedPayments = backupPayments;
        if (currentUser && Array.isArray(backupUsers) && Array.isArray(backupPayments)) {
          const backupAdmin = backupUsers.find((u: any) => u.email === currentUser.email);
          if (backupAdmin && backupAdmin.id !== currentUser.id) {
            console.log(`[RESTORE] Mapping backup admin ID ${backupAdmin.id} to current admin ID ${currentUser.id}`);
            processedPayments = backupPayments.map((p: any) => 
              p.user_id === backupAdmin.id ? { ...p, user_id: currentUser.id } : p
            );
          }
        }

        let poolsInserted = 0;
        let snapshotsInserted = 0;
        let usersInserted = 0;
        let paymentsInserted = 0;
        let suggestionsInserted = 0;
        let repliesInserted = 0;

        // Use a transaction for all SQLite operations to ensure atomicity and proper overwrite
        const transaction = db.transaction(() => {
          console.log("[RESTORE] Starting SQLite transaction...");
          
          // 1. Clear existing data
          db.prepare("DELETE FROM snapshots").run();
          db.prepare("DELETE FROM pools").run();
          db.prepare("DELETE FROM users").run();
          db.prepare("DELETE FROM payments").run();
          db.prepare("DELETE FROM suggestions").run();
          db.prepare("DELETE FROM suggestion_replies").run();

          const poolIdMap = new Map<string, number>();
          const poolNameMap = new Map<string, number>();

          // 2. Insert pools
          if (Array.isArray(backupPools)) {
            console.log(`[RESTORE DEBUG] Total pools in backup: ${backupPools.length}`);
            console.log(`[RESTORE DEBUG] Sample pools from backup:`, JSON.stringify(backupPools.slice(0, 3)));
            
            const insertPool = db.prepare(`
              INSERT INTO pools (name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date, latest_total_fees, latest_snapshot_datetime, stable_id)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            for (const p of backupPools) {
              const rawId = getField(p, ['id', 'pool_id', 'PoolId', 'name']);
              const originalId = normalizeId(rawId);
              const name = getField(p, ['name', 'pool_name']) || 'Unknown';
              const network = getField(p, ['network', 'chain']) || 'Unknown';
              const pair = getField(p, ['pair', 'symbol']) || 'Unknown';
              const fee = parseNum(getField(p, ['fee_percent', 'fee']));
              const min = parseNum(getField(p, ['min_range', 'min']));
              const max = parseNum(getField(p, ['max_range', 'max']));
              const liq = parseNum(getField(p, ['start_liquidity_usd', 'liquidity']));
              const price = parseNum(getField(p, ['start_price', 'price']));
              const date = normalizeDate(getField(p, ['start_date', 'date']));
              const stableId = getPoolDocId({ name, network, pair });
              
              const runResult = insertPool.run(name, network, pair, fee, min, max, liq, price, date, 0, null, stableId);
              const newId = runResult.lastInsertRowid as number;
              if (originalId) poolIdMap.set(originalId, newId);
              poolNameMap.set(name.toLowerCase(), newId);
              poolsInserted++;
            }
          }

          // 3. Insert snapshots
          let totalFeesSum = 0;
          let snapsInBatch = 0;
          let skippedSnapshots = 0;
          
          if (Array.isArray(backupSnapshots) && backupSnapshots.length > 0) {
            console.log(`[RESTORE DEBUG] Total snapshots in backup: ${backupSnapshots.length}`);
            
            const insertSnapshot = db.prepare(`
              INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
              VALUES (?, ?, ?)
            `);
            for (const s of backupSnapshots) {
              const rawPoolId = getField(s, ['pool_id', 'poolId', 'id', 'name']);
              const originalPoolId = normalizeId(rawPoolId);
              let targetPoolId = poolIdMap.get(originalPoolId);
              
              // Fuzzy match by name if ID fails
              if (!targetPoolId) {
                const sPoolName = getField(s, ['pool_name', 'name', 'pool']);
                if (sPoolName) {
                  const normalizedName = String(sPoolName).trim().toLowerCase();
                  targetPoolId = poolNameMap.get(normalizedName);
                }
              }

              if (targetPoolId) {
                const fees = parseNum(getField(s, ['total_fees', 'fees', 'amount', 'total_fees_usd', 'fees_usd', 'accumulated_fees']));
                const dt = normalizeDate(getField(s, ['snapshot_datetime', 'datetime', 'date', 'timestamp']));
                
                try {
                  insertSnapshot.run(targetPoolId, fees, dt);
                  snapsInBatch++;
                  totalFeesSum += fees;
                } catch (e) {
                  console.error(`[RESTORE ERROR] Failed to insert snapshot for pool ${targetPoolId}:`, e);
                }
              } else {
                skippedSnapshots++;
              }
            }
          }
          // Update the outer variable
          snapshotsInserted = snapsInBatch;
          console.log(`[RESTORE] Total fees sum across all snapshots: ${totalFeesSum}`);
          if (totalFeesSum === 0 && snapshotsInserted > 0) {
             console.warn("[RESTORE] WARNING: All snapshots have 0 fees. Check field mapping.");
             if (backupSnapshots.length > 0) {
               console.log("[RESTORE DEBUG] Sample snapshot data:", JSON.stringify(backupSnapshots[0]));
             }
          }
          
          // 4. Update pools with latest stats from snapshots
          console.log("[RESTORE] Updating pools with latest snapshot data...");
          const pools = db.prepare("SELECT id FROM pools").all() as any[];
          for (const pool of pools) {
            const latest = db.prepare(`
              SELECT total_fees, snapshot_datetime 
              FROM snapshots 
              WHERE pool_id = ? 
              ORDER BY snapshot_datetime DESC 
              LIMIT 1
            `).get(pool.id) as any;
            
            if (latest) {
              db.prepare("UPDATE pools SET latest_total_fees = ?, latest_snapshot_datetime = ? WHERE id = ?")
                .run(latest.total_fees, latest.snapshot_datetime, pool.id);
            }
          }

          // 5. Insert users
          if (Array.isArray(backupUsers)) {
            console.log(`[RESTORE] Inserting ${backupUsers.length} users...`);
            const insertUser = db.prepare(`
              INSERT OR REPLACE INTO users (id, email, name, picture, role, subscription_type, wallet_address, subscription_expiry, last_payment_at, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            for (const u of backupUsers) {
              if (currentUser && u.email === currentUser.email) continue;
              insertUser.run(
                u.id, 
                u.email || `unknown_${Math.random()}@example.com`, 
                u.name || 'Unknown User', 
                u.picture || null, 
                u.role || 'approved', 
                u.subscription_type || 'free_test',
                u.wallet_address || null,
                u.subscription_expiry || null,
                u.last_payment_at || null,
                u.created_at || new Date().toISOString()
              );
              usersInserted++;
            }
          }

          // 6. Insert payments
          if (Array.isArray(processedPayments)) {
            console.log(`[RESTORE] Inserting ${processedPayments.length} payments...`);
            const insertPayment = db.prepare(`
              INSERT INTO payments (id, user_id, amount, currency, network, status, subscription_type, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `);
            
            for (const pay of processedPayments) {
              try {
                const pId = normalizeId(getField(pay, ['id', 'ID'])) || `pay_${Date.now()}_${Math.random()}`;
                const pUserId = normalizeId(getField(pay, ['user_id', 'userId', 'UID', 'uid']));
                const pAmount = parseNum(getField(pay, ['amount', 'Amount']));
                const pCurrency = getField(pay, ['currency', 'Currency']) || 'USD';
                const pNetwork = getField(pay, ['network', 'Network']) || 'Unknown';
                const pStatus = getField(pay, ['status', 'Status']) || 'completed';
                const pSub = getField(pay, ['subscription_type', 'subscriptionType', 'subType']) || 'pro';
                const pCreatedAt = normalizeDate(getField(pay, ['created_at', 'createdAt', 'date']));

                if (pUserId) {
                  insertPayment.run(pId, pUserId, pAmount, pCurrency, pNetwork, pStatus, pSub, pCreatedAt);
                  paymentsInserted++;
                } else {
                  console.warn(`[RESTORE] Skipping payment due to missing UserID:`, JSON.stringify(pay).substring(0, 100));
                }
              } catch (e) {
                console.error("[RESTORE] Error inserting payment:", e);
              }
            }
          } else {
            console.warn("[RESTORE] processedPayments is not an array. Type:", typeof processedPayments);
          }

          // 7. Insert suggestions
          const suggestionIdMap = new Map<number | string, number>();
          if (Array.isArray(backupSuggestions)) {
            console.log(`[RESTORE] Inserting ${backupSuggestions.length} suggestions...`);
            const insertSuggestion = db.prepare(`
              INSERT INTO suggestions (user_id, user_email, topic, message, attachment_name, attachment_data, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?)
            `);
            
            for (const sug of backupSuggestions) {
              try {
                const sId = normalizeId(getField(sug, ['id', 'ID']));
                const sUserId = normalizeId(getField(sug, ['user_id', 'userId', 'UID', 'uid']));
                const sEmail = getField(sug, ['user_email', 'userEmail', 'email', 'Email']);
                const sTopic = getField(sug, ['topic', 'Topic']) || 'General';
                const sMessage = getField(sug, ['message', 'Message', 'text']) || '';
                const sAttachName = getField(sug, ['attachment_name', 'attachmentName']);
                const sAttachData = getField(sug, ['attachment_data', 'attachmentData']);
                const sCreatedAt = normalizeDate(getField(sug, ['created_at', 'createdAt', 'date']));

                const runResult = insertSuggestion.run(
                  sUserId || null,
                  sEmail || null,
                  sTopic,
                  sMessage,
                  sAttachName || null,
                  sAttachData || null,
                  sCreatedAt
                );
                const newId = runResult.lastInsertRowid as number;
                if (sId !== undefined) suggestionIdMap.set(sId, newId);
                suggestionsInserted++;
              } catch (e) {
                console.error("[RESTORE] Error inserting suggestion:", e);
              }
            }
          }

          // 8. Insert replies
          if (Array.isArray(backupReplies)) {
            console.log(`[RESTORE] Inserting ${backupReplies.length} replies...`);
            const insertReply = db.prepare(`
              INSERT INTO suggestion_replies (suggestion_id, admin_id, message, created_at)
              VALUES (?, ?, ?, ?)
            `);
            
            for (const rep of backupReplies) {
              try {
                const rSugId = normalizeId(getField(rep, ['suggestion_id', 'suggestionId', 'sugId']));
                const rAdminId = normalizeId(getField(rep, ['admin_id', 'adminId', 'UID', 'uid']));
                const rMessage = getField(rep, ['message', 'Message', 'text']) || '';
                const rCreatedAt = normalizeDate(getField(rep, ['created_at', 'createdAt', 'date']));

                const targetSugId = rSugId ? suggestionIdMap.get(rSugId) : null;
                if (targetSugId) {
                  insertReply.run(
                    targetSugId,
                    rAdminId || (currentUser?.id || 'admin'),
                    rMessage,
                    rCreatedAt
                  );
                  repliesInserted++;
                } else {
                  console.warn(`[RESTORE] Skipping reply due to missing target suggestion ID: ${rSugId}`);
                }
              } catch (e) {
                console.error("[RESTORE] Error inserting reply:", e);
              }
            }
          }

          // 9. Restore Admin
          if (currentUser) {
            db.prepare(`
              INSERT OR REPLACE INTO users (id, email, name, picture, role, subscription_type, wallet_address, subscription_expiry, last_payment_at, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
              currentUser.id, currentUser.email, currentUser.name, currentUser.picture, 'admin', 
              currentUser.subscription_type || 'none', currentUser.wallet_address || null, currentUser.subscription_expiry, 
              currentUser.last_payment_at, currentUser.created_at || new Date().toISOString()
            );
          }
          
          console.log("[RESTORE] SQLite transaction completed successfully.");
        });

        transaction();

        // 10. Recalculate latest stats for all pools in SQLite
        console.log("[RESTORE] Recalculating latest stats for pools...");
        const allPools = db.prepare("SELECT id FROM pools").all() as { id: number }[];
        const updatePoolStats = db.prepare(`
          UPDATE pools 
          SET latest_total_fees = COALESCE((SELECT total_fees FROM snapshots WHERE pool_id = pools.id ORDER BY snapshot_datetime DESC LIMIT 1), latest_total_fees),
              latest_snapshot_datetime = COALESCE((SELECT snapshot_datetime FROM snapshots WHERE pool_id = pools.id ORDER BY snapshot_datetime DESC LIMIT 1), latest_snapshot_datetime)
          WHERE id = ?
        `);
        
        for (const p of allPools) {
          updatePoolStats.run(p.id);
        }

        // 11. Sync System Pools BEFORE Firestore Sync
        console.log("[RESTORE] Running syncSystemPools...");
        await syncSystemPools();

        // 12. Consolidated Firestore Sync
        const syncToFirestore = async () => {
          try {
            console.log("[RESTORE] Starting Firestore sync...");
            await clearFirestorePools();
            await syncAllPoolsToFirestore();
            console.log("[RESTORE] Firestore sync completed successfully.");
          } catch (syncErr) {
            console.error("[RESTORE] Firestore sync failed during restore:", syncErr);
            // We don't throw here to still return the SQLite success
          }
        };

        // Run sync in foreground to ensure it's done before we return
        await syncToFirestore();

        // 13. Full Recalculation to ensure deltas are correct
        console.log("[RESTORE] Running full delta recalculation...");
        await recalculateAllPoolDeltas();

        const totalFeesInDb = db.prepare("SELECT SUM(latest_total_fees) as total FROM pools").get() as any;
        const totalSnapsInDb = db.prepare("SELECT COUNT(*) as count FROM snapshots").get() as any;

        return { 
          poolsInserted, 
          snapshotsInserted, 
          usersInserted, 
          paymentsInserted,
          suggestionsInserted,
          repliesInserted,
          debug: {
            totalFeesInDb: totalFeesInDb.total || 0,
            totalSnapshotsInDb: totalSnapsInDb.count || 0
          }
        };
      };

      const result = await performRestore();
      
      console.log(`[RESTORE] Success. Pools: ${result.poolsInserted}, Snaps: ${result.snapshotsInserted}, Users: ${result.usersInserted}, Payments: ${result.paymentsInserted}, Sug: ${result.suggestionsInserted}`);
      res.json({ success: true, ...result });
    } catch (error) {
      console.error("[RESTORE FATAL]", error);
      res.status(500).json({ error: (error as Error).message });
    } finally {
      isRestoreInProgress = false;
    }
  });

  // Bulk snapshots (v3 - Unified handler for better debugging)
  apiRouter.all("/snapshots/bulk-save-v3", requireAdmin, async (req, res) => {
    console.log(`[API DEBUG] Bulk Save v3 - Method: ${req.method}, User: ${(req as any).user?.email}`);
    
    if (req.method !== 'POST') {
      return res.status(405).json({ 
        error: `Method ${req.method} Not Allowed. This endpoint requires POST.`,
        details: "If you see this, the browser or a proxy converted your POST request to a GET."
      });
    }

    try {
      const { snapshots, timestamp } = req.body;
      if (!Array.isArray(snapshots)) {
        console.error("[API ERROR] Bulk Save v3 - snapshots is not an array:", req.body);
        return res.status(400).json({ error: "Snapshots must be an array" });
      }

      const ts = timestamp || new Date().toISOString();
      const poolCount = db.prepare("SELECT COUNT(*) as count FROM pools").get() as any;
      
      const insert = db.prepare(`
        INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
        VALUES (?, ?, ?)
      `);

      const transaction = db.transaction((data) => {
        if (data.length < poolCount.count) {
          throw new Error(`Incomplete data: Received ${data.length} snapshots but expected ${poolCount.count}. All pools must be recorded.`);
        }

        let count = 0;
        for (const s of data) {
          const fees = typeof s.total_fees === 'number' ? s.total_fees : parseFloat(String(s.total_fees).replace(/\s/g, '').replace(',', '.'));
          if (isNaN(fees)) {
            throw new Error(`Invalid fee value for pool ${s.pool_id}`);
          }
          
          // Find the numeric SQLite ID if a stable string ID was provided
          let sqlitePoolId = s.pool_id;
          if (typeof s.pool_id === 'string' && isNaN(Number(s.pool_id))) {
            const pool = db.prepare("SELECT id FROM pools WHERE stable_id = ? OR name = ?").get(s.pool_id, s.pool_id) as any;
            if (pool) {
              sqlitePoolId = pool.id;
            } else {
              console.warn(`[API] Could not find numeric ID for stable ID: ${s.pool_id}`);
            }
          }

          // Final check to prevent FOREIGN KEY constraint failed
          if (isNaN(Number(sqlitePoolId))) {
            throw new Error(`Could not resolve pool ID: ${s.pool_id}. Ensure the pool exists in the database.`);
          }

          insert.run(sqlitePoolId, fees, ts);
          count++;
        }
        return count;
      });

      const savedCount = transaction(snapshots);
      
      // Sync to Firestore after SQLite transaction
      for (const s of snapshots) {
        const fees = typeof s.total_fees === 'number' ? s.total_fees : parseFloat(String(s.total_fees).replace(/\s/g, '').replace(',', '.'));
        await syncSnapshotToFirestore(s.pool_id, {
          total_fees: fees,
          snapshot_datetime: ts
        });
      }

      console.log(`[SNAPSHOTS] Bulk save v3 successful. Saved ${savedCount} snapshots with timestamp ${ts}`);
      res.json({ success: true, savedCount, timestamp: ts });
    } catch (error) {
      console.error("[SNAPSHOTS ERROR v3]", error);
      res.status(500).json({ error: (error as Error).message });
    }
  });
  
  // Get all pools with latest metrics
  apiRouter.get("/pools", (req, res) => {
    try {
      const pools = db.prepare("SELECT * FROM pools").all();
      const poolsWithMetrics = pools.map((pool: any) => {
        const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(pool.id);
        
        const latestSnapshot: any = snapshots[0] || { total_fees: 0, snapshot_datetime: pool.start_date };
        
        const { delta_1: d1, delta_3: d3, delta_7: d7 } = calculatePoolDeltas(snapshots);

        const deltas = { "1": d1, "3": d3, "7": d7 };
        
        if (pool.name.includes('AERODROME')) {
          console.log(`[SERVER] Pool ${pool.id} (${pool.name}) - Snaps: ${snapshots.length}, D1: ${d1}, D3: ${d3}, D7: ${d7}`);
        }
        
        // Calculate days active
        const startDate = new Date(pool.start_date);
        const now = new Date();
        const daysActive = Math.max(0.0001, (now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
        
      // APR Since Start
        const aprSinceStart = (latestSnapshot.total_fees / pool.start_liquidity_usd) * (365.25 / daysActive) * 100;
        const feesPerDayAvg = latestSnapshot.total_fees / daysActive;

        // Price Neutral Logic
        // We assume fees are collected 50/50 in Asset/USDC.
        // We adjust the USD value of the Asset portion back to the start_price.
        let priceNeutralFees = latestSnapshot.total_fees;
        let priceImpactOnFees = 0;
        
        if (pool.start_price && pool.start_price > 0) {
          // Current price of asset (we don't have live price here, so we use the latest snapshot's context if possible, 
          // but for simplicity in the dashboard list we'll use a placeholder or the last known price from the client.
          // For now, let's assume we want to show the formulaic potential.
          // In a real scenario, we'd pass the current_price to this API.
        }

        // APR for periods (1D, 7D)
        const getMetricsForPeriod = (days: number) => {
          const targetDate = new Date(now.getTime() - days * 24 * 60 * 60 * 1000).toISOString();
          const oldSnapshot: any = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? AND snapshot_datetime <= ? ORDER BY snapshot_datetime DESC LIMIT 1").get(pool.id, targetDate);
          
          if (!oldSnapshot || oldSnapshot.id === latestSnapshot.id) {
            return { apr: 0, feesPerDay: 0 };
          }
          
          const feeDiff = latestSnapshot.total_fees - oldSnapshot.total_fees;
          const timeDiff = (new Date(latestSnapshot.snapshot_datetime).getTime() - new Date(oldSnapshot.snapshot_datetime).getTime()) / (1000 * 60 * 60 * 24);
          const actualDays = Math.max(0.0001, timeDiff);

          return {
            apr: (feeDiff / pool.start_liquidity_usd) * (365.25 / actualDays) * 100,
            feesPerDay: feeDiff / actualDays
          };
        };

        const metrics1D = getMetricsForPeriod(1);
        const metrics7D = getMetricsForPeriod(7);

        return {
          ...pool,
          daysActive,
          totalFees: latestSnapshot.total_fees,
          aprSinceStart,
          feesPerDayAvg,
          apr1D: metrics1D.apr,
          apr7D: metrics7D.apr,
          feesPerDay7D: metrics7D.feesPerDay,
          lastUpdate: latestSnapshot.snapshot_datetime,
          deltas,
          delta_1: d1,
          delta_3: d3,
          delta_7: d7,
          lastDeltaPct: d1
        };
      });
      
      res.json(poolsWithMetrics);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Get single pool details and history
  apiRouter.get("/pools/:id", (req, res) => {
    try {
      const pool = db.prepare("SELECT * FROM pools WHERE id = ?").get(req.params.id) as any;
      if (!pool) return res.status(404).json({ error: "Pool not found" });

      const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(req.params.id) as any[];
      
      const latestSnapshot: any = snapshots[0] || { total_fees: 0, snapshot_datetime: pool.start_date };
      const { delta_1: d1, delta_3: d3, delta_7: d7 } = calculatePoolDeltas(snapshots);

      const deltas = {
        "1": d1,
        "3": d3,
        "7": d7
      };

      const startDate = new Date(pool.start_date);
      const now = new Date();
      const daysActive = Math.max(0.0001, (now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      const aprSinceStart = (latestSnapshot.total_fees / pool.start_liquidity_usd) * (365.25 / daysActive) * 100;

      const poolWithMetrics = {
        ...pool,
        daysActive,
        totalFees: latestSnapshot.total_fees,
        aprSinceStart,
        lastUpdate: latestSnapshot.snapshot_datetime,
        deltas,
        delta_1: d1,
        delta_3: d3,
        delta_7: d7,
        lastDeltaPct: d1
      };

      res.json({ pool: poolWithMetrics, snapshots });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Add new pool
  apiRouter.post("/pools", requireAdmin, async (req, res) => {
    try {
      const { name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date } = req.body;
      const stableId = getPoolDocId({ name, network, pair });
      
      const result = db.prepare(`
        INSERT INTO pools (name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date, stable_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price || null, start_date, stableId);
      
      const poolId = result.lastInsertRowid;
      
      // Sync to Firestore
      await syncPoolToFirestore(poolId as number);

      res.json({ id: poolId, stable_id: stableId });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Add new snapshot
  apiRouter.post("/snapshots", requireAdmin, async (req, res) => {
    try {
      const { pool_id, total_fees, snapshot_datetime } = req.body;
      const ts = snapshot_datetime || new Date().toISOString();
      
      // Resolve pool_id to numeric SQLite ID if it's a stable string ID
      let sqlitePoolId = pool_id;
      if (typeof pool_id === 'string' && isNaN(Number(pool_id))) {
        const pool = db.prepare("SELECT id FROM pools WHERE stable_id = ? OR name = ?").get(pool_id, pool_id) as any;
        if (pool) {
          sqlitePoolId = pool.id;
        } else {
          console.warn(`[API] Could not find numeric ID for stable ID: ${pool_id}`);
        }
      }

      const result = db.prepare(`
        INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
        VALUES (?, ?, ?)
      `).run(sqlitePoolId, total_fees, ts);
      
      // Sync to Firestore (use the original pool_id which might be the stable ID)
      await syncSnapshotToFirestore(pool_id, {
        total_fees,
        snapshot_datetime: ts
      });

      res.json({ id: result.lastInsertRowid });
    } catch (error) {
      console.error("[SNAPSHOTS ERROR]", error);
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Update pool
  apiRouter.put("/pools/:id", requireAdmin, async (req, res) => {
      try {
          const { name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price, start_date } = req.body;
          db.prepare(`
            UPDATE pools SET name = ?, network = ?, pair = ?, fee_percent = ?, min_range = ?, max_range = ?, start_liquidity_usd = ?, start_price = ?, start_date = ?
            WHERE id = ?
          `).run(name, network, pair, fee_percent, min_range, max_range, start_liquidity_usd, start_price || null, start_date, req.params.id);
          
          // Sync to Firestore
          await syncPoolToFirestore(req.params.id);

          res.json({ success: true });
      } catch (error) {
          res.status(500).json({ error: (error as Error).message });
      }
  });

  // Delete pool
  apiRouter.delete("/pools/:id", requireAdmin, async (req, res) => {
      try {
          const poolId = req.params.id;
          let sqlitePoolId = poolId;
          let stableId = poolId;
          
          if (isNaN(Number(poolId))) {
            const pool = db.prepare("SELECT id, stable_id FROM pools WHERE stable_id = ? OR name = ?").get(poolId, poolId) as any;
            if (pool) {
              sqlitePoolId = pool.id;
              stableId = pool.stable_id;
            }
          } else {
            const pool = db.prepare("SELECT stable_id FROM pools WHERE id = ?").get(poolId) as any;
            if (pool) stableId = pool.stable_id;
          }

          db.prepare("DELETE FROM snapshots WHERE pool_id = ?").run(sqlitePoolId);
          db.prepare("DELETE FROM pools WHERE id = ?").run(sqlitePoolId);
          
          // Sync to Firestore
          const activeDb = await getWorkingFirestore();
          if (activeDb) {
            await activeDb.collection('pools').doc(stableId).delete();
          }

          res.json({ success: true });
      } catch (error) {
          res.status(500).json({ error: (error as Error).message });
      }
  });

  // Delete snapshot
  apiRouter.delete("/snapshots/:id", requireAdmin, async (req, res) => {
      try {
          const id = parseInt(req.params.id);
          if (isNaN(id)) {
              return res.status(400).json({ error: "Invalid snapshot ID" });
          }
          
          const snapshot = db.prepare("SELECT * FROM snapshots WHERE id = ?").get(id) as any;
          if (snapshot) {
            const pool = db.prepare("SELECT stable_id FROM pools WHERE id = ?").get(snapshot.pool_id) as any;
            const stableId = pool ? pool.stable_id : String(snapshot.pool_id);

            db.prepare("DELETE FROM snapshots WHERE id = ?").run(id);
            
            // Sync to Firestore
            const activeDb = await getWorkingFirestore();
            if (activeDb) {
              const snapRef = activeDb.collection('pools').doc(stableId).collection('snapshots');
              // Use the deterministic ID based on timestamp
              const deterministicId = snapshot.snapshot_datetime.replace(/[^0-9]/g, '');
              await snapRef.doc(deterministicId).delete();
            }
          }
          
          res.json({ success: true });
      } catch (error) {
          res.status(500).json({ error: (error as Error).message });
      }
  });

  // Suggestions API
  apiRouter.post("/suggestions", (req, res) => {
    try {
      const { topic, message, attachment_name, attachment_data } = req.body;
      const user = (req as any).user;
      
      if (!topic || !message) {
        return res.status(400).json({ error: "Topic and message are required" });
      }

      const result = db.prepare(`
        INSERT INTO suggestions (user_id, user_email, topic, message, attachment_name, attachment_data)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(user?.id || null, user?.email || 'Guest', topic, message, attachment_name || null, attachment_data || null);

      console.log(`[SUGGESTION] New submission from ${user?.email || 'Guest'}. ID: ${result.lastInsertRowid}, Attachment: ${attachment_name || 'None'}`);

      // Simulate sending email to administrator
      console.log(`
============================================================
[EMAIL NOTIFICATION] TO: administrator@lpanalytics.com
FROM: system@lpanalytics.com
SUBJECT: New Suggestion: ${topic}

A new suggestion has been submitted by ${user?.email || 'a Guest'}.

Topic: ${topic}
Message: ${message}
Attachment: ${attachment_name || 'None'}

Suggestion ID: ${result.lastInsertRowid}
============================================================
      `);
      
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (error) {
      console.error("[SUGGESTION ERROR]", error);
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Final API 404 handler
  apiRouter.use((req, res) => {
    console.log(`[API 404 DEBUG] ${req.method} ${req.url} - Not matched in apiRouter`);
    res.status(404).json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Debug handler for internal AI Studio upload paths
  app.all("/_/upload/*", (req, res) => {
    console.log(`[UPLOAD DEBUG] ${req.method} ${req.url} - Internal AI Studio path detected`);
    res.status(204).end();
  });

  app.use("/api", apiRouter);

  // Error handler for API routes to ensure JSON response instead of HTML
  app.use("/api", (err: any, req: Request, res: Response, next: NextFunction) => {
    console.error(`[API ERROR] ${req.method} ${req.url}:`, err);
    res.status(err.status || 500).json({
      error: err.message || "Internal Server Error",
      details: err.details || null
    });
  });

  // Vite middleware for development or fallback
  const distPath = path.join(__dirname, "dist");
  const hasDist = fs.existsSync(path.join(distPath, "index.html"));
  
  console.log(`[SERVER] dist folder exists: ${hasDist}`);

  console.log("[SERVER] Initializing Vite...");
  // 1. Initialize Vite
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });
  console.log("[SERVER] Vite initialized.");

  // 2. Static files from dist (if they exist)
  if (hasDist) {
    console.log("[SERVER] Enabling static file serving from dist");
    app.use(express.static(distPath, { index: false }));
  }

  // 3. Vite middlewares
  app.use(vite.middlewares);

  // 4. SPA Fallback
  app.get("*", (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    
    if (hasDist) {
      console.log(`[SERVER] SPA Fallback: Serving index.html for ${req.url}`);
      return res.sendFile(path.join(distPath, "index.html"));
    }
    
    next();
  });

  // Run initial sync on startup
  const runStartupSync = async () => {
    try {
      const poolCount = db.prepare("SELECT COUNT(*) as count FROM pools").get() as any;
      const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
      
      if (poolCount.count === 0 || userCount.count === 0) {
        console.log("[SERVER] Database is empty or missing users, pulling from Firestore...");
        await syncFromFirestoreToSQLite();
        console.log("[SERVER] Initial pull from Firestore complete.");
      } else {
        console.log("[SERVER] Database has data, skipping initial pull.");
      }
      await recalculateAllPoolDeltas();
    } catch (err) {
      console.error("[SERVER] Startup sync failed:", err);
      // Still try to recalculate if possible
      recalculateAllPoolDeltas().catch(console.error);
    }
  };
  
  // Await startup sync before starting the server to ensure data is ready
  await runStartupSync();

  // Admin: Force recalculate all deltas
app.post("/api/admin/recalculate", requireAdmin, async (req, res) => {
  try {
    await recalculateAllPoolDeltas();
    res.json({ success: true, message: "Recalculation and sync started in background" });
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

// Admin: Pull from Cloud (Firestore -> SQLite)
app.post("/api/admin/pull-from-cloud", requireAdmin, async (req, res) => {
  try {
    const result = await syncFromFirestoreToSQLite();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    
    // Sync system pools in background after server starts
    syncSystemPools().catch(err => {
      console.error("[SERVER] Background sync failed:", err);
    });
    
    // Sync historical prices for range analysis
    syncHistoricalPrices().catch(err => {
      console.error("[SERVER] Historical price sync failed:", err);
    });

    // Auto-sync wallets every 6 hours
    setInterval(() => {
      autoSyncAllWallets().catch(err => console.error("[SERVER] Auto-sync failed:", err));
    }, 6 * 60 * 60 * 1000);
    
    // Run once on start
    autoSyncAllWallets().catch(err => console.error("[SERVER] Initial auto-sync failed:", err));
  });
}

startServer().catch(err => {
  console.error("[SERVER] Fatal error during startup:", err);
});
console.log("[SERVER] server.ts finished loading.");
