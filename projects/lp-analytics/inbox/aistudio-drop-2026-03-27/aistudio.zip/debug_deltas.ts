import Database from "better-sqlite3";
const db = new Database("lp_analytics.db");

function calculatePoolDeltas(snapshots: any[]) {
  const getDelta = (offset: number) => {
    if (!snapshots || snapshots.length < 2) {
      console.log(`[DELTA] Pool has < 2 snapshots (${snapshots?.length || 0}), returning 0`);
      return 0;
    }
    const latest = snapshots[0];
    const latestFees = typeof latest.total_fees === 'number' ? latest.total_fees : parseFloat(String(latest.total_fees).replace(',', '.'));
    let baselineIndex = Math.min(offset, snapshots.length - 1);
    let prev: any = snapshots[baselineIndex];
    let prevFees = prev ? (typeof prev.total_fees === 'number' ? prev.total_fees : parseFloat(String(prev.total_fees).replace(',', '.'))) : 0;
    while (baselineIndex < snapshots.length - 1 && (isNaN(prevFees) || prevFees <= 0)) {
      baselineIndex++;
      prev = snapshots[baselineIndex];
      prevFees = prev ? (typeof prev.total_fees === 'number' ? prev.total_fees : parseFloat(String(prev.total_fees).replace(',', '.'))) : 0;
    }
    if (!isNaN(prevFees) && !isNaN(latestFees)) {
      if (prevFees === 0) {
        const res = latestFees > 0 ? 100 : 0;
        console.log(`[DELTA] Offset ${offset}: latest=${latestFees}, prev=0 (at index ${baselineIndex}), result=${res}`);
        return res;
      }
      const d = ((latestFees - prevFees) / prevFees) * 100;
      const res = isFinite(d) ? d : 0;
      console.log(`[DELTA] Offset ${offset}: latest=${latestFees}, prev=${prevFees} (at index ${baselineIndex}), result=${res}`);
      return res;
    }
    return 0;
  };
  return {
    delta_1: getDelta(1),
    delta_3: getDelta(3),
    delta_7: getDelta(7)
  };
}

const pools = db.prepare("SELECT id, name FROM pools").all() as any[];
for (const pool of pools) {
  const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(pool.id) as any[];
  console.log(`Pool: ${pool.name} (ID: ${pool.id}), Snapshots: ${snapshots.length}`);
  const deltas = calculatePoolDeltas(snapshots);
  console.log(`Deltas:`, deltas);
}
