
import Database from 'better-sqlite3';
const db = new Database('lp_analytics.db');

console.log("--- POOLS ---");
const pools = db.prepare("SELECT id, name, latest_total_fees, delta_1, snapshots_count FROM pools").all();
console.table(pools);

console.log("\n--- SNAPSHOTS (Latest 10) ---");
const snapshots = db.prepare("SELECT id, pool_id, total_fees, snapshot_datetime FROM snapshots ORDER BY id DESC LIMIT 10").all();
console.table(snapshots);

console.log("\n--- SNAPSHOTS COUNT PER POOL ---");
const counts = db.prepare("SELECT pool_id, COUNT(*) as count FROM snapshots GROUP BY pool_id").all();
console.table(counts);
