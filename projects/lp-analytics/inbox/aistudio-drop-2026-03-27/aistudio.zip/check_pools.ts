import Database from "better-sqlite3";
const db = new Database("lp_analytics.db");
const pools = db.prepare("SELECT * FROM pools").all();
console.log(JSON.stringify(pools, null, 2));
