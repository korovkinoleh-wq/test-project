import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function test() {
  console.log("Starting Firebase Admin SDK Multi-Database Test...");
  
  let firebaseConfig: any = {};
  try {
    const configPath = path.join(__dirname, "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    }
  } catch (e) {}

  const projectId = firebaseConfig.projectId;
  const namedDbId = firebaseConfig.firestoreDatabaseId;

  const dbsToTest = [
    { id: '(default)', label: 'Default Database' },
    { id: namedDbId, label: `Named Database (${namedDbId})` }
  ];

  for (const dbInfo of dbsToTest) {
    console.log(`\n--- Testing ${dbInfo.label} ---`);
    try {
      const appName = `app-${dbInfo.id}-${Date.now()}`;
      const app = admin.initializeApp({
        projectId: projectId
      }, appName);
      
      const db = getFirestore(app, dbInfo.id === '(default)' ? undefined : dbInfo.id);
      const healthRef = db.collection('_health').doc('test-' + dbInfo.id);
      
      console.log(`Attempting write to ${dbInfo.id}/_health/test...`);
      await healthRef.set({ timestamp: new Date().toISOString() });
      console.log(`SUCCESS for ${dbInfo.label}`);
      
      await app.delete();
    } catch (err: any) {
      console.error(`FAILED for ${dbInfo.label}:`, err.message);
    }
  }
}

test();
