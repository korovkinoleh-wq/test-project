import Database from "better-sqlite3";
const db = new Database("database.sqlite");

console.log("--- POOLS ---");
const pools = db.prepare("SELECT id, name, latest_total_fees, delta_1, delta_3, delta_7 FROM pools").all();
console.log(JSON.stringify(pools, null, 2));

console.log("\n--- SNAPSHOTS ---");
const snapshots = db.prepare("SELECT * FROM snapshots ORDER BY pool_id, snapshot_datetime DESC").all();
console.log(JSON.stringify(snapshots, null, 2));
