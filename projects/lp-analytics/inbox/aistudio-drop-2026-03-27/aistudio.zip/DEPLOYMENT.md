# LP Analytics - Deployment Guide

This application is ready to be deployed using Docker.

## Prerequisites
- Docker and Docker Compose installed on your server.
- Google OAuth credentials (Client ID and Secret).

## Deployment Steps

1. **Prepare Environment Variables**
   Create a `.env` file in the root directory and fill it with your data:
   ```env
   VITE_GOOGLE_CLIENT_ID=your_google_client_id
   GOOGLE_CLIENT_SECRET=your_google_client_secret
   JWT_SECRET=your_random_secret_string
   APP_URL=https://your-domain.com
   ```

2. **Build and Start the Container**
   Run the following command:
   ```bash
   docker-compose up -d --build
   ```

3. **Access the App**
   The app will be available at `http://your-server-ip:3000` (or through your reverse proxy).

## Database
The database is stored in `lp_analytics.db` in the root directory. It is mounted as a volume in Docker Compose, so your data will persist even if the container is restarted or updated.
