import fetch from "node-fetch";

async function test() {
  console.log("Checking Service Account Email via Metadata Server...");
  
  try {
    const response = await fetch("http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/email", {
      headers: { "Metadata-Flavor": "Google" }
    });
    if (response.ok) {
      const email = await response.text();
      console.log("Service Account Email:", email);
    } else {
      console.log("Metadata server check: FAILED (not on GCP?)");
    }
  } catch (e: any) {
    console.log("Metadata server check: FAILED:", e.message);
  }
}

test();
