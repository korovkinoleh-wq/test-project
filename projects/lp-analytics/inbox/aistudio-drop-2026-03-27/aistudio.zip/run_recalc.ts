import Database from 'better-sqlite3';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import * as fs from 'fs';

const db = new Database('lp_analytics.db');
const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));

if (!process.env.GOOGLE_CLOUD_PROJECT) {
  process.env.GOOGLE_CLOUD_PROJECT = config.projectId;
}

const app = initializeApp({
  projectId: config.projectId
});

const activeDb = getFirestore(app, config.firestoreDatabaseId);

function calculatePoolDeltas(snapshots: any[]) {
  if (!snapshots || snapshots.length < 2) return { delta_1: 0, delta_3: 0, delta_7: 0 };
  
  const latest = snapshots[0];
  const latestFees = latest.total_fees || 0;
  
  const getDelta = (offsetDays: number) => {
    const targetDate = new Date(new Date(latest.snapshot_datetime).getTime() - (offsetDays * 24 * 60 * 60 * 1000));
    let baseline = snapshots.find(s => new Date(s.snapshot_datetime) <= targetDate);
    if (!baseline) baseline = snapshots[snapshots.length - 1];
    
    const oldFees = baseline.total_fees || 0;
    if (oldFees === 0) return latestFees > 0 ? 100 : 0;
    return ((latestFees - oldFees) / oldFees) * 100;
  };

  return {
    delta_1: getDelta(1),
    delta_3: getDelta(3),
    delta_7: getDelta(7)
  };
}

async function recalculateAllPoolDeltas() {
  console.log("[ADMIN] Starting full delta recalculation...");
  const pools = db.prepare("SELECT * FROM pools").all() as any[];
  
  for (const pool of pools) {
    const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(pool.id) as any[];
    const deltas = calculatePoolDeltas(snapshots);
    
    db.prepare(`
      UPDATE pools 
      SET delta_1 = ?, delta_3 = ?, delta_7 = ?
      WHERE id = ?
    `).run(deltas.delta_1, deltas.delta_3, deltas.delta_7, pool.id);
    
    console.log(`[ADMIN] Recalculated pool ${pool.name}: D1=${deltas.delta_1.toFixed(2)}%`);
  }
  console.log("[ADMIN] Recalculation complete.");
}

recalculateAllPoolDeltas();
