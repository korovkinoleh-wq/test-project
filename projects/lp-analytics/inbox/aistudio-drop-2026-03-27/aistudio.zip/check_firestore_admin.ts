import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import * as fs from 'fs';

// Check if service account exists, if not use default credentials
// In this environment, we usually don't have a service account file,
// but we might have the project ID.
// Actually, I'll just use the firebase-applet-config.json to get the projectId
const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));

const app = admin.apps.length ? admin.app() : admin.initializeApp({
  projectId: config.projectId
});

const db = getFirestore(app, config.firestoreDatabaseId);

async function checkFirestore() {
  const poolsRef = db.collection('pools');
  const snapshot = await poolsRef.get();
  snapshot.forEach(doc => {
    const data = doc.data();
    console.log(`Pool: ${data.name} (ID: ${doc.id})`);
    console.log(`  delta_1: ${data.delta_1}, delta_3: ${data.delta_3}, delta_7: ${data.delta_7}`);
    console.log(`  latest_total_fees: ${data.latest_total_fees}`);
  });
}

checkFirestore();
