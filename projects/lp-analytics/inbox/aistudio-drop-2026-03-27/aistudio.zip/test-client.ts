import { initializeApp } from "firebase/app";
import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function test() {
  console.log("Starting Firebase Client SDK test...");
  
  let firebaseConfig: any = {};
  try {
    const configPath = path.join(__dirname, "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    }
  } catch (e) {}

  try {
    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    
    console.log("Client SDK initialized.");
    
    const healthRef = doc(db, '_health', 'client-test');
    console.log("Attempting write to _health/client-test...");
    
    await setDoc(healthRef, { 
      timestamp: new Date().toISOString(),
      source: 'client-test'
    });
    
    console.log("Write SUCCESSFUL!");
    
    const snap = await getDoc(healthRef);
    console.log("Read SUCCESSFUL:", snap.data());
    
  } catch (err: any) {
    console.error("CLIENT TEST FAILED:", err.message);
    if (err.stack) console.error(err.stack);
  }
}

test();
