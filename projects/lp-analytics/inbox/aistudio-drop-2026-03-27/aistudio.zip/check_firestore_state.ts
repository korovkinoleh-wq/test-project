
import admin from 'firebase-admin';
import fs from 'fs';
import path from 'path';
import { getFirestore } from 'firebase-admin/firestore';

const configPath = 'firebase-applet-config.json';
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

if (firebaseConfig.projectId) {
  process.env.GOOGLE_CLOUD_PROJECT = firebaseConfig.projectId;
}

if (admin.apps.length === 0) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId
  });
}

const db = getFirestore(firebaseConfig.firestoreDatabaseId || '(default)');

async function checkFirestore() {
  console.log("--- FIRESTORE POOLS ---");
  const poolsSnap = await db.collection('pools').get();
  const pools = poolsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as any[];
  console.table(pools.map((p: any) => ({
    id: p.id,
    name: p.name,
    latest_total_fees: p.latest_total_fees,
    snapshots_count: p.snapshots_count,
    delta_1: p.delta_1
  })));

  for (const pool of pools.slice(0, 5)) {
    console.log(`\n--- SNAPSHOTS FOR ${pool.name} (Latest 5) ---`);
    const snapsSnap = await db.collection('pools').doc(pool.id).collection('snapshots').orderBy('snapshot_datetime', 'desc').limit(5).get();
    const snaps = snapsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    console.table(snaps);
  }
}

checkFirestore().catch(console.error);
