
import Database from 'better-sqlite3';
const db = new Database('lp_analytics.db');
const nonZero = db.prepare("SELECT COUNT(*) as count FROM snapshots WHERE total_fees > 0").get();
console.log(`Snapshots with non-zero fees: ${nonZero.count}`);
const allSnaps = db.prepare("SELECT COUNT(*) as count FROM snapshots").get();
console.log(`Total snapshots: ${allSnaps.count}`);
const pools = db.prepare("SELECT id, name, latest_total_fees FROM pools").all();
console.log("Pools with latest_total_fees:", JSON.stringify(pools, null, 2));
