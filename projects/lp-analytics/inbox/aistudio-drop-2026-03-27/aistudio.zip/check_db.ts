
import Database from 'better-sqlite3';
const db = new Database('lp_analytics.db');

async function run() {
  const pools = db.prepare("SELECT * FROM pools").all();
  console.log("Pools:");
  console.table(pools.map(p => ({
    id: p.id,
    name: p.name,
    d1: p.delta_1,
    d3: p.delta_3,
    d7: p.delta_7,
    latest_fees: p.latest_total_fees
  })));

  const snapshots = db.prepare("SELECT * FROM snapshots ORDER BY pool_id, snapshot_datetime DESC").all();
  console.log("\nSnapshots:");
  console.table(snapshots.map(s => ({
    pool_id: s.pool_id,
    fees: s.total_fees,
    date: s.snapshot_datetime
  })));
}

run().catch(console.error);
