import { Firestore } from "@google-cloud/firestore";

async function test() {
  try {
    const db = new Firestore();
    const collections = await db.listCollections();
    console.log("Collections:", collections.map(c => c.id));
    console.log("Project ID:", db.projectId);
    console.log("Database ID:", db.databaseId);
  } catch (e) {
    console.error(e);
  }
}
test();
