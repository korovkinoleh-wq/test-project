import jwt from 'jsonwebtoken';
import fetch from 'node-fetch';

const JWT_SECRET = "lp-analytics-secret-key-2026";
const user = { id: "EBWPiMfNuZZACirKwPn2Jw7cp6F2", email: "olegglasstrader@gmail.com", role: "admin" };
const token = jwt.sign(user, JWT_SECRET, { expiresIn: '1h' });

async function check() {
  const poolId = "uniswap-eth-usdc-uniswap-eth-usdc"; // Example stable ID
  const response = await fetch(`http://localhost:3000/api/admin/debug-firestore/${poolId}`, {
    headers: {
      'Cookie': `auth_token=${token}`
    }
  });
  const data = await response.json();
  console.log('Firestore Debug Data:', JSON.stringify(data, null, 2));
}

check().catch(console.error);
