import admin from "firebase-admin";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function test() {
  console.log("Checking Service Account Info...");
  
  let firebaseConfig: any = {};
  try {
    const configPath = path.join(__dirname, "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
    }
  } catch (e) {}

  const projectId = firebaseConfig.projectId;

  try {
    const app = admin.initializeApp({
      projectId: projectId
    }, "info-app-" + Date.now());
    
    // Try to get the service account email via metadata server or similar
    // Actually, we can just try to list users or something to see if we have admin rights
    try {
      const users = await app.auth().listUsers(1);
      console.log("Auth Admin check: SUCCESS (can list users)");
    } catch (e: any) {
      console.log("Auth Admin check: FAILED:", e.message);
    }

    // Try to get the project ID from the app
    console.log("App Project ID:", app.options.projectId);
    
    await app.delete();
  } catch (err: any) {
    console.error("INFO TEST FAILED:", err.message);
  }
}

test();
