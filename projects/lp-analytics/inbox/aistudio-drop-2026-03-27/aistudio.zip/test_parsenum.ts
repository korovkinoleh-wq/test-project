
function getField(obj: any, keys: string[]) {
  if (!obj) return undefined;
  
  const wrappers = ['fields', 'data', '_data', 'value'];
  for (const wrapper of wrappers) {
    if (obj[wrapper] && typeof obj[wrapper] === 'object' && !Array.isArray(obj[wrapper])) {
      const result = getField(obj[wrapper], keys);
      if (result !== undefined) return result;
    }
  }

  for (const key of keys) {
    if (obj[key] !== undefined && obj[key] !== null) return obj[key];
  }
  
  const objKeys = Object.keys(obj);
  for (const key of keys) {
    const match = objKeys.find(k => k.toLowerCase() === key.toLowerCase());
    if (match && obj[match] !== undefined && obj[match] !== null) return obj[match];
  }
  
  return undefined;
}

function parseNum(val: any): number {
  if (val === null || val === undefined) return 0;
  const originalVal = val;
  let result = 0;

  if (typeof val === 'object' && !Array.isArray(val)) {
    const inner = getField(val, [
      'value', 'amount', 'val', 'total', 'total_fees', 'fees', 
      'integerValue', 'doubleValue', 'numberValue', 'stringValue',
      'decimalValue', 'low', 'high'
    ]);
    
    if (inner !== undefined && inner !== val) {
      result = parseNum(inner);
    } else if ('low' in val && 'high' in val) {
      if (typeof val.high === 'number' && val.high !== 0) {
        result = val.low + (val.high * 4294967296);
      } else {
        result = val.low;
      }
    } else if (val._seconds !== undefined) {
      return 0;
    } else {
      for (const key in val) {
        if (typeof val[key] === 'number') return val[key];
        if (typeof val[key] === 'string' && !isNaN(parseFloat(val[key]))) return parseFloat(val[key]);
      }
    }
  } else if (typeof val === 'number') {
    result = val;
  } else if (typeof val === 'string') {
    let cleaned = val.trim();
    cleaned = cleaned.replace(/[^\d.,-]/g, '');
    
    if (cleaned.includes(',') && !cleaned.includes('.')) {
      const commaCount = (cleaned.match(/,/g) || []).length;
      const lastCommaIndex = cleaned.lastIndexOf(',');
      const charsAfterComma = cleaned.length - lastCommaIndex - 1;
      if (commaCount === 1 && charsAfterComma <= 2) {
        cleaned = cleaned.replace(',', '.');
      } else {
        cleaned = cleaned.replace(/,/g, '');
      }
    } else if (cleaned.includes(',') && cleaned.includes('.')) {
      if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
        cleaned = cleaned.replace(/\./g, '').replace(',', '.');
      } else {
        cleaned = cleaned.replace(/,/g, '');
      }
    }
    const parsed = parseFloat(cleaned);
    result = isNaN(parsed) ? 0 : parsed;
  }

  return result;
}

// Test cases
console.log("Test 1 (Firestore double):", parseNum({ doubleValue: 123.45 }));
console.log("Test 2 (Firestore integer):", parseNum({ integerValue: "123" }));
console.log("Test 3 (Nested Firestore):", parseNum({ fields: { total_fees: { doubleValue: 123.45 } } }));
console.log("Test 4 (European format):", parseNum("1.234,56"));
console.log("Test 5 (US format):", parseNum("1,234.56"));
console.log("Test 6 (String with currency):", parseNum("$1,234.56"));
console.log("Test 7 (Firestore object with value):", parseNum({ value: 123.45 }));
console.log("Test 8 (Firestore object with amount):", parseNum({ amount: "123.45" }));
console.log("Test 9 (Firestore object with total):", parseNum({ total: 123.45 }));
console.log("Test 10 (Firestore object with total_fees):", parseNum({ total_fees: 123.45 }));
console.log("Test 11 (Firestore object with fees):", parseNum({ fees: 123.45 }));
console.log("Test 12 (Firestore object with val):", parseNum({ val: 123.45 }));
console.log("Test 13 (Firestore object with decimalValue):", parseNum({ decimalValue: "123.45" }));
console.log("Test 14 (Firestore object with numberValue):", parseNum({ numberValue: 123.45 }));
console.log("Test 15 (Firestore object with stringValue):", parseNum({ stringValue: "123.45" }));
console.log("Test 16 (Firestore object with low/high):", parseNum({ low: 123, high: 0 }));
console.log("Test 17 (Firestore object with low/high non-zero):", parseNum({ low: 123, high: 1 }));
