import React from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import PoolDetail from './components/PoolDetail';
import PoolForm from './components/PoolForm';
import YieldCalculator from './components/YieldCalculator';
import Strategy from './components/Strategy';
import Ranges from './components/Ranges';
import SnapshotModal from './components/SnapshotModal';
import LandingPage from './components/LandingPage';
import AdminPanel from './components/AdminPanel';
import Overview from './components/Overview';
import TokenCalculator from './components/TokenCalculator';
import Training from './components/Training';
import SubscriptionPage from './components/SubscriptionPage';
import { DisclaimerModal } from './components/DisclaimerModal';
import { AuthProvider, useAuth } from './components/AuthContext';
import { Pool, Snapshot, User } from './types';
import { db } from './firebase';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs,
  writeBatch,
  serverTimestamp,
  getDoc
} from 'firebase/firestore';

function AppContent() {
  const { user, loading: authLoading, acceptDisclaimer } = useAuth();
  const [activeTab, setActiveTab] = React.useState(user?.role === 'admin' ? 'dashboard' : 'overview');
  const [pools, setPools] = React.useState<Pool[]>([]);
  const [selectedPoolId, setSelectedPoolId] = React.useState<string | number | null>(null);
  const [poolDetails, setPoolDetails] = React.useState<{ pool: Pool, snapshots: Snapshot[] } | null>(null);
  const [isSnapshotModalOpen, setIsSnapshotModalOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  // Set default tab for guests
  React.useEffect(() => {
    if (user && user.role !== 'admin' && activeTab === 'admin') {
      setActiveTab('overview');
    }
  }, [user, activeTab]);

  // Real-time pools listener
  React.useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'pools'), orderBy('name'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const poolsData: Pool[] = [];
      
      for (const poolDoc of snapshot.docs) {
        const data = poolDoc.data() as any;
        const poolId = poolDoc.id;
        
        // Use the pre-calculated latest_total_fees from the pool document
        // This is MUCH faster than fetching snapshots for every pool in the listener
        const totalFees = data.latest_total_fees || 0;
        const lastUpdate = data.lastUpdate || data.latest_snapshot_datetime || data.start_date;
        
        // Calculate metrics
        const startDate = new Date(data.start_date);
        const now = new Date();
        const daysActive = Math.max(0.01, (now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
        const aprSinceStart = data.start_liquidity_usd > 0 
          ? (totalFees / data.start_liquidity_usd) * (365 / daysActive) * 100
          : 0;

        const feesPerDayAvg = totalFees / daysActive;
        
        // Diagnostic log for deltas
        if (data.name.includes('AERODROME')) {
          console.log(`[FRONTEND] Pool ${data.name} deltas:`, {
            d1: data.delta_1,
            d3: data.delta_3,
            d7: data.delta_7,
            raw: data
          });
        }
        
        poolsData.push({
          id: poolId,
          ...data,
          totalFees,
          daysActive,
          aprSinceStart,
          apr7D: aprSinceStart, // Fallback
          feesPerDayAvg,
          feesPerDay7D: feesPerDayAvg, // Fallback
          lastUpdate,
          delta_1: data.delta_1,
          delta_3: data.delta_3,
          delta_7: data.delta_7,
          deltas: { 
            "1": data.delta_1 ?? 0, 
            "3": data.delta_3 ?? 0, 
            "7": data.delta_7 ?? 0 
          }
        } as Pool);
      }
      
      setPools(poolsData);
      setLoading(false);
    }, (error) => {
      console.error("Firestore listener error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const fetchPoolDetails = async (id: string | number) => {
    try {
      const poolDoc = await getDoc(doc(db, 'pools', String(id)));
      if (!poolDoc.exists()) return;
      
      const snapshotsQ = query(collection(db, `pools/${id}/snapshots`), orderBy('snapshot_datetime', 'desc'));
      const snapshotsSnap = await getDocs(snapshotsQ);
      const snapshots = snapshotsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Snapshot));
      
      setPoolDetails({
        pool: { id: poolDoc.id, ...poolDoc.data() } as Pool,
        snapshots
      });
    } catch (err) {
      console.error('Failed to fetch pool details:', err);
    }
  };

  if (authLoading) return (
    <div className="min-h-screen bg-[#E4E3E0] flex items-center justify-center">
      <div className="font-mono text-xs uppercase tracking-[0.5em] animate-pulse">Authenticating...</div>
    </div>
  );

  if (!user || (user.role === 'pending' && !user.id)) {
    return <LandingPage />;
  }

  const handleSelectPool = (pool: Pool) => {
    setSelectedPoolId(pool.id);
    fetchPoolDetails(pool.id);
    setActiveTab('pool-detail');
  };

  const handleSavePool = async (poolData: Partial<Pool>) => {
    try {
      const response = await fetch('/api/pools', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(poolData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to save pool');
      }

      setActiveTab('dashboard');
    } catch (err) {
      console.error('Failed to save pool:', err);
      alert(`Failed to save pool: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleSaveSnapshot = async (snapshotData: any) => {
    try {
      const response = await fetch('/api/snapshots', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(snapshotData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to save snapshot');
      }

      if (selectedPoolId) await fetchPoolDetails(selectedPoolId);
      setIsSnapshotModalOpen(false);
    } catch (err) {
      console.error('Failed to save snapshot:', err);
      alert(`Failed to save snapshot: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleDeletePool = async (id: string | number) => {
    if (!window.confirm('Are you sure you want to delete this pool and all its snapshots?')) return;
    try {
      const response = await fetch(`/api/pools/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete pool');
      }

      setActiveTab('dashboard');
      setSelectedPoolId(null);
    } catch (err) {
      console.error('Failed to delete pool:', err);
      alert(`Failed to delete pool: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleDeleteSnapshot = async (id: string | number) => {
    if (!selectedPoolId) return;
    try {
      const response = await fetch(`/api/snapshots/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete snapshot');
      }

      await fetchPoolDetails(selectedPoolId);
    } catch (err) {
      console.error('Failed to delete snapshot:', err);
      alert(`Failed to delete snapshot: ${err instanceof Error ? err.message : 'Unknown error'}`);
    }
  };

  const handleBulkSave = async (snapshots: { pool_id: string | number, total_fees: number }[]) => {
    try {
      // 1. Save to Backend (SQLite + Firestore Sync)
      const response = await fetch('/api/snapshots/bulk-save-v3', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ snapshots })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to save to backend');
      }

      // 2. Refresh local details if needed
      if (selectedPoolId) await fetchPoolDetails(selectedPoolId);
      return true;
    } catch (err) {
      console.error('Failed to save bulk snapshots:', err);
      throw err; 
    }
  };

  const renderContent = () => {
    if (loading) return (
      <div className="flex items-center justify-center h-[60vh]">
        <div className="font-mono text-xs uppercase tracking-[0.5em] animate-pulse">Loading System Data...</div>
      </div>
    );

    switch (activeTab) {
      case 'overview':
        return <Overview />;
      case 'dashboard':
        return <Dashboard pools={pools} onSelectPool={handleSelectPool} onBulkSave={handleBulkSave} onRefresh={() => {}} />;
      case 'pool-detail':
        const pool = pools.find(p => p.id === selectedPoolId);
        if (!pool || !poolDetails) return null;
        return (
          <PoolDetail 
            pool={pool} 
            snapshots={poolDetails.snapshots} 
            onBack={() => setActiveTab('dashboard')}
            onAddSnapshot={() => setIsSnapshotModalOpen(true)}
            onDelete={handleDeletePool}
            onDeleteSnapshot={handleDeleteSnapshot}
          />
        );
      case 'add-pool':
        if (user?.role !== 'admin') return <Dashboard pools={pools} onSelectPool={handleSelectPool} onBulkSave={handleBulkSave} onRefresh={() => {}} />;
        return <PoolForm onSave={handleSavePool} onCancel={() => setActiveTab('dashboard')} />;
      case 'calculator':
        return <YieldCalculator pools={pools} />;
      case 'strategy':
        return <Strategy pools={pools} />;
      case 'ranges':
        return <Ranges />;
      case 'admin':
        return <AdminPanel />;
      case 'token-calculator':
        return <TokenCalculator />;
      case 'training':
        return <Training />;
      default:
        return <Dashboard pools={pools} onSelectPool={handleSelectPool} onBulkSave={handleBulkSave} onRefresh={() => {}} />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
      {isSnapshotModalOpen && selectedPoolId && (
        <SnapshotModal 
          poolId={selectedPoolId} 
          onSave={handleSaveSnapshot} 
          onClose={() => setIsSnapshotModalOpen(false)} 
        />
      )}
      <DisclaimerModal 
        isOpen={!!user && !user.has_accepted_disclaimer}
        onClose={() => {}} // Mandatory, can't close without accepting
        onAccept={acceptDisclaimer}
        isMandatory={true}
      />
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
