export interface Pool {
  id: string | number;
  name: string;
  network: string;
  pair: string;
  fee_percent: number;
  min_range: number;
  max_range: number;
  start_liquidity_usd: number;
  start_price?: number;
  start_date: string;
  latest_total_fees?: number;
  latest_snapshot_datetime?: string;
  _sync_complete?: boolean;
  // Calculated fields
  daysActive?: number;
  totalFees?: number;
  aprSinceStart?: number;
  apr1D?: number;
  apr7D?: number;
  feesPerDay7D?: number;
  feesPerDayAvg?: number;
  lastUpdate?: string;
  lastDeltaPct?: number;
  deltas?: Record<string, number>;
  delta_1?: number;
  delta_3?: number;
  delta_7?: number;
  snapshots_count?: number;
}

export interface Snapshot {
  id: string | number;
  pool_id: string | number;
  snapshot_datetime: string;
  total_fees: number;
}

export interface User {
  id?: string;
  email?: string;
  name?: string;
  picture?: string;
  role: 'admin' | 'approved' | 'pending' | 'pending_payment' | 'guest';
  subscription_type?: 'none' | 'monthly' | 'yearly' | 'manual' | 'free_test';
  subscription_expiry?: string;
  wallet_address?: string;
  last_payment_at?: string;
  has_accepted_disclaimer?: boolean;
}

export interface Payment {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  network: string;
  status: 'pending' | 'completed' | 'failed';
  subscription_type: 'monthly' | 'yearly';
  created_at: string;
}
