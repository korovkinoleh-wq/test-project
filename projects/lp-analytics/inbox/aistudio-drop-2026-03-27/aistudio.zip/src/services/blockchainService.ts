import { Pool } from '../types';

export async function syncPoolsWithWallet(): Promise<Record<number, string>> {
  try {
    const res = await fetch('/api/wallet-sync-v3', {
      method: 'GET',
      headers: { 
        'Accept': 'application/json'
      },
      credentials: 'include'
    });
    
    const text = await res.text();
    
    if (!res.ok) {
      try {
        const error = JSON.parse(text);
        throw new Error(error.error || `Server error (${res.status})`);
      } catch (e) {
        throw new Error(`Server error (${res.status}): ${text.slice(0, 100) || 'Empty response'}`);
      }
    }
    
    try {
      return JSON.parse(text);
    } catch (e) {
      console.error('Failed to parse sync response:', text);
      throw new Error('Invalid response from server. Check console for details.');
    }
  } catch (err) {
    console.error('Wallet sync error:', err);
    throw err;
  }
}
