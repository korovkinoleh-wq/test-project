import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Validate Connection to Firestore
async function testConnection() {
  try {
    // Attempt to read a non-existent doc to test connection
    await getDocFromServer(doc(db, '_connection_test_', 'ping'));
    console.log("[FIREBASE] Connection to Firestore verified.");
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("[FIREBASE ERROR] Please check your Firebase configuration. The client appears to be offline.");
    }
    // Other errors (like permission denied) are expected for this test path
  }
}

testConnection();
