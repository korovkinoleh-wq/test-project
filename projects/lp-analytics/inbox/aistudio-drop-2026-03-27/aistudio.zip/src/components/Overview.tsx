import React from 'react';
import { Calculator, Zap, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export default function Overview() {
  return (
    <div className="max-w-4xl space-y-12 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <h1 className="font-serif italic text-6xl tracking-tight leading-none">
          Liquidity management <br />
          without the noise.
        </h1>
        <p className="font-mono text-lg opacity-70 leading-relaxed max-w-2xl">
          LP Analytics is a specialized environment for monitoring and optimizing concentrated liquidity positions. 
          We remove DeFi complexity to provide clear and actionable data on fee accumulation, 
          capital efficiency, and rebalancing risks.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-[#141414]/10">
        <div className="space-y-4">
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest font-bold">
            <Calculator className="w-4 h-4" />
            Yield Calculation
          </div>
          <p className="font-mono text-xs opacity-50 leading-relaxed">
            Predict your yield based on historical fee data and customizable price ranges. 
            Our engine accounts for liquidity concentration and volume dynamics.
          </p>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest font-bold">
            <Zap className="w-4 h-4" />
            Strategy Optimization
          </div>
          <p className="font-mono text-xs opacity-50 leading-relaxed">
            Model rebalancing scenarios and liquidation risks. 
            Optimize your range to maximize fees while maintaining a safe health factor.
          </p>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest font-bold">
            <ShieldCheck className="w-4 h-4" />
            Risk Management
          </div>
          <p className="font-mono text-xs opacity-50 leading-relaxed">
            Track impermanent loss and price divergence in real-time. 
            Get clear signals on when to narrow or widen your liquidity bounds.
          </p>
        </div>
      </div>

    </div>
  );
}
