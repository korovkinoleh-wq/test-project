import React from 'react';
import { BookOpen, Zap, Target, RefreshCw, Info, Calculator, PieChart, TrendingUp } from 'lucide-react';

export default function Training() {
  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <section className="border-b border-[#141414] pb-12">
        <div className="flex flex-col sm:flex-row justify-between items-start gap-8 mb-6">
          <h1 className="text-6xl sm:text-8xl font-serif italic tracking-tighter">Обучение</h1>
        </div>
        <p className="text-xl opacity-70 max-w-2xl leading-relaxed">
          Простое руководство по работе системы аналитики ликвидности. Узнайте, как формируются стратегии и как использовать инструменты на максимум.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Как работают пулы */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[#141414]">
            <BookOpen className="w-6 h-6" />
            <h2 className="font-serif italic text-3xl">Как работают пулы</h2>
          </div>
          <div className="p-6 border border-[#141414] bg-white/30 space-y-4">
            <p className="text-sm leading-relaxed">
              Пулы ликвидности — это хранилища активов, где пользователи могут обменивать один токен на другой. За предоставление своих средств в эти хранилища вы получаете вознаграждение в виде комиссий от каждой сделки.
            </p>
            <p className="text-sm leading-relaxed font-medium">
              Ваша доходность зависит от объема торгов в пуле и вашей доли в нем.
            </p>
          </div>
        </div>

        {/* Базовые пулы */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[#141414]">
            <Zap className="w-6 h-6" />
            <h2 className="font-serif italic text-3xl">Базовые пулы</h2>
          </div>
          <div className="p-6 border border-[#141414] bg-white/30 space-y-4">
            <p className="text-sm leading-relaxed">
              В системе есть «Калибровочные пулы» — это реальные пулы с широким диапазоном цен. Они служат эталоном для всех расчетов.
            </p>
            <p className="text-sm leading-relaxed">
              На основе их данных (текущая ликвидность, объем комиссий) система вычисляет потенциальную доходность для ваших индивидуальных настроек.
            </p>
          </div>
        </div>

        {/* Калькулятор */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[#141414]">
            <Calculator className="w-6 h-6" />
            <h2 className="font-serif italic text-3xl">Калькулятор</h2>
          </div>
          <div className="p-6 border border-[#141414] bg-white/30 space-y-4">
            <p className="text-sm leading-relaxed">
              Инструмент для быстрого прогноза. Вы выбираете пул и вводите сумму инвестиций и диапазон цен.
            </p>
            <p className="text-sm leading-relaxed">
              Калькулятор мгновенно показывает ожидаемую доходность (APR) и сумму комиссий в день/месяц, основываясь на текущей рыночной ситуации.
            </p>
          </div>
        </div>

        {/* Стратегии */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-[#141414]">
            <Target className="w-6 h-6" />
            <h2 className="font-serif italic text-3xl">Стратегии</h2>
          </div>
          <div className="p-6 border border-[#141414] bg-white/30 space-y-4">
            <p className="text-sm leading-relaxed">
              Это комплексный план вашего портфеля. Здесь вы объединяете несколько пулов и настраиваете их параметры:
            </p>
            <ul className="list-disc list-inside text-sm space-y-2 opacity-80">
              <li>Общий капитал и его распределение (аллокация)</li>
              <li>Индивидуальные диапазоны для каждого актива</li>
              <li>Целевая доходность (система подскажет, достижима ли она)</li>
            </ul>
            <p className="text-xs opacity-50 uppercase tracking-widest pt-2 border-t border-[#141414]/10">
              Логика: Система берет данные из калибровочных пулов и «накладывает» на ваши настройки, чтобы выдать финальный результат.
            </p>
          </div>
        </div>
      </div>

      {/* Аллокация и Нелинейность */}
      <section className="space-y-8 pt-12 border-t border-[#141414]">
        <div className="flex items-center gap-3 text-[#141414]">
          <PieChart className="w-8 h-8" />
          <h2 className="font-serif italic text-5xl tracking-tighter">Аллокация и Доход</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="p-8 border border-[#141414] bg-white/30 space-y-6">
              <h3 className="font-serif italic text-2xl">Почему доход не равен аллокации?</h3>
              <p className="text-sm leading-relaxed">
                Аллокация — это то, как вы распределили свои **деньги** (капитал) между активами. Доход — это то, сколько **комиссий** генерирует каждый актив.
              </p>
              <p className="text-sm leading-relaxed">
                Разные пулы имеют разную доходность (APR). Если вы вложили 70% в BTC с низкой доходностью и 30% в ETH с высокой, то ETH может приносить почти половину всей прибыли, несмотря на меньшую долю в капитале.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-6 border-t border-[#141414]/10">
                <div className="space-y-2">
                  <div className="font-mono text-[10px] uppercase tracking-widest opacity-50">Пример аллокации (Капитал)</div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1 h-4 bg-[#141414]/10 rounded-full overflow-hidden flex">
                      <div className="h-full bg-[#141414]" style={{ width: '30%' }}></div>
                      <div className="h-full bg-[#141414]/40" style={{ width: '70%' }}></div>
                    </div>
                  </div>
                  <div className="flex justify-between font-mono text-[10px]">
                    <span>ETH: 30%</span>
                    <span>BTC: 70%</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="font-mono text-[10px] uppercase tracking-widest text-emerald-600">Пример дохода (Прибыль)</div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1 h-4 bg-emerald-500/10 rounded-full overflow-hidden flex">
                      <div className="h-full bg-emerald-500" style={{ width: '45%' }}></div>
                      <div className="h-full bg-emerald-500/40" style={{ width: '55%' }}></div>
                    </div>
                  </div>
                  <div className="flex justify-between font-mono text-[10px] text-emerald-600">
                    <span>ETH: 45%</span>
                    <span>BTC: 55%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="p-6 border border-[#141414] bg-[#141414] text-[#E4E3E0] space-y-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                <h3 className="font-serif italic text-xl">Конкретный пример</h3>
              </div>
              <div className="space-y-3 font-mono text-xs">
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="opacity-50">Капитал:</span>
                  <span>$10,000</span>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span>ETH (30%):</span>
                    <span>$3,000</span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Доход (50% APR):</span>
                    <span>$1,500/год</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span>BTC (70%):</span>
                    <span>$7,000</span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Доход (25% APR):</span>
                    <span>$1,750/год</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-white/20 flex justify-between font-bold">
                  <span>Итого доход:</span>
                  <span>$3,250/год</span>
                </div>
              </div>
              <p className="text-[10px] opacity-50 leading-relaxed italic">
                Как видите, ETH при вложении в 2.3 раза меньше, приносит почти столько же дохода, сколько BTC.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Summary Note */}
      <section className="p-8 border border-[#141414] bg-emerald-50 flex items-start gap-4">
        <Info className="w-6 h-6 text-emerald-600 shrink-0 mt-1" />
        <div>
          <h3 className="font-serif italic text-xl mb-2">Важно помнить</h3>
          <p className="text-sm opacity-70 leading-relaxed">
            Все расчеты являются прогнозными и основаны на исторических данных и текущем состоянии рынка. Всегда учитывайте риски волатильности криптоактивов.
          </p>
        </div>
      </section>
    </div>
  );
}
