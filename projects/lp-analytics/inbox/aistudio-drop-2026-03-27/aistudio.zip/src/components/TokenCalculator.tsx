import React, { useState, useEffect } from 'react';
import { Coins, RefreshCw, Calculator, DollarSign, CheckCircle2, AlertCircle, Wallet, ArrowDownCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface TokenData {
  symbol: string;
  name: string;
  amount: string;
  price: string;
  isManual: boolean;
  currentMarketPrice: number | null;
}

const INITIAL_TOKENS: TokenData[] = [
  { symbol: 'BTCUSDT', name: 'Bitcoin', amount: '', price: '', isManual: false, currentMarketPrice: null },
  { symbol: 'ETHUSDT', name: 'Ethereum', amount: '', price: '', isManual: false, currentMarketPrice: null },
  { symbol: 'AVAXUSDT', name: 'Avax', amount: '', price: '', isManual: false, currentMarketPrice: null },
  { symbol: 'USDCUSDT', name: 'USDC', amount: '', price: '', isManual: false, currentMarketPrice: null },
];

export default function TokenCalculator() {
  const [tokens, setTokens] = useState<TokenData[]>(INITIAL_TOKENS);
  const [debt, setDebt] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPrices = async () => {
    setLoading(true);
    setError(null);
    try {
      const symbols = tokens.map(t => t.symbol);
      const prices: { [key: string]: number } = {};
      
      await Promise.all(symbols.map(async (symbol) => {
        try {
          const response = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
          if (!response.ok) throw new Error(`Failed to fetch price for ${symbol}`);
          const data = await response.json();
          prices[symbol] = parseFloat(data.price);
        } catch (e) {
          console.warn(`Could not fetch price for ${symbol}, using fallback 1.0 for USDC or 0.0`);
          prices[symbol] = symbol === 'USDCUSDT' ? 1.0 : 0.0;
        }
      }));

      setTokens(prev => prev.map(token => ({
        ...token,
        currentMarketPrice: prices[token.symbol],
        // If not manual, update the price field to market price
        price: token.isManual ? token.price : (prices[token.symbol] || 0).toString()
      })));
    } catch (err) {
      console.error('Price fetch error:', err);
      setError('Failed to update market prices. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPrices();
    // Refresh every 60 seconds
    const interval = setInterval(fetchPrices, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleAmountChange = (index: number, value: string) => {
    const newTokens = [...tokens];
    newTokens[index].amount = value;
    setTokens(newTokens);
  };

  const handlePriceChange = (index: number, value: string) => {
    const newTokens = [...tokens];
    if (newTokens[index].isManual) {
      newTokens[index].price = value;
      setTokens(newTokens);
    }
  };

  const handleManualToggle = (index: number) => {
    const newTokens = [...tokens];
    newTokens[index].isManual = !newTokens[index].isManual;
    
    // If turning off manual, reset to market price
    if (!newTokens[index].isManual && newTokens[index].currentMarketPrice) {
      newTokens[index].price = newTokens[index].currentMarketPrice!.toString();
    }
    
    setTokens(newTokens);
  };

  const calculateTotal = (token: TokenData) => {
    const amount = parseFloat(token.amount) || 0;
    const price = parseFloat(token.price) || 0;
    return amount * price;
  };

  const assetsTotal = tokens.reduce((sum, token) => sum + calculateTotal(token), 0);
  const debtValue = parseFloat(debt) || 0;
  const netTotal = assetsTotal - debtValue;

  return (
    <div className="space-y-8">
      <header className="border-b border-[#141414] pb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="font-serif italic text-5xl mb-2">Token Calculator</h1>
            <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Multi-asset portfolio valuation tool</p>
          </div>
          <button 
            onClick={fetchPrices}
            disabled={loading}
            className="p-3 border border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0] transition-all disabled:opacity-50"
            title="Refresh Prices"
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </header>

      {error && (
        <div className="p-4 bg-amber-500/10 border border-amber-500 text-amber-700 flex items-center gap-3 font-mono text-xs uppercase tracking-wider">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tokens.map((token, index) => (
          <motion.div 
            key={token.symbol}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="border border-[#141414] p-6 space-y-6 bg-white/50 relative overflow-hidden group"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-[#141414] text-[#E4E3E0]">
                  <Coins size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-lg leading-none">{token.name}</h3>
                  <p className="font-mono text-[10px] opacity-50 uppercase tracking-widest mt-1">{token.symbol.replace('USDT', '')}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-[10px] opacity-40 uppercase tracking-widest mb-1">Market Price</div>
                <div className="font-mono font-bold">
                  {token.currentMarketPrice ? `$${token.currentMarketPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}` : '---'}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block font-mono text-[10px] uppercase tracking-widest mb-2 opacity-50">Amount</label>
                <input
                  type="number"
                  value={token.amount}
                  onChange={(e) => handleAmountChange(index, e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-all"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block font-mono text-[10px] uppercase tracking-widest opacity-50">Price (USD)</label>
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <span className="font-mono text-[9px] uppercase tracking-widest opacity-40 group-hover:opacity-100 transition-opacity">Manual</span>
                    <div 
                      onClick={() => handleManualToggle(index)}
                      className={`w-8 h-4 border border-[#141414] relative transition-colors ${token.isManual ? 'bg-[#141414]' : 'bg-transparent'}`}
                    >
                      <div className={`absolute top-0.5 bottom-0.5 w-2.5 transition-all ${token.isManual ? 'right-0.5 bg-[#E4E3E0]' : 'left-0.5 bg-[#141414]'}`} />
                    </div>
                  </label>
                </div>
                <input
                  type="number"
                  value={token.price}
                  onChange={(e) => handlePriceChange(index, e.target.value)}
                  disabled={!token.isManual}
                  className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none transition-all ${
                    !token.isManual ? 'opacity-50 cursor-not-allowed bg-black/5' : 'focus:bg-[#141414] focus:text-[#E4E3E0]'
                  }`}
                />
              </div>
            </div>

            <div className="pt-6 border-t border-[#141414]/10 flex justify-between items-end">
              <div className="font-mono text-[10px] uppercase tracking-widest opacity-40">Total Value</div>
              <div className="text-2xl font-serif italic">
                ${calculateTotal(token).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
          </motion.div>
        ))}

        {/* Debt Field */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: tokens.length * 0.05 }}
          className="border border-red-500/30 p-6 space-y-6 bg-red-500/5 relative overflow-hidden group"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500 text-white">
                <ArrowDownCircle size={20} />
              </div>
              <div>
                <h3 className="font-bold text-lg leading-none">Debt (USDC/USDT)</h3>
                <p className="font-mono text-[10px] opacity-50 uppercase tracking-widest mt-1">Lending Liabilities</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-widest mb-2 opacity-50">Total Debt Amount</label>
              <input
                type="number"
                value={debt}
                onChange={(e) => setDebt(e.target.value)}
                placeholder="0.00"
                className="w-full bg-transparent border border-red-500/30 p-3 font-mono text-sm focus:outline-none focus:bg-red-500 focus:text-white transition-all"
              />
            </div>
          </div>

          <div className="pt-6 border-t border-red-500/10 flex justify-between items-end">
            <div className="font-mono text-[10px] uppercase tracking-widest opacity-40">Liability Value</div>
            <div className="text-2xl font-serif italic text-red-600">
              -${debtValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </motion.div>
      </div>

      <div className="border border-[#141414] bg-[#141414] text-[#E4E3E0] p-8 flex flex-col lg:flex-row justify-between items-center gap-8">
        <div className="flex items-center gap-4">
          <div className="p-4 border border-[#E4E3E0]/20">
            <Calculator className="w-8 h-8" />
          </div>
          <div>
            <h2 className="font-serif italic text-3xl">Portfolio Summary</h2>
            <p className="font-mono text-[10px] opacity-50 uppercase tracking-widest mt-1">Consolidated asset valuation</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-8 sm:gap-16 items-center">
          <div className="text-center sm:text-right">
            <div className="font-mono text-[10px] uppercase tracking-widest opacity-40 mb-1">Gross Assets</div>
            <div className="text-2xl font-serif italic">
              ${assetsTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>

          <div className="text-center sm:text-right">
            <div className="font-mono text-[10px] uppercase tracking-widest opacity-40 mb-1">Total Debt</div>
            <div className="text-2xl font-serif italic text-red-400">
              -${debtValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>

          <div className="text-center sm:text-right">
            <div className="font-mono text-xs uppercase tracking-[0.3em] opacity-40 mb-2">Net Portfolio Value</div>
            <div className="text-5xl sm:text-6xl font-serif italic flex items-center gap-2">
              <span className="text-2xl opacity-40 not-italic font-sans">$</span>
              {netTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-4 border border-[#141414] bg-white/30 font-mono text-[10px] uppercase tracking-widest opacity-50 flex items-center gap-3">
          <CheckCircle2 size={14} className="text-emerald-600" />
          Real-time data from Binance API
        </div>
        <div className="p-4 border border-[#141414] bg-white/30 font-mono text-[10px] uppercase tracking-widest opacity-50 flex items-center gap-3">
          <RefreshCw size={14} className="text-blue-600" />
          Auto-refresh every 60 seconds
        </div>
      </div>
    </div>
  );
}
