import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Paperclip, CheckCircle2, AlertCircle, Loader2, MessageSquare } from 'lucide-react';
import { db, auth } from '../firebase';
import { collection, addDoc, query, where, orderBy, getDocs, serverTimestamp, onSnapshot } from 'firebase/firestore';

interface SuggestionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Language = 'en' | 'ru';

const translations = {
  en: {
    title: 'Submit your suggestions',
    topicLabel: 'Choose a topic',
    messageLabel: 'Your message',
    attachLabel: 'Attach screenshot or file',
    submitBtn: 'Submit',
    successMsg: 'Thank you! Your suggestion has been sent.',
    errorMsg: 'Something went wrong. Please try again.',
    topics: {
      error: 'Found an error',
      ui: 'UI Improvement',
      wishes: 'Wishes',
      other: 'Other'
    },
    placeholders: {
      message: 'Describe your suggestion or report an error...'
    }
  }
};

interface Suggestion {
  id: number;
  topic: string;
  message: string;
  attachment_name: string | null;
  attachment_data: string | null;
  created_at: string;
  replies: {
    id: number;
    message: string;
    created_at: string;
  }[];
}

export const SuggestionModal: React.FC<SuggestionModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'new' | 'history'>('new');
  const [topic, setTopic] = useState('ui');
  const [message, setMessage] = useState('');
  const [attachment, setAttachment] = useState<{ name: string; data: string } | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [history, setHistory] = useState<Suggestion[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = translations.en;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachment({
          name: file.name,
          data: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const fetchHistory = async () => {
    if (!auth.currentUser) return;
    setLoadingHistory(true);
    try {
      const q = query(
        collection(db, 'suggestions'), 
        where('user_id', '==', auth.currentUser.uid),
        orderBy('created_at', 'desc')
      );
      
      const unsubscribe = onSnapshot(q, async (snapshot) => {
        const suggestions: Suggestion[] = [];
        for (const d of snapshot.docs) {
          const repliesQ = query(collection(db, `suggestions/${d.id}/replies`), orderBy('created_at', 'asc'));
          const repliesSnap = await getDocs(repliesQ);
          const replies = repliesSnap.docs.map(rd => ({ id: rd.id, ...rd.data() } as any));
          
          suggestions.push({ id: d.id, ...d.data(), replies } as any);
        }
        setHistory(suggestions);
        setLoadingHistory(false);
      }, (err) => {
        console.error('History listener error:', err);
        setLoadingHistory(false);
      });

      return unsubscribe;
    } catch (err) {
      console.error('Failed to fetch history:', err);
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    let unsubscribe: any;
    if (isOpen && activeTab === 'history') {
      fetchHistory().then(unsub => {
        unsubscribe = unsub;
      });
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isOpen, activeTab]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setStatus('loading');
    try {
      await addDoc(collection(db, 'suggestions'), {
        topic: t.topics[topic as keyof typeof t.topics],
        message,
        attachment_name: attachment?.name || null,
        attachment_data: attachment?.data || null,
        user_id: auth.currentUser?.uid || null,
        user_email: auth.currentUser?.email || null,
        created_at: serverTimestamp()
      });

      setStatus('success');
      setTimeout(() => {
        onClose();
        setStatus('idle');
        setMessage('');
        setAttachment(null);
      }, 2000);
    } catch (err) {
      console.error('Submit error:', err);
      setStatus('error');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-[#151619] border border-white/10 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl"
          >
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                  <MessageSquare size={20} />
                </div>
                <h2 className="text-xl font-semibold text-white">{t.title}</h2>
              </div>
              <button onClick={onClose} className="text-white/40 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            <div className="flex border-b border-white/5">
              <button
                onClick={() => setActiveTab('new')}
                className={`flex-1 py-3 text-xs font-mono uppercase tracking-widest transition-colors ${
                  activeTab === 'new' ? 'text-emerald-500 border-b-2 border-emerald-500' : 'text-white/40 hover:text-white/60'
                }`}
              >
                New Message
              </button>
              <button
                onClick={() => setActiveTab('history')}
                className={`flex-1 py-3 text-xs font-mono uppercase tracking-widest transition-colors ${
                  activeTab === 'history' ? 'text-emerald-500 border-b-2 border-emerald-500' : 'text-white/40 hover:text-white/60'
                }`}
              >
                History
              </button>
            </div>

            <div className="p-6 max-h-[60vh] overflow-y-auto">
              {activeTab === 'new' ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {status === 'success' ? (
                    <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                      <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-500">
                        <CheckCircle2 size={32} />
                      </div>
                      <p className="text-lg font-medium text-white">{t.successMsg}</p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{t.topicLabel}</label>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(t.topics).map(([key, label]) => (
                            <button
                              key={key}
                              type="button"
                              onClick={() => setTopic(key)}
                              className={`px-4 py-3 rounded-xl text-sm font-medium border transition-all text-left ${
                                topic === key
                                  ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400'
                                  : 'bg-white/5 border-white/5 text-white/60 hover:bg-white/10 hover:border-white/10'
                              }`}
                            >
                              {label}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{t.messageLabel}</label>
                        <textarea
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          placeholder={t.placeholders.message}
                          className="w-full bg-white/5 border border-white/10 rounded-xl p-4 text-white placeholder:text-white/20 focus:outline-none focus:border-emerald-500/50 min-h-[120px] resize-none"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{t.attachLabel}</label>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white/60 hover:bg-white/10 hover:text-white transition-all"
                          >
                            <Paperclip size={16} />
                            {attachment ? attachment.name : 'Choose file'}
                          </button>
                          {attachment && (
                            <button
                              type="button"
                              onClick={() => setAttachment(null)}
                              className="text-xs text-red-400 hover:text-red-300 transition-colors"
                            >
                              Remove
                            </button>
                          )}
                          <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            className="hidden"
                            accept="image/*"
                          />
                        </div>
                      </div>

                      {status === 'error' && (
                        <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 p-3 rounded-lg">
                          <AlertCircle size={16} />
                          {t.errorMsg}
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={status === 'loading' || !message.trim()}
                        className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:hover:bg-emerald-500 text-black font-bold rounded-xl transition-all flex items-center justify-center gap-2"
                      >
                        {status === 'loading' ? (
                          <Loader2 size={20} className="animate-spin" />
                        ) : (
                          <>
                            <Send size={20} />
                            {t.submitBtn}
                          </>
                        )}
                      </button>
                    </>
                  )}
                </form>
              ) : (
                <div className="space-y-6">
                  {loadingHistory ? (
                    <div className="py-12 flex justify-center">
                      <Loader2 size={32} className="animate-spin text-emerald-500" />
                    </div>
                  ) : history.length === 0 ? (
                    <div className="py-12 text-center text-white/40 font-mono text-xs uppercase tracking-widest">
                      No messages yet
                    </div>
                  ) : (
                    history.map((item) => (
                      <div key={item.id} className="space-y-4">
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2">
                          <div className="flex justify-between items-start">
                            <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-500 font-bold">
                              {item.topic}
                            </span>
                            <span className="text-[9px] font-mono opacity-40">
                              {new Date(item.created_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm text-white/80 whitespace-pre-wrap">{item.message}</p>
                        </div>
                        
                        {item.replies.map((reply) => (
                          <div key={reply.id} className="ml-8 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-4 space-y-2">
                            <div className="flex justify-between items-start">
                              <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                                Admin
                              </span>
                              <span className="text-[9px] font-mono opacity-40 text-emerald-400/60">
                                {new Date(reply.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-sm text-emerald-100/80 whitespace-pre-wrap">{reply.message}</p>
                          </div>
                        ))}
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
