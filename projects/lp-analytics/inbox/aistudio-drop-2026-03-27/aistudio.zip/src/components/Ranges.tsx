import React from 'react';
import { TrendingUp, Calendar, Target, Info, Search, Loader2 } from 'lucide-react';

interface RangeStats {
  daysInRange: number;
  totalDays: number;
  avgDaysPerYear: number;
  allTimeDays: number;
  lastYearDaysInRange: number;
  lastYearTotalDays: number;
}

interface SummaryStats {
  min_price: number;
  max_price: number;
  total_days: number;
  first_time: number;
  last_time: number;
}

export default function Ranges() {
  const [symbol, setSymbol] = React.useState('BTCUSDT');
  const [rangeWidth, setRangeWidth] = React.useState('5000');
  const [currentPrice, setCurrentPrice] = React.useState<number | null>(null);
  const [stats, setStats] = React.useState<RangeStats | null>(null);
  const [summary, setSummary] = React.useState<SummaryStats | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const fetchCurrentPrice = async (sym: string) => {
    try {
      const res = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${sym}`);
      const data = await res.json();
      const price = parseFloat(data.price);
      setCurrentPrice(price);
      return price;
    } catch (err) {
      console.error('Failed to fetch current price:', err);
      return null;
    }
  };

  const fetchSummary = async (sym: string) => {
    try {
      const res = await fetch(`/api/ranges/summary?symbol=${sym}`);
      const data = await res.json();
      setSummary(data);
    } catch (err) {
      console.error('Failed to fetch summary:', err);
    }
  };

  const handleAnalyze = async () => {
    setLoading(true);
    setError(null);
    try {
      let price = currentPrice;
      if (!price) {
        price = await fetchCurrentPrice(symbol);
      }
      
      if (!price) throw new Error("Could not fetch current price");

      const width = parseFloat(rangeWidth);
      const lower = price - (width / 2);
      const upper = price + (width / 2);

      const res = await fetch(`/api/ranges/analyze?symbol=${symbol}&lower=${lower}&upper=${upper}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setStats(data);
      await fetchSummary(symbol);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchCurrentPrice(symbol);
    handleAnalyze();
  }, [symbol]);

  const instruments = [
    { name: 'Bitcoin', symbol: 'BTCUSDT' },
    { name: 'Ethereum', symbol: 'ETHUSDT' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-20">
      <header className="border-b border-[#141414] pb-6">
        <h1 className="font-serif italic text-5xl mb-2">Historical Ranges</h1>
        <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Backtesting Price Stability & Range Duration</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls */}
        <div className="lg:col-span-1 space-y-6">
          <div className="border border-[#141414] p-6 bg-white/30 space-y-6">
            <div className="space-y-2">
              <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Select Instrument</label>
              <div className="grid grid-cols-1 gap-2">
                {instruments.map((inst) => (
                  <button
                    key={inst.symbol}
                    onClick={() => setSymbol(inst.symbol)}
                    className={`p-3 font-mono text-sm border transition-colors text-left ${
                      symbol === inst.symbol 
                        ? 'bg-[#141414] text-[#E4E3E0] border-[#141414]' 
                        : 'border-[#141414] hover:bg-[#141414]/5'
                    }`}
                  >
                    {inst.name} ({inst.symbol.replace('USDT', '')})
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Range Width ($)</label>
              <div className="relative">
                <input
                  type="number"
                  value={rangeWidth}
                  onChange={(e) => setRangeWidth(e.target.value)}
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  placeholder="e.g. 5000"
                />
                {currentPrice && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 font-mono text-[8px] opacity-30">
                    ~{((parseFloat(rangeWidth) / currentPrice) * 100).toFixed(1)}%
                  </div>
                )}
              </div>
              <p className="font-mono text-[8px] opacity-40 italic">
                Range will be centered at current price (${currentPrice?.toLocaleString()})
              </p>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="w-full bg-[#141414] text-[#E4E3E0] p-4 font-mono text-xs uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Analyze Range
            </button>
          </div>

          {summary && (
            <div className="border border-[#141414] p-6 bg-[#141414] text-[#E4E3E0] space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <h3 className="font-serif italic text-xl">All-Time Summary</h3>
              </div>
              <div className="space-y-4 font-mono text-xs">
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="opacity-50 uppercase">Max Price (ATH)</span>
                  <span className="font-bold">${summary.max_price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="opacity-50 uppercase">Min Price (ATL)</span>
                  <span className="font-bold">${summary.min_price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-2 text-emerald-400">
                  <span className="opacity-50 uppercase">Max Historical Range</span>
                  <span className="font-bold">${(summary.max_price - summary.min_price).toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="opacity-50 uppercase">Total Data Days</span>
                  <span className="font-bold">{summary.total_days} days</span>
                </div>
                <div className="flex justify-between">
                  <span className="opacity-50 uppercase">Data Since</span>
                  <span className="font-bold">{new Date(summary.first_time).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results */}
        <div className="lg:col-span-2 space-y-8">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 text-rose-600 font-mono text-sm">
              {error}
            </div>
          )}

          {stats ? (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border border-[#141414] p-8 bg-white/30 space-y-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    <h3 className="font-serif italic text-2xl">Last 365 Days</h3>
                  </div>
                  <div className="space-y-1">
                    <div className="text-4xl font-bold text-[#141414]">{stats.lastYearDaysInRange} days</div>
                    <div className="font-mono text-[10px] uppercase tracking-widest opacity-50">Stayed within range</div>
                  </div>
                  <div className="w-full h-2 bg-[#141414]/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-[#141414] transition-all duration-1000" 
                      style={{ width: `${(stats.lastYearDaysInRange / stats.lastYearTotalDays) * 100}%` }}
                    />
                  </div>
                  <p className="font-mono text-[10px] opacity-50">
                    The price held this range for {((stats.lastYearDaysInRange / stats.lastYearTotalDays) * 100).toFixed(1)}% of the last year.
                  </p>
                </div>

                <div className="border border-[#141414] p-8 bg-white/30 space-y-4">
                  <div className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    <h3 className="font-serif italic text-2xl">All-Time Average</h3>
                  </div>
                  <div className="space-y-1">
                    <div className="text-4xl font-bold text-[#141414]">{stats.avgDaysPerYear.toFixed(1)} days</div>
                    <div className="font-mono text-[10px] uppercase tracking-widest opacity-50">Average days per year</div>
                  </div>
                  <div className="pt-4 border-t border-[#141414]/10 space-y-2">
                    <div className="flex justify-between font-mono text-[10px]">
                      <span className="opacity-50 uppercase">Total Days in Range</span>
                      <span className="font-bold">{stats.allTimeDays} days</span>
                    </div>
                    <div className="flex justify-between font-mono text-[10px]">
                      <span className="opacity-50 uppercase">Total Historical Days</span>
                      <span className="font-bold">{stats.totalDays} days</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border border-[#141414] p-8 bg-white/30">
                <div className="flex items-start gap-4">
                  <Info className="w-6 h-6 mt-1 opacity-30" />
                  <div className="space-y-4">
                    <h4 className="font-serif italic text-xl">Strategy Insights</h4>
                    <p className="font-mono text-sm opacity-70 leading-relaxed">
                      Based on historical data for {symbol.replace('USDT', '')}, a range width of ${parseFloat(rangeWidth).toLocaleString()} 
                      centered at current price is held for an average of <span className="font-bold text-[#141414]">{stats.avgDaysPerYear.toFixed(1)} days per year</span>. 
                      This suggests that if you set this range, you might expect to stay "in-range" for approximately 
                      <span className="font-bold text-[#141414]"> {((stats.avgDaysPerYear / 365) * 100).toFixed(1)}%</span> of the time annually.
                    </p>
                    <div className="bg-[#141414] text-[#E4E3E0] p-4 font-mono text-[10px] uppercase tracking-widest">
                      Recommendation: Adjust your range to cover at least 180 days of historical stability for optimal fee collection.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center border border-dashed border-[#141414]/30">
              <p className="font-mono text-xs opacity-30 uppercase tracking-widest">Select instrument and range to begin analysis</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
