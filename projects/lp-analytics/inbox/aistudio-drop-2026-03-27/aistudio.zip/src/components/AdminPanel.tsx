import React, { useEffect, useState } from 'react';
import { User } from '../types';
import { Shield, UserCheck, Clock, ShieldAlert, CreditCard, Trash2, Calendar, Plus, MessageSquare, X, FileText, RefreshCw, CloudDownload, Database, History } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../firebase';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs,
  addDoc,
  serverTimestamp,
  where
} from 'firebase/firestore';

interface Suggestion {
  id: string;
  topic: string;
  message: string;
  attachment_name: string | null;
  attachment_data: string | null;
  created_at: any;
  user_id: string;
  user_email?: string;
  replies?: {
    id: string;
    message: string;
    created_at: any;
  }[];
}

export default function AdminPanel() {
  const [users, setUsers] = useState<(User & { suggestion_count?: number })[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUserSuggestions, setSelectedUserSuggestions] = useState<{ user: User | null, suggestions: Suggestion[] } | null>(null);
  const [fetchingSuggestions, setFetchingSuggestions] = useState(false);
  const [allSuggestions, setAllSuggestions] = useState<Suggestion[]>([]);
  const [showAllSuggestions, setShowAllSuggestions] = useState(false);
  const [replyMessages, setReplyMessages] = useState<{[key: string]: string}>({});
  const [sendingReply, setSendingReply] = useState<string | null>(null);
  const [isRecalculating, setIsRecalculating] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [maintenanceStatus, setMaintenanceStatus] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'users'), orderBy('email'));
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const usersData: (User & { suggestion_count?: number })[] = [];
      
      for (const userDoc of snapshot.docs) {
        const userData = { id: userDoc.id, ...userDoc.data() } as User;
        
        // Count suggestions for each user
        const suggestionsQ = query(collection(db, 'suggestions'), where('user_id', '==', userDoc.id));
        const suggestionsSnap = await getDocs(suggestionsQ);
        
        usersData.push({
          ...userData,
          suggestion_count: suggestionsSnap.size
        });
      }
      
      setUsers(usersData);
      setLoading(false);
    }, (error) => {
      console.error("Firestore users listener error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const updateRole = async (userId: string, newRole: string) => {
    try {
      await updateDoc(doc(db, 'users', userId), { role: newRole });
    } catch (err) {
      console.error('Failed to update role:', err);
    }
  };

  const deleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This will also delete their payment history.')) return;
    try {
      await deleteDoc(doc(db, 'users', userId));
    } catch (err) {
      console.error('Failed to delete user:', err);
    }
  };

  const extendSubscription = async (userId: string, currentExpiry: string | undefined, currentWallet: string | undefined) => {
    const days = prompt('Enter number of days to add:', '30');
    if (days === null) return;
    
    const wallet = prompt('Enter Wallet Address (optional):', currentWallet || '');
    if (wallet === null) return;

    const d = parseInt(days);
    if (isNaN(d)) return;

    const baseDate = currentExpiry ? new Date(currentExpiry) : new Date();
    if (baseDate < new Date()) baseDate.setTime(new Date().getTime());
    
    baseDate.setDate(baseDate.getDate() + d);
    
    try {
      await updateDoc(doc(db, 'users', userId), {
        subscription_expiry: baseDate.toISOString(),
        subscription_type: 'manual',
        wallet_address: wallet || null
      });
    } catch (err) {
      console.error('Failed to extend subscription:', err);
    }
  };

  const fetchUserSuggestions = async (user: User) => {
    setFetchingSuggestions(true);
    try {
      const q = query(collection(db, 'suggestions'), where('user_id', '==', user.id), orderBy('created_at', 'desc'));
      const snap = await getDocs(q);
      const suggestions: Suggestion[] = [];
      
      for (const d of snap.docs) {
        const repliesQ = query(collection(db, `suggestions/${d.id}/replies`), orderBy('created_at', 'asc'));
        const repliesSnap = await getDocs(repliesQ);
        const replies = repliesSnap.docs.map(rd => ({ id: rd.id, ...rd.data() } as any));
        
        suggestions.push({ id: d.id, ...d.data(), replies } as Suggestion);
      }
      
      setSelectedUserSuggestions({ user, suggestions });
    } catch (err) {
      console.error('Failed to fetch suggestions:', err);
    } finally {
      setFetchingSuggestions(false);
    }
  };

  const fetchAllSuggestions = async () => {
    setFetchingSuggestions(true);
    try {
      const q = query(collection(db, 'suggestions'), orderBy('created_at', 'desc'));
      const snap = await getDocs(q);
      const suggestions: Suggestion[] = [];
      
      for (const d of snap.docs) {
        const repliesQ = query(collection(db, `suggestions/${d.id}/replies`), orderBy('created_at', 'asc'));
        const repliesSnap = await getDocs(repliesQ);
        const replies = repliesSnap.docs.map(rd => ({ id: rd.id, ...rd.data() } as any));
        
        suggestions.push({ id: d.id, ...d.data(), replies } as Suggestion);
      }
      
      setAllSuggestions(suggestions);
      setShowAllSuggestions(true);
    } catch (err) {
      console.error('Failed to fetch suggestions:', err);
    } finally {
      setFetchingSuggestions(false);
    }
  };

  const handleReply = async (suggestionId: string) => {
    const message = replyMessages[suggestionId];
    if (!message?.trim()) return;

    setSendingReply(suggestionId);
    try {
      await addDoc(collection(db, `suggestions/${suggestionId}/replies`), {
        message,
        created_at: serverTimestamp()
      });
      
      setReplyMessages(prev => ({ ...prev, [suggestionId]: '' }));
      
      // Refresh suggestions
      if (showAllSuggestions) {
        fetchAllSuggestions();
      } else if (selectedUserSuggestions?.user) {
        fetchUserSuggestions(selectedUserSuggestions.user);
      }
    } catch (err) {
      console.error('Failed to send reply:', err);
    } finally {
      setSendingReply(null);
    }
  };

  const handleRecalculate = async () => {
    if (!confirm('Force recalculate all pool deltas and sync to Firestore? This will update all metrics based on current snapshots.')) return;
    
    setIsRecalculating(true);
    setMaintenanceStatus(null);
    try {
      const response = await fetch('/api/admin/recalculate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        setMaintenanceStatus({ message: 'Recalculation and sync started in background.', type: 'success' });
      } else {
        const err = await response.json();
        setMaintenanceStatus({ message: `Failed: ${err.error || 'Unknown error'}`, type: 'error' });
      }
    } catch (err) {
      setMaintenanceStatus({ message: `Error: ${(err as Error).message}`, type: 'error' });
    } finally {
      setIsRecalculating(false);
    }
  };

  const handlePullFromCloud = async () => {
    if (!confirm('Pull all data from Firestore back to local SQLite? This will update local records with cloud data. Use this if your local database is empty but Firestore has data.')) return;
    
    setIsPulling(true);
    setMaintenanceStatus(null);
    try {
      const response = await fetch('/api/admin/pull-from-cloud', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        setMaintenanceStatus({ message: 'Data pulled from cloud successfully. Local database updated.', type: 'success' });
      } else {
        const err = await response.json();
        setMaintenanceStatus({ message: `Failed: ${err.error || 'Unknown error'}`, type: 'error' });
      }
    } catch (err) {
      setMaintenanceStatus({ message: `Error: ${(err as Error).message}`, type: 'error' });
    } finally {
      setIsPulling(false);
    }
  };

  if (loading) return <div className="font-mono text-xs uppercase opacity-50">Loading user database...</div>;

  return (
    <div className="space-y-8">
      <header className="border-b border-[#141414] pb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="font-serif italic text-5xl mb-2">Administration</h1>
            <p className="font-mono text-xs opacity-50 uppercase tracking-widest">User Access Control & Permissions ({users.length} users)</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={fetchAllSuggestions}
              className="px-4 py-2 border border-[#141414] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-all flex items-center gap-2"
            >
              <MessageSquare size={14} />
              View All Suggestions
            </button>
            <div className={`font-mono text-[10px] px-2 py-1 border ${window.location.hostname.includes('-pre-') ? 'border-emerald-500 text-emerald-600' : 'border-amber-500 text-amber-600'}`}>
              {window.location.hostname.includes('-pre-') ? 'SHARED ENVIRONMENT' : 'DEVELOPMENT ENVIRONMENT'}
            </div>
          </div>
        </div>
      </header>

      <div className="border border-[#141414]">
        <div className="hidden lg:grid lg:grid-cols-[1.5fr_1.5fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr] bg-[#141414] text-[#E4E3E0] font-mono text-[10px] uppercase tracking-widest p-4">
          <div>User</div>
          <div>Email</div>
          <div>Wallet</div>
          <div>Role</div>
          <div>Subscription</div>
          <div>Last Pay</div>
          <div>Joined</div>
          <div>Msgs</div>
          <div className="text-right">Actions</div>
        </div>

        <div className="divide-y divide-[#141414]">
          {users.map((user) => (
            <div key={user.id} className="flex flex-col lg:grid lg:grid-cols-[1.5fr_1.5fr_1fr_1fr_1fr_1fr_1fr_1fr_1fr] p-4 items-center gap-4 hover:bg-[#141414]/5 transition-colors">
              <div 
                className="flex items-center gap-3 w-full lg:w-auto cursor-pointer group"
                onClick={() => user.suggestion_count ? fetchUserSuggestions(user) : null}
              >
                <img src={user.picture} alt="" className="w-8 h-8 rounded-full border border-[#141414]" />
                <span className="font-bold text-xs truncate group-hover:underline">{user.name}</span>
              </div>
              <div className="font-mono text-[10px] opacity-60 w-full lg:w-auto truncate">{user.email}</div>
              <div className="font-mono text-[9px] opacity-60 w-full lg:w-auto truncate" title={user.wallet_address}>
                {user.wallet_address ? `${user.wallet_address.slice(0, 6)}...${user.wallet_address.slice(-4)}` : '—'}
              </div>
              <div className="w-full lg:w-auto">
                <span className={`font-mono text-[9px] uppercase px-2 py-1 rounded ${
                  user.role === 'admin' ? 'bg-emerald-500 text-white' :
                  user.role === 'approved' ? 'bg-blue-500 text-white' :
                  user.role === 'pending_payment' ? 'bg-purple-500 text-white' :
                  'bg-amber-500 text-white'
                }`}>
                  {user.role.replace('_', ' ')}
                </span>
              </div>
              <div className="w-full lg:w-auto">
                {user.subscription_type !== 'none' ? (
                  <div className="space-y-1">
                    <div className="font-mono text-[9px] uppercase font-bold">{user.subscription_type}</div>
                    {user.subscription_expiry && (
                      <div className="font-mono text-[8px] opacity-50">
                        Exp: {format(new Date(user.subscription_expiry), 'MMM dd, yy')}
                      </div>
                    )}
                  </div>
                ) : (
                  <span className="font-mono text-[9px] opacity-30 uppercase">None</span>
                )}
              </div>
              <div className="font-mono text-[9px] opacity-50 w-full lg:w-auto">
                {user.last_payment_at ? format(new Date(user.last_payment_at), 'MMM dd, yy') : '—'}
              </div>
              <div className="font-mono text-[9px] opacity-50 w-full lg:w-auto">
                {(user as any).created_at ? format(new Date((user as any).created_at.toDate ? (user as any).created_at.toDate() : (user as any).created_at), 'MMM dd, yy') : 'N/A'}
              </div>
              <div className="w-full lg:w-auto">
                {user.suggestion_count ? (
                  <button 
                    onClick={() => fetchUserSuggestions(user)}
                    className="flex items-center gap-1.5 px-2 py-1 bg-emerald-500/10 text-emerald-600 rounded-md hover:bg-emerald-500/20 transition-colors"
                  >
                    <MessageSquare size={12} />
                    <span className="font-mono text-[10px] font-bold">{user.suggestion_count}</span>
                  </button>
                ) : (
                  <span className="font-mono text-[9px] opacity-20">—</span>
                )}
              </div>
              <div className="flex justify-end gap-1 w-full lg:w-auto">
                {user.role !== 'admin' && (
                  <>
                    <button 
                      onClick={() => extendSubscription(user.id!, user.subscription_expiry, user.wallet_address)}
                      className="p-1.5 border border-[#141414] hover:bg-emerald-500 hover:text-white transition-all rounded"
                      title="Edit Subscription & Wallet"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => updateRole(user.id!, 'approved')}
                      className="p-1.5 border border-[#141414] hover:bg-blue-500 hover:text-white transition-all rounded"
                      title="Approve User"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => updateRole(user.id!, 'pending_payment')}
                      className="p-1.5 border border-[#141414] hover:bg-purple-500 hover:text-white transition-all rounded"
                      title="Set to Pending Payment"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => deleteUser(user.id!)}
                      className="p-1.5 border border-red-500 text-red-500 hover:bg-red-500 hover:text-white transition-all rounded"
                      title="Delete User"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <ShieldAlert className="w-5 h-5" />
          <h2 className="font-serif italic text-3xl">System Maintenance</h2>
        </div>

        {maintenanceStatus && (
          <div className={`p-4 border font-mono text-[10px] uppercase tracking-widest flex items-center justify-between ${
            maintenanceStatus.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'
          }`}>
            <span>{maintenanceStatus.message}</span>
            <button onClick={() => setMaintenanceStatus(null)} className="opacity-50 hover:opacity-100">
              <X size={14} />
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-[#141414] p-6 space-y-4 bg-white/50">
            <div className="flex items-center gap-3">
              <RefreshCw className={`w-5 h-5 ${isRecalculating ? 'animate-spin' : ''}`} />
              <h3 className="font-mono text-xs uppercase font-bold tracking-widest">Data Recalculation</h3>
            </div>
            <p className="text-xs opacity-60 leading-relaxed">
              Force a full recalculation of all pool deltas (1D, 3D, 7D) and APRs based on current snapshots in the local database. This will also sync the results to Firestore.
            </p>
            <button 
              onClick={handleRecalculate}
              disabled={isRecalculating}
              className="w-full py-3 bg-[#141414] text-[#E4E3E0] font-mono text-[10px] uppercase tracking-widest hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {isRecalculating ? 'Recalculating...' : 'Start Full Recalculation'}
            </button>
          </div>

          <div className="border border-[#141414] p-6 space-y-4 bg-white/50">
            <div className="flex items-center gap-3">
              <CloudDownload className={`w-5 h-5 ${isPulling ? 'animate-pulse' : ''}`} />
              <h3 className="font-mono text-xs uppercase font-bold tracking-widest">Cloud Recovery</h3>
            </div>
            <p className="text-xs opacity-60 leading-relaxed">
              Pull all pool and snapshot data from Firestore back into the local SQLite database. Use this if your local data was lost or corrupted but Firestore is still accurate.
            </p>
            <button 
              onClick={handlePullFromCloud}
              disabled={isPulling}
              className="w-full py-3 border border-[#141414] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-all disabled:opacity-50"
            >
              {isPulling ? 'Pulling Data...' : 'Restore from Cloud'}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {(selectedUserSuggestions || showAllSuggestions) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-[#E4E3E0] border border-[#141414] w-full max-w-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-[#141414] flex items-center justify-between bg-[#141414] text-[#E4E3E0]">
                <div className="flex items-center gap-3">
                  {selectedUserSuggestions?.user ? (
                    <img src={selectedUserSuggestions.user.picture} alt="" className="w-8 h-8 rounded-full border border-white/20" />
                  ) : (
                    <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center bg-white/10">
                      <MessageSquare size={16} />
                    </div>
                  )}
                  <div>
                    <h2 className="text-lg font-bold leading-none">
                      {selectedUserSuggestions?.user ? selectedUserSuggestions.user.name : 'All Suggestions'}
                    </h2>
                    <p className="text-[10px] font-mono opacity-60 uppercase tracking-wider mt-1">
                      {selectedUserSuggestions?.user ? 'User Messages & Suggestions' : 'Global Feedback Database'}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    setSelectedUserSuggestions(null);
                    setShowAllSuggestions(false);
                  }}
                  className="p-1 hover:bg-white/10 rounded-md transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-6 max-h-[60vh] overflow-y-auto space-y-6">
                {(selectedUserSuggestions?.suggestions || allSuggestions).map((s) => (
                  <div key={s.id} className="border border-[#141414] p-4 space-y-3 bg-white/50">
                    <div className="flex justify-between items-start">
                      <div className="flex flex-col gap-1">
                        <span className="font-mono text-[10px] uppercase font-bold px-2 py-0.5 bg-[#141414] text-[#E4E3E0] w-fit">
                          {s.topic}
                        </span>
                        {!selectedUserSuggestions?.user && (
                          <span className="font-mono text-[9px] opacity-60">
                            From: {s.user_email || 'Guest'}
                          </span>
                        )}
                      </div>
                      <span className="font-mono text-[9px] opacity-50">
                        {s.created_at ? format(s.created_at.toDate ? s.created_at.toDate() : new Date(s.created_at), 'MMM dd, yyyy HH:mm') : 'N/A'}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{s.message}</p>
                    
                    {s.replies && s.replies.length > 0 && (
                      <div className="ml-6 space-y-3 border-l-2 border-[#141414]/10 pl-4 py-2">
                        {s.replies.map((reply) => (
                          <div key={reply.id} className="space-y-1">
                            <div className="flex justify-between items-center">
                              <span className="text-[9px] font-mono uppercase font-bold text-emerald-600">Admin Response</span>
                              <span className="text-[8px] font-mono opacity-40">
                                {reply.created_at ? format(reply.created_at.toDate ? reply.created_at.toDate() : new Date(reply.created_at), 'MMM dd, HH:mm') : 'N/A'}
                              </span>
                            </div>
                            <p className="text-xs opacity-80">{reply.message}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="pt-3 border-t border-[#141414]/5 space-y-2">
                      <textarea
                        value={replyMessages[s.id] || ''}
                        onChange={(e) => setReplyMessages(prev => ({ ...prev, [s.id]: e.target.value }))}
                        placeholder="Type your response..."
                        className="w-full bg-white/50 border border-[#141414]/10 rounded p-2 text-xs focus:outline-none focus:border-[#141414] min-h-[60px] resize-none"
                      />
                      <div className="flex justify-end">
                        <button
                          onClick={() => handleReply(s.id)}
                          disabled={sendingReply === s.id || !(replyMessages[s.id]?.trim())}
                          className="px-4 py-1.5 bg-[#141414] text-[#E4E3E0] font-mono text-[9px] uppercase tracking-widest hover:bg-[#141414]/90 disabled:opacity-50 transition-all flex items-center gap-2"
                        >
                          {sendingReply === s.id ? 'Sending...' : 'Send Response'}
                        </button>
                      </div>
                    </div>

                    {s.attachment_name && (
                      <div className="pt-2 border-t border-[#141414]/10 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs font-mono opacity-60">
                          <FileText size={14} />
                          {s.attachment_name}
                        </div>
                        {s.attachment_data && (
                          <a 
                            href={s.attachment_data} 
                            download={s.attachment_name}
                            className="text-[10px] font-mono uppercase font-bold underline hover:no-underline"
                          >
                            Download
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {(selectedUserSuggestions?.suggestions.length === 0 || (showAllSuggestions && allSuggestions.length === 0)) && (
                  <div className="py-12 text-center font-mono text-xs opacity-40 uppercase tracking-widest">
                    No messages found in database
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-[#141414] flex justify-end">
                <button 
                  onClick={() => {
                    setSelectedUserSuggestions(null);
                    setShowAllSuggestions(false);
                  }}
                  className="px-6 py-2 bg-[#141414] text-[#E4E3E0] font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414]/90 transition-all"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
