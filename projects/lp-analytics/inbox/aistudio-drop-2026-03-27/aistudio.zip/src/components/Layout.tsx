import React, { useState } from 'react';
import { LayoutDashboard, PlusCircle, Calculator, Database, Zap, Menu, X, Shield, LogOut, MessageSquarePlus, Eye, EyeOff, Info, AlertTriangle, Target, Coins, BookOpen } from 'lucide-react';
import { useAuth } from './AuthContext';
import { SuggestionModal } from './SuggestionModal';
import { DisclaimerModal } from './DisclaimerModal';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Layout({ children, activeTab, onTabChange }: LayoutProps) {
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSuggestionModalOpen, setIsSuggestionModalOpen] = useState(false);
  const [isDisclaimerModalOpen, setIsDisclaimerModalOpen] = useState(false);
  const [isBlurred, setIsBlurred] = useState(false);

  const navItems = [
    { id: 'overview', label: 'Overview', icon: Database, roles: ['approved'] },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'approved'] },
    { id: 'add-pool', label: 'Add Pool', icon: PlusCircle, roles: ['admin'] },
    { id: 'calculator', label: 'Calculator', icon: Calculator, roles: ['admin', 'approved'] },
    { id: 'strategy', label: 'Strategy', icon: Zap, roles: ['admin', 'approved'] },
    { id: 'ranges', label: 'Ranges', icon: Target, roles: ['admin', 'approved'] },
    { id: 'token-calculator', label: 'Token Calculator', icon: Coins, roles: ['admin', 'approved'] },
    { id: 'training', label: 'Обучение', icon: BookOpen, roles: ['admin', 'approved'] },
    { id: 'admin', label: 'Administration', icon: Shield, roles: ['admin'] },
  ];

  const visibleNavItems = navItems.filter(item => item.roles.includes(user?.role || ''));

  const handleTabChange = (id: string) => {
    onTabChange(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-[60] lg:hidden backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed left-0 top-0 h-full w-64 border-r border-[#141414] bg-[#E4E3E0] z-[70] transition-transform duration-300 lg:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <Database className="w-6 h-6" />
              <span className="font-mono font-bold text-lg tracking-tighter uppercase">LP ANALYTICS</span>
            </div>
            <button onClick={() => setIsMobileMenuOpen(false)} className="lg:hidden">
              <X className="w-6 h-6" />
            </button>
          </div>
          
          <nav className="space-y-1 flex-1">
            {visibleNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-mono uppercase tracking-wider transition-colors border border-transparent ${
                  activeTab === item.id 
                    ? 'bg-[#141414] text-[#E4E3E0]' 
                    : 'hover:border-[#141414]'
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}

            <button
              onClick={() => {
                setIsSuggestionModalOpen(true);
                setIsMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm font-mono uppercase tracking-wider transition-colors border border-transparent hover:border-[#141414] mt-4 text-emerald-600"
            >
              <MessageSquarePlus className="w-4 h-4" />
              Submit your suggestions
            </button>
          </nav>
          
          <div className="pt-6 border-t border-[#141414] space-y-4">
            {user && (
              <div className="flex items-center gap-3 px-2">
                <div className={`flex items-center gap-3 flex-1 min-w-0 transition-all duration-300 ${isBlurred ? 'blur-xl opacity-0 select-none pointer-events-none' : ''}`}>
                  <img src={user.picture} alt="" className="w-8 h-8 rounded-full border border-[#141414]" />
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] font-bold truncate uppercase">{user.name}</div>
                    <div className="flex items-center gap-1">
                      <div className="text-[8px] opacity-50 truncate uppercase">{user.role.replace('_', ' ')}</div>
                      {user.subscription_type && user.subscription_type !== 'none' && (
                        <div className="text-[7px] bg-[#141414] text-[#E4E3E0] px-1 rounded uppercase font-bold">
                          {user.subscription_type}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setIsBlurred(!isBlurred)} 
                    className="p-2 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors rounded"
                    title={isBlurred ? "Show profile" : "Hide profile"}
                  >
                    {isBlurred ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button onClick={logout} className="p-2 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors rounded">
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
            <div className="pt-4 border-t border-[#141414]/10">
              <button
                onClick={() => setIsDisclaimerModalOpen(true)}
                className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest opacity-40 hover:opacity-100 transition-opacity"
              >
                <AlertTriangle className="w-3 h-3" />
                Disclaimer
              </button>
            </div>
            <div className="text-[10px] font-mono opacity-50 uppercase tracking-widest">
              Cloud Version 1.0.0
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:pl-64 min-h-screen">
        <header className="h-16 border-b border-[#141414] flex items-center justify-between px-4 lg:px-8 bg-[#E4E3E0]/80 backdrop-blur-sm sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="font-mono text-xs uppercase opacity-50 italic">
              {activeTab.replace('-', ' ')}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-[10px] uppercase tracking-widest hidden sm:inline">System Online</span>
          </div>
        </header>
        
        <div className="p-4 sm:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>

      <SuggestionModal 
        isOpen={isSuggestionModalOpen} 
        onClose={() => setIsSuggestionModalOpen(false)} 
      />

      <DisclaimerModal
        isOpen={isDisclaimerModalOpen}
        onClose={() => setIsDisclaimerModalOpen(false)}
      />
    </div>
  );
}
