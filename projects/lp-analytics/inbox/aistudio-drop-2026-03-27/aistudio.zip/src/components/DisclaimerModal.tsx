import React from 'react';
import { X, AlertTriangle } from 'lucide-react';

interface DisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept?: () => void;
  isMandatory?: boolean;
}

export function DisclaimerModal({ isOpen, onClose, onAccept, isMandatory }: DisclaimerModalProps) {
  const [agreed, setAgreed] = React.useState(false);

  if (!isOpen) return null;

  const handleAccept = () => {
    if (agreed) {
      if (onAccept) onAccept();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-[#E4E3E0] border border-[#141414] w-full max-w-lg shadow-2xl">
        <div className="p-6 border-b border-[#141414] flex items-center justify-between bg-[#141414] text-[#E4E3E0]">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <h2 className="font-mono text-sm uppercase tracking-widest font-bold">Legal Disclaimer</h2>
          </div>
          {!isMandatory && (
            <button onClick={onClose} className="hover:opacity-70 transition-opacity">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
        
        <div className="p-8 space-y-6 font-sans text-sm leading-relaxed text-[#141414]">
          <p className="font-bold">
            Please read this disclaimer carefully before using the LP Analytics application.
          </p>
          
          <div className="space-y-4 opacity-80 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
            <p>
              <strong>No Financial Advice:</strong> The information provided by this application, including but not limited to yield projections, strategy simulations, and historical data analysis, does not constitute financial, investment, or professional advice. 
            </p>
            
            <p>
              <strong>Observation Only:</strong> All data and calculations are based on historical observations and mathematical models. Past performance is not indicative of future results. The cryptocurrency market is highly volatile and carries significant risk.
            </p>
            
            <p>
              <strong>"As Is" Basis:</strong> This application and all its content are provided on an "as is" and "as available" basis without any warranties of any kind, either express or implied. 
            </p>
            
            <p>
              <strong>Limitation of Liability:</strong> The authors and developers of this application shall not be held responsible or liable for any financial losses, damages, or claims arising from the use of or reliance on the information provided herein. You are solely responsible for your own investment decisions.
            </p>
          </div>

          <div className="pt-4 border-t border-[#141414]/10 space-y-4">
            <label className="flex items-start gap-3 cursor-pointer group">
              <input 
                type="checkbox" 
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="mt-1 w-4 h-4 border-[#141414] rounded-none accent-[#141414]"
              />
              <span className="text-xs font-mono uppercase tracking-tight opacity-70 group-hover:opacity-100 transition-opacity">
                I have read, understood, and agree to use this service at my own risk.
              </span>
            </label>

            <button 
              onClick={handleAccept}
              disabled={!agreed}
              className="w-full bg-[#141414] text-[#E4E3E0] py-3 font-mono text-xs uppercase tracking-widest hover:opacity-90 transition-opacity disabled:opacity-30 disabled:cursor-not-allowed"
            >
              I Understand and Accept
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
