import React from 'react';
import { Pool } from '../types';
import { Target, Info, ArrowRight, TrendingUp, DollarSign, Zap, RefreshCw, ShieldAlert, RotateCcw, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { useAuth } from './AuthContext';

interface StrategyProps {
  pools: Pool[];
}

export default function Strategy({ pools }: StrategyProps) {
  const { user, login } = useAuth();
  const isGuest = user?.role === 'guest';

  const RangeHint = ({ symbol, lower, upper }: { symbol: string, lower: number, upper: number }) => {
    const [stats, setStats] = React.useState<any>(null);
    const [loading, setLoading] = React.useState(false);

    React.useEffect(() => {
      const fetchStats = async () => {
        setLoading(true);
        try {
          const res = await fetch(`/api/ranges/analyze?symbol=${symbol}&lower=${lower}&upper=${upper}`);
          const data = await res.json();
          setStats(data);
        } catch (err) {
          console.error('Failed to fetch range stats:', err);
        } finally {
          setLoading(false);
        }
      };
      if (lower && upper) fetchStats();
    }, [symbol, lower, upper]);

    if (loading) return <div className="animate-pulse h-4 w-20 bg-white/10 rounded mt-1" />;
    if (!stats) return null;

    return (
      <div className="mt-2 pt-2 border-t border-white/5 space-y-1">
        <div className="flex justify-between font-mono text-[8px] uppercase tracking-tighter">
          <span className="opacity-40">Last Year:</span>
          <span className="text-emerald-400 font-bold">{stats.lastYearDaysInRange} days</span>
        </div>
        <div className="flex justify-between font-mono text-[8px] uppercase tracking-tighter">
          <span className="opacity-40">All-Time Avg:</span>
          <span className="text-blue-400 font-bold">{stats.avgDaysPerYear.toFixed(1)} d/y</span>
        </div>
      </div>
    );
  };

  // Calibration Pools
  const [ethRefId, setEthRefId] = React.useState<number | string>('');
  const [btcRefId, setBtcRefId] = React.useState<number | string>('');
  const [avaxRefId, setAvaxRefId] = React.useState<number | string>('');

  // Calculate averages for guests
  const getAveragePool = (type: 'ETH' | 'BTC' | 'AVAX') => {
    const filtered = pools.filter(p => {
      const pair = p.pair.toUpperCase();
      if (type === 'BTC') return pair.includes('BTC') || pair.includes('cbBTC');
      if (type === 'AVAX') return pair.includes('AVAX') || p.network === 'Avalanche';
      return pair.includes('ETH') || pair.includes('WETH');
    });

    if (filtered.length === 0) return null;

    const avgApr = filtered.reduce((acc, p) => acc + (p.aprSinceStart || 0), 0) / filtered.length;
    const avgRange = filtered.reduce((acc, p) => acc + (p.max_range - p.min_range), 0) / filtered.length;
    const avgFeesPerDay = filtered.reduce((acc, p) => acc + (p.feesPerDayAvg || 0), 0) / filtered.length;
    const avgStartLiq = filtered.reduce((acc, p) => acc + p.start_liquidity_usd, 0) / filtered.length;

    return {
      id: 0, // Use 0 for average pools
      name: `Average ${type} Pool`,
      aprSinceStart: avgApr,
      apr7D: avgApr,
      max_range: avgRange,
      min_range: 0,
      feesPerDayAvg: avgFeesPerDay,
      feesPerDay7D: avgFeesPerDay,
      start_liquidity_usd: avgStartLiq,
      network: 'Multiple',
      pair: type === 'ETH' ? 'ETH/USDC' : type === 'BTC' ? 'BTC/USDC' : 'AVAX/USDC',
      fee_percent: 0.05,
      start_date: new Date().toISOString()
    } as Pool;
  };

  const ethAvg = getAveragePool('ETH');
  const btcAvg = getAveragePool('BTC');
  const avaxAvg = getAveragePool('AVAX');

  // Prices fetching
  const [isFetchingPrices, setIsFetchingPrices] = React.useState(false);
  const [isManualPrice, setIsManualPrice] = React.useState(() => localStorage.getItem('strat_v2_isManualPrice') === 'true');
  const isManualPriceRef = React.useRef(localStorage.getItem('strat_v2_isManualPrice') === 'true');

  // Strategy Modes
  const [strategyMode, setStrategyMode] = React.useState<'accumulation' | 'distribution'>(() => (localStorage.getItem('strat_v2_strategyMode') as 'accumulation' | 'distribution') || 'accumulation');

  // Distribution Mode Inputs
  const [ethTokens, setEthTokens] = React.useState<string>('10');
  const [btcTokens, setBtcTokens] = React.useState<string>('0.5');
  const [avaxTokens, setAvaxTokens] = React.useState<string>('100');

  // Real Portfolio
  const [totalCapital, setTotalCapital] = React.useState<string>('100000');
  const [allocEth, setAllocEth] = React.useState<string>('30');
  const [allocBtc, setAllocBtc] = React.useState<string>('70');
  const [allocAvax, setAllocAvax] = React.useState<string>('0');
  const [ethPrice, setEthPrice] = React.useState<string>('3000');
  const [btcPrice, setBtcPrice] = React.useState<string>('60000');
  const [avaxPrice, setAvaxPrice] = React.useState<string>('40');

  // Enabled state for calibration
  const [ethEnabled, setEthEnabled] = React.useState(true);
  const [btcEnabled, setBtcEnabled] = React.useState(true);
  const [avaxEnabled, setAvaxEnabled] = React.useState(false);

  // Fear & Greed Index
  const [fngData, setFngData] = React.useState<{ value: string; classification: string } | null>(null);

  const fetchFnG = async () => {
    try {
      const res = await fetch('https://api.alternative.me/fng/');
      const data = await res.json();
      if (data.data && data.data[0]) {
        setFngData({
          value: data.data[0].value,
          classification: data.data[0].value_classification
        });
      }
    } catch (err) {
      console.error('Failed to fetch Fear & Greed Index:', err);
    }
  };

  // Auto-allocation logic
  React.useEffect(() => {
    const enabledCount = [ethEnabled, btcEnabled, avaxEnabled].filter(Boolean).length;
    
    if (enabledCount === 1) {
      if (ethEnabled) { setAllocEth('100'); setAllocBtc('0'); setAllocAvax('0'); }
      if (btcEnabled) { setAllocEth('0'); setAllocBtc('100'); setAllocAvax('0'); }
      if (avaxEnabled) { setAllocEth('0'); setAllocBtc('0'); setAllocAvax('100'); }
    } else if (enabledCount === 2) {
      // Ensure the disabled one is 0
      if (!ethEnabled) setAllocEth('0');
      if (!btcEnabled) setAllocBtc('0');
      if (!avaxEnabled) setAllocAvax('0');
      
      // If the sum of enabled isn't 100, normalize or just keep as is?
      // User said: "If we enter 30% for one pool, it means 70% goes to another automatically."
      // This implies we should balance them.
      const e = parseFloat(ethEnabled ? allocEth : '0') || 0;
      const b = parseFloat(btcEnabled ? allocBtc : '0') || 0;
      const a = parseFloat(avaxEnabled ? allocAvax : '0') || 0;
      const sum = e + b + a;
      
      if (sum !== 100) {
        // Simple balancing for the 2-enabled case if they were both 0 or something
        if (ethEnabled && btcEnabled) {
          if (e === 0 && b === 0) { setAllocEth('50'); setAllocBtc('50'); }
          else if (e + b !== 100) { setAllocBtc((100 - e).toString()); }
        } else if (ethEnabled && avaxEnabled) {
          if (e === 0 && a === 0) { setAllocEth('50'); setAllocAvax('50'); }
          else if (e + a !== 100) { setAllocAvax((100 - e).toString()); }
        } else if (btcEnabled && avaxEnabled) {
          if (b === 0 && a === 0) { setAllocBtc('50'); setAllocAvax('50'); }
          else if (b + a !== 100) { setAllocAvax((100 - b).toString()); }
        }
      }
    }
  }, [ethEnabled, btcEnabled, avaxEnabled]);

  const handleAllocChange = (asset: 'ETH' | 'BTC' | 'AVAX', value: string) => {
    const val = parseFloat(value) || 0;
    const enabledCount = [ethEnabled, btcEnabled, avaxEnabled].filter(Boolean).length;

    if (asset === 'ETH') {
      setAllocEth(value);
      if (enabledCount === 2) {
        if (btcEnabled) setAllocBtc((100 - val).toString());
        else if (avaxEnabled) setAllocAvax((100 - val).toString());
      }
    } else if (asset === 'BTC') {
      setAllocBtc(value);
      if (enabledCount === 2) {
        if (ethEnabled) setAllocEth((100 - val).toString());
        else if (avaxEnabled) setAllocAvax((100 - val).toString());
      }
    } else if (asset === 'AVAX') {
      setAllocAvax(value);
      if (enabledCount === 2) {
        if (ethEnabled) setAllocEth((100 - val).toString());
        else if (btcEnabled) setAllocBtc((100 - val).toString());
      }
    }
  };

  const toggleManualPrice = (val: boolean) => {
    setIsManualPrice(val);
    isManualPriceRef.current = val;
    if (!val) fetchPrices();
  };

  // Split
  const [ethAssetPct, setEthAssetPct] = React.useState<string>('5');
  const [btcAssetPct, setBtcAssetPct] = React.useState<string>('5');
  const [avaxAssetPct, setAvaxAssetPct] = React.useState<string>('5');

  // Target
  const [targetIncome, setTargetIncome] = React.useState<string>(() => localStorage.getItem('strat_v2_targetIncome') || '5000');
  const [mode, setMode] = React.useState<'split' | 'manual'>(() => (localStorage.getItem('strat_v2_mode') as 'split' | 'manual') || 'split');
  const [ethTargetShare, setEthTargetShare] = React.useState<string>(() => localStorage.getItem('strat_v2_ethTargetShare') || '45');
  const [btcTargetShare, setBtcTargetShare] = React.useState<string>(() => localStorage.getItem('strat_v2_btcTargetShare') || '55');
  const [ethManualRange, setEthManualRange] = React.useState<string>(() => localStorage.getItem('strat_v2_ethManualRange') || '5000');
  const [btcManualRange, setBtcManualRange] = React.useState<string>(() => localStorage.getItem('strat_v2_btcManualRange') || '50000');
  const [avaxManualRange, setAvaxManualRange] = React.useState<string>(() => localStorage.getItem('strat_v2_avaxManualRange') || '10');

  const [ethManualRebPrice, setEthManualRebPrice] = React.useState<string>(() => localStorage.getItem('strat_v2_ethManualRebPrice') || '');
  const [btcManualRebPrice, setBtcManualRebPrice] = React.useState<string>(() => localStorage.getItem('strat_v2_btcManualRebPrice') || '');
  const [avaxManualRebPrice, setAvaxManualRebPrice] = React.useState<string>(() => localStorage.getItem('strat_v2_avaxManualRebPrice') || '');

  // Persist settings
  React.useEffect(() => {
    localStorage.setItem('strat_v2_targetIncome', targetIncome);
    localStorage.setItem('strat_v2_mode', mode);
    localStorage.setItem('strat_v2_ethTargetShare', ethTargetShare);
    localStorage.setItem('strat_v2_btcTargetShare', btcTargetShare);
    localStorage.setItem('strat_v2_ethManualRange', ethManualRange);
    localStorage.setItem('strat_v2_btcManualRange', btcManualRange);
    localStorage.setItem('strat_v2_avaxManualRange', avaxManualRange);
    localStorage.setItem('strat_v2_ethManualRebPrice', ethManualRebPrice);
    localStorage.setItem('strat_v2_btcManualRebPrice', btcManualRebPrice);
    localStorage.setItem('strat_v2_avaxManualRebPrice', avaxManualRebPrice);
    localStorage.setItem('strat_v2_isManualPrice', isManualPrice.toString());
    localStorage.setItem('strat_v2_strategyMode', strategyMode);
  }, [targetIncome, mode, ethTargetShare, btcTargetShare, ethManualRange, btcManualRange, avaxManualRange, ethManualRebPrice, btcManualRebPrice, avaxManualRebPrice, isManualPrice, strategyMode]);

  // Initialize refs
  React.useEffect(() => {
    const ethPools = pools.filter(p => p.pair.toUpperCase().includes('ETH') || p.pair.toUpperCase().includes('WETH'));
    const btcPools = pools.filter(p => p.pair.toUpperCase().includes('BTC') || p.pair.toUpperCase().includes('WBTC'));
    const avaxPools = pools.filter(p => p.pair.toUpperCase().includes('AVAX') || p.network === 'Avalanche');

    if (ethPools.length > 0 && !ethRefId) {
      const bestEth = ethPools.reduce((prev, curr) => (prev.aprSinceStart || 0) > (curr.aprSinceStart || 0) ? prev : curr);
      setEthRefId(bestEth.id);
    }
    if (btcPools.length > 0 && !btcRefId) {
      const bestBtc = btcPools.reduce((prev, curr) => (prev.aprSinceStart || 0) > (curr.aprSinceStart || 0) ? prev : curr);
      setBtcRefId(bestBtc.id);
    }
    if (avaxPools.length > 0 && !avaxRefId) {
      const bestAvax = avaxPools.reduce((prev, curr) => (prev.aprSinceStart || 0) > (curr.aprSinceStart || 0) ? prev : curr);
      setAvaxRefId(bestAvax.id);
    }
  }, [pools]);

  const MONTH_DAYS = 365.25 / 12;

  const fetchPrices = async () => {
    if (isManualPriceRef.current) return;
    setIsFetchingPrices(true);
    try {
      const [ethRes, btcRes, avaxRes] = await Promise.all([
        fetch('https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDC'),
        fetch('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDC'),
        fetch('https://api.binance.com/api/v3/ticker/price?symbol=AVAXUSDC')
      ]);
      const ethData = await ethRes.json();
      const btcData = await btcRes.json();
      const avaxData = await avaxRes.json();
      if (ethData.price) setEthPrice(parseFloat(ethData.price).toString());
      if (btcData.price) setBtcPrice(parseFloat(btcData.price).toString());
      if (avaxData.price) setAvaxPrice(parseFloat(avaxData.price).toString());
    } catch (err) {
      console.error('Failed to fetch prices:', err);
    } finally {
      setIsFetchingPrices(false);
    }
  };

  React.useEffect(() => {
    fetchPrices();
    fetchFnG();
    const interval = setInterval(() => {
      fetchPrices();
      fetchFnG();
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Derived values
  const ethRef = isGuest ? ethAvg : pools.find(p => String(p.id) === String(ethRefId));
  const btcRef = isGuest ? btcAvg : pools.find(p => String(p.id) === String(btcRefId));
  const avaxRef = isGuest ? avaxAvg : pools.find(p => String(p.id) === String(avaxRefId));

  const ethUsdcPct = 100 - (parseFloat(ethAssetPct) || 0);
  const btcUsdcPct = 100 - (parseFloat(btcAssetPct) || 0);
  const avaxUsdcPct = 100 - (parseFloat(avaxAssetPct) || 0);
  const avaxTargetShare = 100 - (parseFloat(ethTargetShare) || 0) - (parseFloat(btcTargetShare) || 0);

  const ethPriceNum = parseFloat(ethPrice) || 0;
  const btcPriceNum = parseFloat(btcPrice) || 0;
  const avaxPriceNum = parseFloat(avaxPrice) || 0;

  // Derived Total Capital and Allocations based on mode
  let totalCapNum = parseFloat(totalCapital) || 0;
  let allocEthNum = parseFloat(allocEth) || 0;
  let allocBtcNum = parseFloat(allocBtc) || 0;
  let allocAvaxNum = parseFloat(allocAvax) || 0;

  if (strategyMode === 'distribution') {
    const ethVal = (parseFloat(ethTokens) || 0) * ethPriceNum;
    const btcVal = (parseFloat(btcTokens) || 0) * btcPriceNum;
    const avaxVal = (parseFloat(avaxTokens) || 0) * avaxPriceNum;
    totalCapNum = ethVal + btcVal + avaxVal;
    
    if (totalCapNum > 0) {
      allocEthNum = (ethVal / totalCapNum) * 100;
      allocBtcNum = (btcVal / totalCapNum) * 100;
      allocAvaxNum = (avaxVal / totalCapNum) * 100;
    }
  }

  const ethCap = totalCapNum * (allocEthNum / 100);
  const btcCap = totalCapNum * (allocBtcNum / 100);
  const avaxCap = totalCapNum * (allocAvaxNum / 100);

  // Calculations
  const calculatePool = (
    cap: number, 
    price: number, 
    assetPct: number, 
    usdcPct: number, 
    refPool: Pool | undefined, 
    targetShare: number,
    manualRange: string,
    enabled: boolean
  ) => {
    if (!refPool || price <= 0 || !enabled) return null;

    const refRange0 = refPool.max_range - refPool.min_range;
    // Use 7D APR if available, otherwise fall back to Since Start
    const refApr0 = refPool.apr7D || refPool.aprSinceStart || 0;
    
    // Price scaling factor: ranges should scale with price to maintain relative width
    // Use Geometric Mean for more accurate reference price in Uniswap V3
    const refPrice = Math.sqrt(refPool.min_range * refPool.max_range);
    const priceScale = price / refPrice;

    let range = 0;
    let apr = 0;
    let k = 0;

    if (mode === 'split') {
      const targetMonth = (parseFloat(targetIncome) || 0) * (targetShare / 100);
      const monthAtW0 = (cap * (refApr0 / 100)) / 12;
      k = monthAtW0 === 0 ? (targetMonth === 0 ? 1 : 999) : targetMonth / monthAtW0;
      // Apply price scaling to the range
      range = k > 0 ? (refRange0 / k) * priceScale : 0;
      apr = refApr0 * k;
    } else {
      range = parseFloat(manualRange) || 0;
      // When calculating APR from manual range, we must also account for price scaling
      // If range is wider than (refRange0 * priceScale), APR is lower
      apr = range > 0 ? refApr0 * ((refRange0 * priceScale) / range) : 0;
      k = refApr0 === 0 ? 0 : apr / refApr0;
    }

    const monthIncome = (cap * (apr / 100)) / 12;
    const refIncome = (cap * (refApr0 / 100)) / 12;
    const down = range * (usdcPct / 100);
    const up = range * (assetPct / 100);
    const lower = price - down;
    const upper = price + up;

    // After lower analytics
    const assetUsd0 = cap * (assetPct / 100);
    const usdcUsd0 = cap * (usdcPct / 100);
    const assetUnits0 = assetUsd0 / price;
    const addUnits = usdcUsd0 / (Math.sqrt(Math.max(0.000001, lower)) * Math.sqrt(Math.max(0.000001, price)));
    const unitsAfter = assetUnits0 + addUnits;
    const valueAtLower = unitsAfter * lower;
    const pnlTotal = valueAtLower - cap;

    // After upper analytics (Distribution Mode)
    const addUsdc = assetUsd0 * (Math.sqrt(Math.max(0.000001, price)) * Math.sqrt(Math.max(0.000001, upper))) / (Math.sqrt(Math.max(0.000001, price)) * Math.sqrt(Math.max(0.000001, upper)));
    // Simplified: at upper bound, all asset is converted to USDC
    // In Uniswap V3, if price goes from P to Pb (upper), asset is sold for USDC.
    // The amount of USDC received is Asset * sqrt(P * Pb)
    const usdcReceivedAtUpper = assetUnits0 * Math.sqrt(price * upper);
    const totalUsdcAtUpper = usdcUsd0 + usdcReceivedAtUpper;
    const pnlAtUpper = totalUsdcAtUpper - cap;

    return {
      cap,
      range,
      apr,
      refApr: refApr0,
      monthIncome,
      refIncome,
      lower,
      upper,
      down,
      up,
      k,
      unitsAfter,
      valueAtLower,
      pnlTotal,
      assetUnits0,
      usdcUsd0,
      usdcReceivedAtUpper,
      totalUsdcAtUpper,
      pnlAtUpper
    };
  };

  const ethResult = calculatePool(ethCap, ethPriceNum, parseFloat(ethAssetPct), ethUsdcPct, ethRef, parseFloat(ethTargetShare), ethManualRange, ethEnabled);
  const btcResult = calculatePool(btcCap, btcPriceNum, parseFloat(btcAssetPct), btcUsdcPct, btcRef, parseFloat(btcTargetShare), btcManualRange, btcEnabled);
  const avaxResult = calculatePool(avaxCap, avaxPriceNum, parseFloat(avaxAssetPct), avaxUsdcPct, avaxRef, avaxTargetShare, avaxManualRange, avaxEnabled);

  // Use strategy income for the dashboard
  const totalMonthly = (ethResult?.monthIncome || 0) + (btcResult?.monthIncome || 0) + (avaxResult?.monthIncome || 0);
  const totalApr = totalCapNum > 0 ? (totalMonthly * 12 / totalCapNum) * 100 : 0;
  const targetNum = parseFloat(targetIncome) || 0;
  const targetApr = totalCapNum > 0 ? (targetNum * 12 / totalCapNum) * 100 : 0;
  const delta = totalMonthly - targetNum;

  const getAssetColor = (enabled: boolean) => enabled ? 'text-[#141414]' : 'text-[#141414]/40';
  const getPriceColor = (enabled: boolean) => enabled ? 'text-[#141414]' : 'text-[#141414]/30';

  const [showRebalance, setShowRebalance] = React.useState(false);
  const [isMatrixLoading, setIsMatrixLoading] = React.useState(false);

  // Rebalance State
  const [ethRebLtv, setEthRebLtv] = React.useState('30');
  const [ethRebLt, setEthRebLt] = React.useState('88');
  const [ethRebCf, setEthRebCf] = React.useState('85');
  const [ethRebBr, setEthRebBr] = React.useState('3.94');
  const [ethRebDays, setEthRebDays] = React.useState('0');
  const [ethRebAssetPct, setEthRebAssetPct] = React.useState('5');

  const [btcRebLtv, setBtcRebLtv] = React.useState('30');
  const [btcRebLt, setBtcRebLt] = React.useState('85');
  const [btcRebCf, setBtcRebCf] = React.useState('80');
  const [btcRebBr, setBtcRebBr] = React.useState('3.94');
  const [btcRebDays, setBtcRebDays] = React.useState('0');
  const [btcRebAssetPct, setBtcRebAssetPct] = React.useState('5');

  const [avaxRebLtv, setAvaxRebLtv] = React.useState('30');
  const [avaxRebLt, setAvaxRebLt] = React.useState('80');
  const [avaxRebCf, setAvaxRebCf] = React.useState('75');
  const [avaxRebBr, setAvaxRebBr] = React.useState('3.94');
  const [avaxRebDays, setAvaxRebDays] = React.useState('0');
  const [avaxRebAssetPct, setAvaxRebAssetPct] = React.useState('5');

  const [rebTargetIncome, setRebTargetIncome] = React.useState<string>('');

  const handleContinue = () => {
    setIsMatrixLoading(true);
    setTimeout(() => {
      setIsMatrixLoading(false);
      setShowRebalance(true);
    }, 1500);
  };

  const handleReset = () => {
    setEthRebLtv('30');
    setEthRebLt('88');
    setEthRebCf('85');
    setEthRebBr('3.94');
    setEthRebDays('0');
    setEthRebAssetPct('5');

    setBtcRebLtv('30');
    setBtcRebLt('85');
    setBtcRebCf('80');
    setBtcRebBr('3.94');
    setBtcRebDays('0');
    setBtcRebAssetPct('5');

    setAvaxRebLtv('30');
    setAvaxRebLt('80');
    setAvaxRebCf('75');
    setAvaxRebBr('3.94');
    setAvaxRebDays('0');
    setAvaxRebAssetPct('5');

    setRebTargetIncome('');
    setShowRebalance(false);
  };

  const calculateRebalance = (
    poolKey: 'eth' | 'btc' | 'avax',
    res: any,
    refPool: Pool | undefined,
    ltv: string,
    lt: string,
    cf: string,
    br: string,
    days: string,
    assetPct: string,
    targetShare: number,
    globalTarget: string,
    manualPrice: string,
    mode: 'swap' | 'loan'
  ) => {
    if (!res || !refPool) return null;

    const ltvNum = parseFloat(ltv) || 0;
    const ltNum = parseFloat(lt) || 0;
    const cfNum = parseFloat(cf) || 0;
    const brNum = parseFloat(br) || 0;
    const daysNum = parseFloat(days) || 0;
    const assetPctNum = parseFloat(assetPct) || 0;
    const usdcPctNum = 100 - assetPctNum;
    const targetIncomeNum = parseFloat(globalTarget || targetIncome) || 0;

    const collateralUnits1 = res.unitsAfter;
    const priceReb = parseFloat(manualPrice) || res.lower; // Use manual price if provided, else lower bound
    
    const collateralValueUsed = collateralUnits1 * priceReb; // Always use 100%

    // The user wants the TOTAL Working Capital to be the % of collateral
    const cap = collateralValueUsed * (ltvNum / 100);
    // The borrowed amount is the USDC portion of that capital
    const borrowUsd0 = cap * (usdcPctNum / 100);
    const debtUsd = borrowUsd0 * (1 + (brNum / 100) * (daysNum / 365));

    const maxBorrowByCF = collateralValueUsed * (cfNum / 100);
    
    const capAssetUsd = cap * (assetPctNum / 100);
    const capUsdcUsd = borrowUsd0;
    const unitsNew0 = capAssetUsd / priceReb;

    // Calibration for new pool
    const refRange0 = refPool.max_range - refPool.min_range;
    const refApr0 = refPool.apr7D || refPool.aprSinceStart || 0;
    // Use Geometric Mean for more accurate reference price in Uniswap V3
    const refPrice = Math.sqrt(refPool.min_range * refPool.max_range);
    const priceScale = priceReb / refPrice;

    const poolTarget = targetIncomeNum * (targetShare / 100);
    const income0 = (cap * (refApr0 / 100)) / 12;
    const k = income0 === 0 ? 1 : poolTarget / income0;
    
    // Apply price scaling to rebalance range
    const rangeNew = k > 0 ? (refRange0 / k) * priceScale : 0;
    const aprNew = refApr0 * k;

    const down = rangeNew * (usdcPctNum / 100);
    const up = rangeNew * (assetPctNum / 100);
    const lower = priceReb - down;
    const upper = priceReb + up;

    const hfNow = (collateralValueUsed * (ltNum / 100)) / debtUsd;
    const liqP = debtUsd / (collateralUnits1 * (ltNum / 100));

    // After 2nd lower
    const addUnits2 = capUsdcUsd / (Math.sqrt(Math.max(0.000001, lower)) * Math.sqrt(Math.max(0.000001, priceReb)));
    const unitsFrom2 = (capAssetUsd / priceReb) + addUnits2;
    const collateralUnits2 = collateralUnits1 + unitsFrom2;
    const hfAtLower2 = (collateralUnits2 * lower * (ltNum / 100)) / debtUsd;
    const liqP2 = debtUsd / (collateralUnits2 * (ltNum / 100));
    const totalAssetValueAtLiq = collateralUnits2 * liqP2;

    return {
      collateralUnits1,
      collateralValueUsed,
      borrowUsd0,
      debtUsd,
      maxBorrowByCF,
      cap,
      rangeNew,
      aprNew,
      lower,
      upper,
      hfNow,
      liqP,
      unitsFrom2,
      collateralUnits2,
      hfAtLower2,
      liqP2,
      totalAssetValueAtLiq,
      priceReb
    };
  };

  const ethReb = calculateRebalance('eth', ethResult, ethRef, ethRebLtv, ethRebLt, ethRebCf, ethRebBr, ethRebDays, ethRebAssetPct, parseFloat(ethTargetShare), rebTargetIncome, ethManualRebPrice, 'loan');
  const btcReb = calculateRebalance('btc', btcResult, btcRef, btcRebLtv, btcRebLt, btcRebCf, btcRebBr, btcRebDays, btcRebAssetPct, parseFloat(btcTargetShare), rebTargetIncome, btcManualRebPrice, 'loan');
  const avaxReb = calculateRebalance('avax', avaxResult, avaxRef, avaxRebLtv, avaxRebLt, avaxRebCf, avaxRebBr, avaxRebDays, avaxRebAssetPct, avaxTargetShare, rebTargetIncome, avaxManualRebPrice, 'loan');

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-20 relative">
      {isMatrixLoading && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            {/* Matrix rain simulation */}
            <div className="flex justify-around w-full h-full font-mono text-emerald-500 text-xs">
              {Array.from({ length: 20 }).map((_, i) => (
                <div key={i} className="animate-bounce" style={{ animationDuration: `${Math.random() * 2 + 1}s` }}>
                  {Array.from({ length: 40 }).map((_, j) => (
                    <div key={j}>{Math.random() > 0.5 ? '1' : '0'}</div>
                  ))}
                </div>
              ))}
            </div>
          </div>
          <div className="relative z-10 text-center space-y-4">
            <div className="font-mono text-emerald-500 text-xl font-bold tracking-[0.5em] uppercase">Initializing Rebalance</div>
            <div className="w-64 h-1 bg-emerald-500/20 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 animate-[progress_1.5s_ease-in-out]" style={{ width: '100%' }} />
            </div>
          </div>
        </div>
      )}

      <header className="flex flex-col sm:flex-row sm:justify-between sm:items-end border-b border-[#141414] pb-6 gap-4">
        <div className="flex flex-col sm:flex-row sm:items-end gap-6">
          <div>
            <h1 className="font-serif italic text-4xl sm:text-5xl mb-2">LP Strategy</h1>
            <div className="flex gap-2 mt-4">
              <button 
                onClick={() => {
                  setStrategyMode('accumulation');
                  setEthAssetPct('5');
                  setBtcAssetPct('5');
                  setAvaxAssetPct('5');
                }}
                className={`px-4 py-2 font-mono text-[10px] uppercase tracking-widest border border-[#141414] transition-colors ${strategyMode === 'accumulation' ? 'bg-[#141414] text-[#E4E3E0]' : 'hover:bg-[#141414]/5'}`}
              >
                Стратегия накопления
              </button>
              <button 
                onClick={() => {
                  setStrategyMode('distribution');
                  setEthAssetPct('95');
                  setBtcAssetPct('95');
                  setAvaxAssetPct('95');
                }}
                className={`px-4 py-2 font-mono text-[10px] uppercase tracking-widest border border-[#141414] transition-colors ${strategyMode === 'distribution' ? 'bg-[#141414] text-[#E4E3E0]' : 'hover:bg-[#141414]/5'}`}
              >
                Стратегия распределения
              </button>
            </div>
            <p className="font-mono text-xs opacity-50 uppercase tracking-widest mt-4">Asymmetric Range Optimization & Risk Simulation</p>
          </div>
          
          {fngData && (
            <div className="flex items-center gap-4 border-l border-[#141414] pl-6 h-12 mb-1 hidden lg:flex">
              <div className="flex flex-col">
                <span className="font-mono text-[8px] uppercase opacity-50 tracking-tighter">Fear & Greed Index</span>
                <div className="flex items-baseline gap-2">
                  <span className="font-serif italic text-3xl leading-none">{fngData.value}</span>
                  <span className={`font-mono text-[10px] uppercase tracking-widest font-bold ${
                    parseInt(fngData.value) <= 25 ? 'text-red-600' :
                    parseInt(fngData.value) <= 45 ? 'text-orange-600' :
                    parseInt(fngData.value) <= 55 ? 'text-amber-600' :
                    parseInt(fngData.value) <= 75 ? 'text-emerald-600' :
                    'text-green-600'
                  }`}>
                    {fngData.classification}
                  </span>
                </div>
              </div>
              <div className="w-24 h-1.5 bg-[#141414]/10 rounded-full overflow-hidden flex">
                <div 
                  className={`h-full transition-all duration-1000 ${
                    parseInt(fngData.value) <= 25 ? 'bg-red-600' :
                    parseInt(fngData.value) <= 45 ? 'bg-orange-600' :
                    parseInt(fngData.value) <= 55 ? 'bg-amber-600' :
                    parseInt(fngData.value) <= 75 ? 'bg-emerald-600' :
                    'bg-green-600'
                  }`}
                  style={{ width: `${fngData.value}%` }}
                />
              </div>
            </div>
          )}
        </div>
        <button 
          onClick={fetchPrices}
          disabled={isFetchingPrices}
          className="flex items-center justify-center gap-2 border border-[#141414] px-4 py-3 sm:py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors disabled:opacity-50 w-full sm:w-auto"
        >
          <RefreshCw className={`w-3 h-3 ${isFetchingPrices ? 'animate-spin' : ''}`} />
          Sync Live Prices
        </button>
      </header>

      {/* Calibration Pools */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <Zap className="w-5 h-5" />
          <h2 className="font-serif italic text-2xl">Calibration Pools</h2>
          <span className="font-mono text-[10px] opacity-50 uppercase tracking-widest bg-[#141414] text-[#E4E3E0] px-2 py-0.5">Reference Data</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { label: 'ETH Reference', id: ethRefId, setId: setEthRefId, ref: ethRef, filter: 'ETH', enabled: ethEnabled, setEnabled: setEthEnabled },
            { label: 'BTC Reference', id: btcRefId, setId: setBtcRefId, ref: btcRef, filter: 'BTC', enabled: btcEnabled, setEnabled: setBtcEnabled },
            { label: 'AVAX Reference', id: avaxRefId, setId: setAvaxRefId, ref: avaxRef, filter: 'AVAX', enabled: avaxEnabled, setEnabled: setAvaxEnabled }
          ].map((item, idx) => (
            <div key={idx} className={`border border-[#141414] p-6 bg-white/30 space-y-4 transition-opacity ${!item.enabled ? 'opacity-40' : ''}`}>
              <div className="flex justify-between items-center">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50 block">{item.label}</label>
                {!isGuest && (
                  <input 
                    type="checkbox" 
                    checked={item.enabled} 
                    onChange={e => item.setEnabled(e.target.checked)}
                    className="accent-[#141414]"
                  />
                )}
              </div>
              {isGuest ? (
                <div className="font-serif italic text-lg py-2">Average {item.filter} Pool</div>
              ) : (
                <select 
                  value={item.id}
                  disabled={!item.enabled}
                  onChange={e => {
                    const val = e.target.value;
                    if (!val) {
                      item.setId('');
                      return;
                    }
                    const found = pools.find(p => String(p.id) === val);
                    if (found) item.setId(found.id);
                  }}
                  className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none disabled:cursor-not-allowed"
                >
                  <option value="">Select pool...</option>
                  {pools.filter(p => p.pair.toUpperCase().includes(item.filter) || p.network === 'Avalanche' && item.filter === 'AVAX').map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              )}
              {item.ref && (
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <div className="font-mono text-[8px] uppercase opacity-50">Ref Range</div>
                    <div className="font-mono text-sm">${(item.ref.max_range - item.ref.min_range).toLocaleString()}</div>
                  </div>
                  <div>
                    <div className="font-mono text-[8px] uppercase opacity-50">Ref APR (7D/Avg)</div>
                    <div className="font-mono text-sm text-emerald-600">
                      {(item.ref.apr7D || item.ref.aprSinceStart || 0).toFixed(2)}%
                    </div>
                  </div>
                </div>
              )}
              {isGuest && (
                <div className="font-mono text-[8px] opacity-30 uppercase tracking-widest pt-2 border-t border-[#141414]/10">
                  Aggregated from {pools.filter(p => p.pair.toUpperCase().includes(item.filter) || p.network === 'Avalanche' && item.filter === 'AVAX').length} sources
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Portfolio & Split */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <DollarSign className="w-5 h-5" />
              <h2 className="font-serif italic text-2xl">Real Portfolio</h2>
            </div>
            <label className="flex items-center gap-2 cursor-pointer group">
              <span className="font-mono text-[10px] uppercase tracking-widest opacity-50 group-hover:opacity-100 transition-opacity">Manual Price</span>
              <input 
                type="checkbox" 
                checked={isManualPrice}
                onChange={e => toggleManualPrice(e.target.checked)}
                className="accent-[#141414] w-3 h-3"
              />
            </label>
          </div>
          <div className="border border-[#141414] p-6 sm:p-8 bg-white/30 space-y-6">
            {strategyMode === 'accumulation' ? (
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Total Capital ($)</label>
                <input 
                  type="number" 
                  value={totalCapital}
                  onChange={e => setTotalCapital(e.target.value)}
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-lg focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                />
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">ETH Tokens</label>
                  <input 
                    type="number" 
                    value={ethTokens}
                    onChange={e => setEthTokens(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">BTC Tokens</label>
                  <input 
                    type="number" 
                    value={btcTokens}
                    onChange={e => setBtcTokens(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">AVAX Tokens</label>
                  <input 
                    type="number" 
                    value={avaxTokens}
                    onChange={e => setAvaxTokens(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
              </div>
            )}

            {strategyMode === 'accumulation' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getAssetColor(ethEnabled)}`}>Alloc to ETH (%)</label>
                  <input 
                    type="number" 
                    value={allocEth}
                    disabled={!ethEnabled}
                    onChange={e => handleAllocChange('ETH', e.target.value)}
                    className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getAssetColor(ethEnabled)} disabled:opacity-30`}
                  />
                  <div className={`font-mono text-[10px] font-bold ${getAssetColor(ethEnabled)}`}>
                    ${(totalCapNum * (parseFloat(allocEth) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                  </div>
                </div>
                <div className="space-y-2">
                  <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getAssetColor(btcEnabled)}`}>Alloc to BTC (%)</label>
                  <input 
                    type="number" 
                    value={allocBtc}
                    disabled={!btcEnabled}
                    onChange={e => handleAllocChange('BTC', e.target.value)}
                    className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getAssetColor(btcEnabled)} disabled:opacity-30`}
                  />
                  <div className={`font-mono text-[10px] font-bold ${getAssetColor(btcEnabled)}`}>
                    ${(totalCapNum * (parseFloat(allocBtc) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                  </div>
                </div>
                <div className="space-y-2">
                  <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getAssetColor(avaxEnabled)}`}>Alloc to AVAX (%)</label>
                  <input 
                    type="number" 
                    value={allocAvax}
                    disabled={!avaxEnabled}
                    onChange={e => handleAllocChange('AVAX', e.target.value)}
                    className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getAssetColor(avaxEnabled)} disabled:opacity-30`}
                  />
                  <div className={`font-mono text-[10px] font-bold ${getAssetColor(avaxEnabled)}`}>
                    ${(totalCapNum * (parseFloat(allocAvax) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                  </div>
                </div>
              </div>
            )}

            {strategyMode === 'distribution' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <div className="font-mono text-[8px] uppercase opacity-50">ETH Allocation</div>
                  <div className="font-mono text-sm font-bold">{allocEthNum.toFixed(2)}%</div>
                  <div className="font-mono text-[10px] opacity-40">${ethCap.toLocaleString()}</div>
                </div>
                <div className="space-y-1">
                  <div className="font-mono text-[8px] uppercase opacity-50">BTC Allocation</div>
                  <div className="font-mono text-sm font-bold">{allocBtcNum.toFixed(2)}%</div>
                  <div className="font-mono text-[10px] opacity-40">${btcCap.toLocaleString()}</div>
                </div>
                <div className="space-y-1">
                  <div className="font-mono text-[8px] uppercase opacity-50">AVAX Allocation</div>
                  <div className="font-mono text-sm font-bold">{allocAvaxNum.toFixed(2)}%</div>
                  <div className="font-mono text-[10px] opacity-40">${avaxCap.toLocaleString()}</div>
                </div>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getPriceColor(ethEnabled)}`}>ETH Price ($)</label>
                <input 
                  type="number" 
                  value={ethPrice}
                  onChange={e => setEthPrice(e.target.value)}
                  className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getPriceColor(ethEnabled)}`}
                />
              </div>
              <div className="space-y-2">
                <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getPriceColor(btcEnabled)}`}>BTC Price ($)</label>
                <input 
                  type="number" 
                  value={btcPrice}
                  onChange={e => setBtcPrice(e.target.value)}
                  className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getPriceColor(btcEnabled)}`}
                />
              </div>
              <div className="space-y-2">
                <label className={`font-mono text-[10px] uppercase tracking-widest opacity-50 ${getPriceColor(avaxEnabled)}`}>AVAX Price ($)</label>
                <input 
                  type="number" 
                  value={avaxPrice}
                  onChange={e => setAvaxPrice(e.target.value)}
                  className={`w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none ${getPriceColor(avaxEnabled)}`}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="flex items-center gap-3 mb-2">
            <RefreshCw className="w-5 h-5" />
            <h2 className="font-serif italic text-2xl">Split within Range</h2>
          </div>
          <div className="border border-[#141414] p-6 sm:p-8 bg-white/30 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">ETH Pool: % Asset</label>
                <input 
                  type="number" 
                  value={ethAssetPct}
                  onChange={e => setEthAssetPct(e.target.value)}
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(ethCap * (parseFloat(ethAssetPct) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">ETH Pool: % USDC</label>
                <input 
                  type="number" 
                  value={ethUsdcPct}
                  readOnly
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm opacity-50 outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(ethCap * (ethUsdcPct / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">BTC Pool: % Asset</label>
                <input 
                  type="number" 
                  value={btcAssetPct}
                  onChange={e => setBtcAssetPct(e.target.value)}
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(btcCap * (parseFloat(btcAssetPct) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">BTC Pool: % USDC</label>
                <input 
                  type="number" 
                  value={btcUsdcPct}
                  readOnly
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm opacity-50 outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(btcCap * (btcUsdcPct / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">AVAX Pool: % Asset</label>
                <input 
                  type="number" 
                  value={avaxAssetPct}
                  onChange={e => setAvaxAssetPct(e.target.value)}
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(avaxCap * (parseFloat(avaxAssetPct) / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">AVAX Pool: % USDC</label>
                <input 
                  type="number" 
                  value={avaxUsdcPct}
                  readOnly
                  className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm opacity-50 outline-none"
                />
                <div className="font-mono text-[10px] text-[#141414] font-bold mt-1">
                  ${(avaxCap * (avaxUsdcPct / 100)).toLocaleString(undefined, { maximumFractionDigits: 2 })} USDC
                </div>
              </div>
            </div>
            <p className="text-[10px] font-mono opacity-50 italic">
              Asymmetric bounds: Down = Range × USDC%, Up = Range × Asset%.
            </p>
          </div>
        </div>
      </section>

      {/* Target & Results */}
      <section className="space-y-8">
        <div className="flex items-center gap-3 mb-2">
          <Target className="w-5 h-5" />
          <h2 className="font-serif italic text-2xl">Target & Calculation</h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="border border-[#141414] p-6 sm:p-8 bg-white/30 space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-end">
                <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Monthly Target ($)</label>
                <div className="font-mono text-[10px] uppercase tracking-widest text-emerald-600 font-bold">{targetApr.toFixed(2)}% APR</div>
              </div>
              <input 
                type="number" 
                value={targetIncome}
                onChange={e => setTargetIncome(e.target.value)}
                className="w-full bg-transparent border border-[#141414] p-3 font-mono text-lg focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
              />
            </div>
            <div className="space-y-4">
              <label className="font-mono text-[10px] uppercase tracking-widest opacity-50 block">Mode</label>
              <div className="flex flex-col sm:flex-row gap-2">
                <button 
                  onClick={() => setMode('split')}
                  className={`flex-1 py-3 sm:py-2 font-mono text-[10px] uppercase tracking-widest border border-[#141414] transition-colors ${mode === 'split' ? 'bg-[#141414] text-[#E4E3E0]' : 'hover:bg-[#141414]/5'}`}
                >
                  Auto Split
                </button>
                <button 
                  onClick={() => setMode('manual')}
                  className={`flex-1 py-3 sm:py-2 font-mono text-[10px] uppercase tracking-widest border border-[#141414] transition-colors ${mode === 'manual' ? 'bg-[#141414] text-[#E4E3E0]' : 'hover:bg-[#141414]/5'}`}
                >
                  Manual Range
                </button>
              </div>
            </div>

            {mode === 'split' ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">ETH Share (%)</label>
                  <input 
                    type="number" 
                    value={ethTargetShare}
                    onChange={e => setEthTargetShare(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">BTC Share (%)</label>
                  <input 
                    type="number" 
                    value={btcTargetShare}
                    onChange={e => setBtcTargetShare(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="text-[10px] font-mono opacity-50">AVAX Share: {avaxTargetShare}%</div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">ETH Range ($)</label>
                  <input 
                    type="number" 
                    value={ethManualRange}
                    onChange={e => setEthManualRange(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">BTC Range ($)</label>
                  <input 
                    type="number" 
                    value={btcManualRange}
                    onChange={e => setBtcManualRange(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">AVAX Range ($)</label>
                  <input 
                    type="number" 
                    value={avaxManualRange}
                    onChange={e => setAvaxManualRange(e.target.value)}
                    className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0] outline-none"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-2 border border-[#141414] p-6 sm:p-8 bg-[#141414] text-[#E4E3E0] space-y-8">
            <div className="flex flex-col sm:flex-row justify-between items-start gap-6">
              <div className="flex flex-col sm:flex-row gap-8 sm:gap-12">
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-widest opacity-50 mb-1">Projected Income</div>
                  <div className="text-4xl sm:text-6xl font-bold tracking-tighter">${totalMonthly.toLocaleString(undefined, { maximumFractionDigits: 2 })}<span className="text-xl opacity-50">/mo</span></div>
                </div>
                <div>
                  <div className="font-mono text-[10px] uppercase tracking-widest opacity-50 mb-1">Portfolio APR</div>
                  <div className="text-4xl sm:text-6xl font-bold tracking-tighter text-emerald-400">{totalApr.toFixed(2)}%</div>
                </div>
              </div>
              <div className="text-left sm:text-right">
                <div className="font-mono text-[10px] uppercase tracking-widest opacity-50 mb-1">Status vs Target</div>
                <div className={`text-xl font-mono ${delta >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {delta >= 0 ? '+' : ''}${Math.abs(delta).toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-12 pt-8 border-t border-white/10">
              {/* ETH Results */}
              {ethResult && ethRef && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
                          {ethRef.name.toLowerCase().includes('trader joe') ? 'Trader Joe' : ethRef.name.split(' ')[0]}
                        </span>
                        {ethRef.name.toLowerCase().includes('uniswap') && (
                          <img 
                            src="https://icon.horse/icon/uniswap.org" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Uniswap" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {ethRef.name.toLowerCase().includes('aerodrome') && (
                          <img 
                            src="https://icon.horse/icon/aerodrome.finance" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Aerodrome" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {(ethRef.name.toLowerCase().includes('trader joe') || ethRef.name.toLowerCase().includes('lfj')) && (
                          <img 
                            src="https://icon.horse/icon/traderjoe.xyz" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="LFJ" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        <span className="font-mono text-[10px] font-bold opacity-70">
                          {ethRef.pair} {ethRef.fee_percent !== null && ethRef.fee_percent !== undefined ? `${ethRef.fee_percent}%` : ''}
                        </span>
                      </div>
                      <h3 className="font-serif font-bold text-lg leading-tight">{ethRef.network}</h3>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-emerald-400 text-3xl font-bold">{ethResult.apr.toFixed(2)}% APR</div>
                      <div className="font-mono text-[10px] opacity-50 uppercase tracking-widest">Initial Allocation: ${ethResult.cap.toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-2xl font-bold text-rose-400">${ethResult.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((ethResult.lower || 0) / ethPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-2xl font-bold text-emerald-400">${ethResult.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          +{((ethResult.upper || 0) / ethPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                        <div className="text-xl font-bold text-blue-400">${ethResult.range.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((ethResult.range || 0) / ethPriceNum * 100).toFixed(2)}% of price
                        </div>
                        <RangeHint symbol="ETHUSDT" lower={ethResult.lower} upper={ethResult.upper} />
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">MONTHLY INCOME</div>
                        <div className="text-xl font-bold text-emerald-400">${ethResult.monthIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>

                    {ethResult.pnlTotal !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Lower Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>Units After:</span> <span>{ethResult.unitsAfter.toFixed(6)} ETH</span></div>
                          <div className="flex justify-between"><span>Value @ Lower:</span> <span>${ethResult.valueAtLower.toLocaleString()}</span></div>
                          <div className="flex justify-between text-rose-400"><span>PnL @ Lower:</span> <span>${ethResult.pnlTotal.toLocaleString()}</span></div>
                        </div>
                      </div>
                    )}

                    {strategyMode === 'distribution' && ethResult.pnlAtUpper !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Upper Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>USDC @ Upper:</span> <span>${ethResult.totalUsdcAtUpper.toLocaleString()}</span></div>
                          <div className="flex justify-between text-emerald-400"><span>PnL @ Upper:</span> <span>${ethResult.pnlAtUpper.toLocaleString()}</span></div>
                          <div className="text-[8px] opacity-30 mt-1 italic">* All ETH converted to USDC at upper bound</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* BTC Results */}
              {btcResult && btcRef && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
                          {btcRef.name.toLowerCase().includes('trader joe') ? 'Trader Joe' : btcRef.name.split(' ')[0]}
                        </span>
                        {btcRef.name.toLowerCase().includes('uniswap') && (
                          <img 
                            src="https://icon.horse/icon/uniswap.org" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Uniswap" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {btcRef.name.toLowerCase().includes('aerodrome') && (
                          <img 
                            src="https://icon.horse/icon/aerodrome.finance" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Aerodrome" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {(btcRef.name.toLowerCase().includes('trader joe') || btcRef.name.toLowerCase().includes('lfj')) && (
                          <img 
                            src="https://icon.horse/icon/traderjoe.xyz" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="LFJ" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        <span className="font-mono text-[10px] font-bold opacity-70">
                          {btcRef.pair} {btcRef.fee_percent !== null && btcRef.fee_percent !== undefined ? `${btcRef.fee_percent}%` : ''}
                        </span>
                      </div>
                      <h3 className="font-serif font-bold text-lg leading-tight">{btcRef.network}</h3>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-emerald-400 text-3xl font-bold">{btcResult.apr.toFixed(2)}% APR</div>
                      <div className="font-mono text-[10px] opacity-50 uppercase tracking-widest">Initial Allocation: ${btcResult.cap.toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-2xl font-bold text-rose-400">${btcResult.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((btcResult.lower || 0) / btcPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-2xl font-bold text-emerald-400">${btcResult.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          +{((btcResult.upper || 0) / btcPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                        <div className="text-xl font-bold text-blue-400">${btcResult.range.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((btcResult.range || 0) / btcPriceNum * 100).toFixed(2)}% of price
                        </div>
                        <RangeHint symbol="BTCUSDT" lower={btcResult.lower} upper={btcResult.upper} />
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">MONTHLY INCOME</div>
                        <div className="text-xl font-bold text-emerald-400">${btcResult.monthIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>

                    {btcResult.pnlTotal !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Lower Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>Units After:</span> <span>{btcResult.unitsAfter.toFixed(6)} BTC</span></div>
                          <div className="flex justify-between"><span>Value @ Lower:</span> <span>${btcResult.valueAtLower.toLocaleString()}</span></div>
                          <div className="flex justify-between text-rose-400"><span>PnL @ Lower:</span> <span>${btcResult.pnlTotal.toLocaleString()}</span></div>
                        </div>
                      </div>
                    )}

                    {strategyMode === 'distribution' && btcResult.pnlAtUpper !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Upper Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>USDC @ Upper:</span> <span>${btcResult.totalUsdcAtUpper.toLocaleString()}</span></div>
                          <div className="flex justify-between text-emerald-400"><span>PnL @ Upper:</span> <span>${btcResult.pnlAtUpper.toLocaleString()}</span></div>
                          <div className="text-[8px] opacity-30 mt-1 italic">* All BTC converted to USDC at upper bound</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* AVAX Results */}
              {avaxResult && avaxRef && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
                          {avaxRef.name.toLowerCase().includes('trader joe') ? 'Trader Joe' : avaxRef.name.split(' ')[0]}
                        </span>
                        {avaxRef.name.toLowerCase().includes('uniswap') && (
                          <img 
                            src="https://icon.horse/icon/uniswap.org" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Uniswap" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {avaxRef.name.toLowerCase().includes('aerodrome') && (
                          <img 
                            src="https://icon.horse/icon/aerodrome.finance" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="Aerodrome" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        {(avaxRef.name.toLowerCase().includes('trader joe') || avaxRef.name.toLowerCase().includes('lfj')) && (
                          <img 
                            src="https://icon.horse/icon/traderjoe.xyz" 
                            className="w-4 h-4 rounded-full object-contain" 
                            alt="LFJ" 
                            referrerPolicy="no-referrer"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                        )}
                        <span className="font-mono text-[10px] font-bold opacity-70">
                          {avaxRef.pair} {avaxRef.fee_percent !== null && avaxRef.fee_percent !== undefined ? `${avaxRef.fee_percent}%` : ''}
                        </span>
                      </div>
                      <h3 className="font-serif font-bold text-lg leading-tight">{avaxRef.network}</h3>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-emerald-400 text-3xl font-bold">{avaxResult.apr.toFixed(2)}% APR</div>
                      <div className="font-mono text-[10px] opacity-50 uppercase tracking-widest">Initial Allocation: ${avaxResult.cap.toLocaleString()}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-2xl font-bold text-rose-400">${avaxResult.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((avaxResult.lower || 0) / avaxPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-2xl font-bold text-emerald-400">${avaxResult.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          +{((avaxResult.upper || 0) / avaxPriceNum * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                        <div className="text-xl font-bold text-blue-400">${avaxResult.range.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[10px] opacity-30 mt-1">
                          {((avaxResult.range || 0) / avaxPriceNum * 100).toFixed(2)}% of price
                        </div>
                        <RangeHint symbol="AVAXUSDT" lower={avaxResult.lower} upper={avaxResult.upper} />
                      </div>
                      <div className="p-4 bg-white/5 border border-white/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">MONTHLY INCOME</div>
                        <div className="text-xl font-bold text-emerald-400">${avaxResult.monthIncome.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>

                    {avaxResult.pnlTotal !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Lower Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>Units After:</span> <span>{avaxResult.unitsAfter.toFixed(6)} AVAX</span></div>
                          <div className="flex justify-between"><span>Value @ Lower:</span> <span>${avaxResult.valueAtLower.toLocaleString()}</span></div>
                          <div className="flex justify-between text-rose-400"><span>PnL @ Lower:</span> <span>${avaxResult.pnlTotal.toLocaleString()}</span></div>
                        </div>
                      </div>
                    )}

                    {strategyMode === 'distribution' && avaxResult.pnlAtUpper !== 0 && (
                      <div className="pt-4 border-t border-white/5">
                        <div className="font-mono text-[8px] opacity-50 uppercase mb-2">After Upper Analysis</div>
                        <div className="space-y-1 text-[10px] font-mono">
                          <div className="flex justify-between"><span>USDC @ Upper:</span> <span>${avaxResult.totalUsdcAtUpper.toLocaleString()}</span></div>
                          <div className="flex justify-between text-emerald-400"><span>PnL @ Upper:</span> <span>${avaxResult.pnlAtUpper.toLocaleString()}</span></div>
                          <div className="text-[8px] opacity-30 mt-1 italic">* All AVAX converted to USDC at upper bound</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Rebalance Module */}
      {strategyMode === 'accumulation' && (
        <section className="border-t border-[#141414] pt-12">
          {isGuest ? (
            <div className="bg-[#141414]/5 p-12 text-center space-y-6 border border-dashed border-[#141414]/30">
              <Lock className="w-12 h-12 mx-auto opacity-20" />
              <div>
                <h3 className="font-serif italic text-2xl">Rebalance & Liquidation Risk Module</h3>
                <p className="font-mono text-xs opacity-50 uppercase tracking-widest mt-2">Advanced risk management for Fluid / Lending protocols</p>
              </div>
              <div className="space-y-4">
                <p className="font-mono text-sm opacity-70">This module requires an approved account to access advanced liquidation simulations.</p>
                <button 
                  className="bg-[#141414] text-[#E4E3E0] px-8 py-4 font-mono text-xs uppercase tracking-widest hover:opacity-90 transition-opacity"
                  onClick={login}
                >
                  Authorize with Google
                </button>
              </div>
            </div>
          ) : !showRebalance ? (
            <div className="bg-[#141414]/5 p-12 text-center space-y-6">
              <ShieldAlert className="w-12 h-12 mx-auto opacity-20" />
              <div>
                <h3 className="font-serif italic text-2xl">Rebalance & Liquidation Risk Module</h3>
                <p className="font-mono text-xs opacity-50 uppercase tracking-widest mt-2">Advanced risk management for Fluid / Lending protocols</p>
              </div>
              <button 
                className="bg-[#141414] text-[#E4E3E0] px-8 py-4 font-mono text-xs uppercase tracking-widest hover:opacity-90 transition-opacity"
                onClick={handleContinue}
              >
                Initialize Rebalance Analysis
              </button>
            </div>
          ) : (
            <div className="space-y-12">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <RefreshCw className="w-5 h-5" />
                  <h2 className="font-serif italic text-3xl">Rebalance + Liquidation Risk</h2>
                </div>
                <div className="flex items-center gap-4 bg-white/30 border border-[#141414] p-4">
                  <div className="space-y-1">
                    <label className="font-mono text-[10px] uppercase tracking-widest opacity-50 block">Rebalance Target Income ($)</label>
                    <input 
                      type="number" 
                      placeholder={targetIncome}
                      value={rebTargetIncome}
                      onChange={e => setRebTargetIncome(e.target.value)}
                      className="bg-transparent border-b border-[#141414] font-mono text-xl w-32 focus:outline-none"
                    />
                  </div>
                  <div className="font-mono text-[10px] opacity-30 max-w-[150px]">
                    Defaults to main target (${targetIncome}). Note: Narrower ranges occur when targeting high income with small borrowed capital.
                  </div>
                </div>
              </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* ETH Rebalance */}
              <div className="border border-[#141414] p-8 bg-white/30 space-y-6">
                <h3 className="font-serif italic text-xl border-b border-[#141414] pb-2 flex justify-between items-end">
                  <span>ETH Rebalance</span>
                  <span className="font-mono text-[10px] opacity-50">Target: ${((parseFloat(rebTargetIncome || targetIncome) || 0) * (parseFloat(ethTargetShare) / 100)).toLocaleString()}</span>
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">Reb Price ($)</label>
                      <input 
                        type="number" 
                        placeholder={ethResult?.lower.toFixed(2)}
                        value={ethManualRebPrice} 
                        onChange={e => setEthManualRebPrice(e.target.value)}
                        className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">LTV (%)</label>
                      <input 
                        type="number" 
                        value={ethRebLtv} 
                        onChange={e => setEthRebLtv(e.target.value)} 
                        className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" 
                      />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">LT (%)</label>
                    <input type="number" value={ethRebLt} onChange={e => setEthRebLt(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">CF (%)</label>
                    <input type="number" value={ethRebCf} onChange={e => setEthRebCf(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">Borrow %</label>
                    <input type="number" value={ethRebBr} onChange={e => setEthRebBr(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                </div>

                {ethReb && (
                  <div className="space-y-4 pt-4 border-t border-[#141414]">
                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Working Capital (LP Position)</div>
                      <div className="text-2xl font-bold text-emerald-600">${ethReb.cap.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-2 flex justify-between border-t border-[#141414]/5 pt-2">
                        <span>Borrowed (Debt):</span>
                        <span className="font-bold text-[#141414]">${ethReb.borrowUsd0.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                      </div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Range is calculated based on total LP value: Borrowed USDC + Paired Asset from collateral.
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-xl font-bold text-rose-600">${ethReb.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          {((ethReb.lower / ethReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-xl font-bold text-emerald-600">${ethReb.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          +{((ethReb.upper / ethReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                      <div className="text-lg font-bold text-blue-600">${ethReb.rangeNew.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        {((ethReb.rangeNew / ethReb.priceReb) * 100).toFixed(2)}% of price
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Health Factor</div>
                        <div className={`text-xl font-bold ${ethReb.hfNow > 1.1 ? 'text-emerald-400' : 'text-rose-400'}`}>{ethReb.hfNow.toFixed(3)}</div>
                      </div>
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Liq Price</div>
                        <div className="text-xl font-bold text-rose-400">${ethReb.liqP.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>
                    <div className="p-4 border border-rose-500/30 bg-rose-500/5">
                      <div className="font-mono text-[10px] uppercase text-rose-500 font-bold mb-1">Final Liquidation (After Top-up)</div>
                      <div className="text-2xl font-bold text-rose-500">${ethReb.liqP2.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-1">HF @ Lower: {ethReb.hfAtLower2.toFixed(3)}</div>
                    </div>
                    
                    <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Total Asset Exposure at Liq</div>
                      <div className="text-2xl font-bold text-emerald-400">${ethReb.totalAssetValueAtLiq.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Total {ethReb.collateralUnits2.toFixed(4)} ETH held at ${ethReb.liqP2.toFixed(2)}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* BTC Rebalance */}
              <div className="border border-[#141414] p-8 bg-white/30 space-y-6">
                <h3 className="font-serif italic text-xl border-b border-[#141414] pb-2 flex justify-between items-end">
                  <span>BTC Rebalance</span>
                  <span className="font-mono text-[10px] opacity-50">Target: ${((parseFloat(rebTargetIncome || targetIncome) || 0) * (parseFloat(btcTargetShare) / 100)).toLocaleString()}</span>
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">Reb Price ($)</label>
                      <input 
                        type="number" 
                        placeholder={btcResult?.lower.toFixed(2)}
                        value={btcManualRebPrice} 
                        onChange={e => setBtcManualRebPrice(e.target.value)}
                        className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">LTV (%)</label>
                      <input type="number" value={btcRebLtv} onChange={e => setBtcRebLtv(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">LT (%)</label>
                    <input type="number" value={btcRebLt} onChange={e => setBtcRebLt(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">CF (%)</label>
                    <input type="number" value={btcRebCf} onChange={e => setBtcRebCf(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">Borrow %</label>
                    <input type="number" value={btcRebBr} onChange={e => setBtcRebBr(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                </div>

                {btcReb && (
                  <div className="space-y-4 pt-4 border-t border-[#141414]">
                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Working Capital (LP Position)</div>
                      <div className="text-2xl font-bold text-emerald-600">${btcReb.cap.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-2 flex justify-between border-t border-[#141414]/5 pt-2">
                        <span>Borrowed (Debt):</span>
                        <span className="font-bold text-[#141414]">${btcReb.borrowUsd0.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                      </div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Range is calculated based on total LP value: Borrowed USDC + Paired Asset from collateral.
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-xl font-bold text-rose-600">${btcReb.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          {((btcReb.lower / btcReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-xl font-bold text-emerald-600">${btcReb.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          +{((btcReb.upper / btcReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                      <div className="text-lg font-bold text-blue-600">${btcReb.rangeNew.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        {((btcReb.rangeNew / btcReb.priceReb) * 100).toFixed(2)}% of price
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Health Factor</div>
                        <div className={`text-xl font-bold ${btcReb.hfNow > 1.1 ? 'text-emerald-400' : 'text-rose-400'}`}>{btcReb.hfNow.toFixed(3)}</div>
                      </div>
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Liq Price</div>
                        <div className="text-xl font-bold text-rose-400">${btcReb.liqP.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>
                    <div className="p-4 border border-rose-500/30 bg-rose-500/5">
                      <div className="font-mono text-[10px] uppercase text-rose-500 font-bold mb-1">Final Liquidation (After Top-up)</div>
                      <div className="text-2xl font-bold text-rose-500">${btcReb.liqP2.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-1">HF @ Lower: {btcReb.hfAtLower2.toFixed(3)}</div>
                    </div>

                    <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Total Asset Exposure at Liq</div>
                      <div className="text-2xl font-bold text-emerald-400">${btcReb.totalAssetValueAtLiq.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Total {btcReb.collateralUnits2.toFixed(6)} BTC held at ${btcReb.liqP2.toFixed(2)}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* AVAX Rebalance */}
              <div className="border border-[#141414] p-8 bg-white/30 space-y-6">
                <h3 className="font-serif italic text-xl border-b border-[#141414] pb-2 flex justify-between items-end">
                  <span>AVAX Rebalance</span>
                  <span className="font-mono text-[10px] opacity-50">Target: ${((parseFloat(rebTargetIncome || targetIncome) || 0) * (100 - (parseFloat(ethTargetShare) || 0) - (parseFloat(btcTargetShare) || 0))).toLocaleString()}</span>
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">Reb Price ($)</label>
                      <input 
                        type="number" 
                        placeholder={avaxResult?.lower.toFixed(2)}
                        value={avaxManualRebPrice} 
                        onChange={e => setAvaxManualRebPrice(e.target.value)}
                        className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase opacity-50">LTV (%)</label>
                      <input type="number" value={avaxRebLtv} onChange={e => setAvaxRebLtv(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">LT (%)</label>
                    <input type="number" value={avaxRebLt} onChange={e => setAvaxRebLt(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">CF (%)</label>
                    <input type="number" value={avaxRebCf} onChange={e => setAvaxRebCf(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase opacity-50">Borrow %</label>
                    <input type="number" value={avaxRebBr} onChange={e => setAvaxRebBr(e.target.value)} className="w-full bg-transparent border border-[#141414] p-2 font-mono text-sm focus:bg-[#141414] focus:text-[#E4E3E0]" />
                  </div>
                </div>

                {avaxReb && (
                  <div className="space-y-4 pt-4 border-t border-[#141414]">
                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Working Capital (LP Position)</div>
                      <div className="text-2xl font-bold text-emerald-600">${avaxReb.cap.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-2 flex justify-between border-t border-[#141414]/5 pt-2">
                        <span>Borrowed (Debt):</span>
                        <span className="font-bold text-[#141414]">${avaxReb.borrowUsd0.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                      </div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Range is calculated based on total LP value: Borrowed USDC + Paired Asset from collateral.
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">LOWER BOUND</div>
                        <div className="text-xl font-bold text-rose-600">${avaxReb.lower.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          {((avaxReb.lower / avaxReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                      <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                        <div className="font-mono text-[10px] uppercase opacity-50 mb-1">UPPER BOUND</div>
                        <div className="text-xl font-bold text-emerald-600">${avaxReb.upper.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                        <div className="font-mono text-[8px] opacity-30 mt-1">
                          +{((avaxReb.upper / avaxReb.priceReb) * 100 - 100).toFixed(2)}%
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-white/50 border border-[#141414]/10 rounded">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">TOTAL RANGE</div>
                      <div className="text-lg font-bold text-blue-600">${avaxReb.rangeNew.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        {((avaxReb.rangeNew / avaxReb.priceReb) * 100).toFixed(2)}% of price
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Health Factor</div>
                        <div className={`text-xl font-bold ${avaxReb.hfNow > 1.1 ? 'text-emerald-400' : 'text-rose-400'}`}>{avaxReb.hfNow.toFixed(3)}</div>
                      </div>
                      <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                        <div className="font-mono text-[8px] opacity-50 uppercase">Liq Price</div>
                        <div className="text-xl font-bold text-rose-400">${avaxReb.liqP.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      </div>
                    </div>
                    <div className="p-4 border border-rose-500/30 bg-rose-500/5">
                      <div className="font-mono text-[10px] uppercase text-rose-500 font-bold mb-1">Final Liquidation (After Top-up)</div>
                      <div className="text-2xl font-bold text-rose-500">${avaxReb.liqP2.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-50 mt-1">HF @ Lower: {avaxReb.hfAtLower2.toFixed(3)}</div>
                    </div>

                    <div className="p-4 bg-[#141414] text-[#E4E3E0]">
                      <div className="font-mono text-[10px] uppercase opacity-50 mb-1">Total Asset Exposure at Liq</div>
                      <div className="text-2xl font-bold text-emerald-400">${avaxReb.totalAssetValueAtLiq.toLocaleString(undefined, { maximumFractionDigits: 2 })}</div>
                      <div className="font-mono text-[8px] opacity-30 mt-1">
                        Total {avaxReb.collateralUnits2.toFixed(2)} AVAX held at ${avaxReb.liqP2.toFixed(2)}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-center pt-8">
              <button 
                onClick={handleReset}
                className="flex items-center gap-2 border border-rose-500 text-rose-500 px-8 py-4 font-mono text-xs uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all"
              >
                <RotateCcw className="w-4 h-4" /> Reset Settings
              </button>
            </div>
          </div>
        )}
      </section>
    )}
    </div>
  );
}
