import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, CreditCard, Wallet, ArrowRight, Loader2, ShieldCheck } from 'lucide-react';
import { useAuth } from './AuthContext';

const PLANS = [
  {
    id: 'monthly',
    name: 'Monthly',
    price: 11,
    period: 'month',
    features: [
      'Full Pool Analytics',
      'Unlimited Snapshots',
      'Strategy Simulator',
      'Risk Monitoring',
      'Email Notifications'
    ]
  },
  {
    id: 'yearly',
    name: 'Yearly',
    price: 97,
    period: 'year',
    features: [
      'All Monthly Features',
      '25% Discount',
      'Priority Support',
      'Early Access to New Tools',
      'Custom Reports'
    ],
    popular: true
  }
];

const CURRENCIES = [
  { id: 'USDC', name: 'USDC', icon: 'https://cryptologos.cc/logos/usd-coin-usdc-logo.png' },
  { id: 'USDT', name: 'USDT', icon: 'https://cryptologos.cc/logos/tether-usdt-logo.png' }
];

const NETWORKS = [
  { id: 'ETH', name: 'Ethereum (ERC20)' },
  { id: 'POLYGON', name: 'Polygon' },
  { id: 'BSC', name: 'BNB Smart Chain (BEP20)' },
  { id: 'BASE', name: 'Base' }
];

export default function SubscriptionPage() {
  const { user, refreshUser, logout } = useAuth();
  const [step, setStep] = useState<'plan' | 'payment' | 'processing'>('plan');
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedCurrency, setSelectedCurrency] = useState<string>('USDC');
  const [selectedNetwork, setSelectedNetwork] = useState<string>('BASE');
  const [invoice, setInvoice] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const handleCreateInvoice = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/payments/create-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan: selectedPlan,
          currency: selectedCurrency,
          network: selectedNetwork
        })
      });
      if (res.ok) {
        const data = await res.json();
        setInvoice(data);
        setStep('payment');
      }
    } catch (err) {
      console.error('Failed to create invoice:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPayment = async () => {
    setVerifying(true);
    // Simulate verification delay
    setTimeout(async () => {
      try {
        const res = await fetch('/api/payments/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ paymentId: invoice.paymentId })
        });
        if (res.ok) {
          await refreshUser();
        }
      } catch (err) {
        console.error('Verification failed:', err);
      } finally {
        setVerifying(false);
      }
    }, 2000);
  };

  if (step === 'plan') {
    return (
      <div className="max-w-5xl mx-auto py-12 px-4 space-y-12">
        <header className="text-center space-y-4">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 border border-emerald-500/20 bg-emerald-500/5 text-emerald-600 rounded-full font-mono text-[10px] uppercase tracking-widest"
          >
            <ShieldCheck className="w-3 h-3" />
            Account Authorized: {user?.email}
          </motion.div>
          <h1 className="font-serif italic text-6xl">Choose your plan</h1>
          <p className="font-mono text-sm opacity-50 uppercase tracking-widest">Select a subscription to unlock full platform access</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {PLANS.map((plan) => (
            <motion.div
              key={plan.id}
              whileHover={{ y: -5 }}
              className={`relative border p-8 space-y-8 transition-all cursor-pointer ${
                selectedPlan === plan.id ? 'border-[#141414] bg-[#141414]/5' : 'border-[#141414]/10 hover:border-[#141414]/30'
              }`}
              onClick={() => setSelectedPlan(plan.id)}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#141414] text-[#E4E3E0] px-3 py-1 font-mono text-[10px] uppercase tracking-widest">
                  Most Popular
                </div>
              )}
              <div className="space-y-2">
                <h3 className="font-serif italic text-3xl">{plan.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="font-mono text-xs opacity-50 uppercase">/ {plan.period}</span>
                </div>
              </div>
              <ul className="space-y-3">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 font-mono text-xs opacity-70">
                    <Check className="w-4 h-4 text-emerald-500" />
                    {feature}
                  </li>
                ))}
              </ul>
              <button
                className={`w-full py-4 font-mono text-[10px] uppercase tracking-widest transition-all ${
                  selectedPlan === plan.id 
                    ? 'bg-[#141414] text-[#E4E3E0]' 
                    : 'border border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0]'
                }`}
              >
                {selectedPlan === plan.id ? 'Selected' : 'Select Plan'}
              </button>
            </motion.div>
          ))}
        </div>

        {selectedPlan && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="border border-[#141414] p-8 space-y-8 bg-white shadow-xl"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <h4 className="font-serif italic text-2xl">Payment Details</h4>
                <div className="space-y-4">
                  <label className="block font-mono text-[10px] uppercase tracking-widest opacity-50">Select Currency</label>
                  <div className="flex gap-4">
                    {CURRENCIES.map(c => (
                      <button
                        key={c.id}
                        onClick={() => setSelectedCurrency(c.id)}
                        className={`flex-1 flex items-center justify-center gap-2 p-4 border transition-all ${
                          selectedCurrency === c.id ? 'border-[#141414] bg-[#141414]/5' : 'border-[#141414]/10'
                        }`}
                      >
                        <img src={c.icon} className="w-5 h-5" alt="" />
                        <span className="font-mono text-xs font-bold">{c.id}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="block font-mono text-[10px] uppercase tracking-widest opacity-50">Select Network</label>
                  <div className="grid grid-cols-1 gap-2">
                    {NETWORKS.map(n => (
                      <button
                        key={n.id}
                        onClick={() => setSelectedNetwork(n.id)}
                        className={`text-left p-4 border transition-all font-mono text-xs ${
                          selectedNetwork === n.id ? 'border-[#141414] bg-[#141414]/5' : 'border-[#141414]/10'
                        }`}
                      >
                        {n.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="bg-[#141414]/5 p-8 flex flex-col justify-between">
                <div className="space-y-4">
                  <h4 className="font-serif italic text-2xl">Summary</h4>
                  <div className="flex justify-between font-mono text-sm border-b border-[#141414]/10 pb-4">
                    <span className="opacity-50 uppercase">Plan</span>
                    <span className="font-bold uppercase">{selectedPlan}</span>
                  </div>
                  <div className="flex justify-between font-mono text-sm border-b border-[#141414]/10 pb-4">
                    <span className="opacity-50 uppercase">Amount</span>
                    <span className="font-bold">${selectedPlan === 'monthly' ? 11 : 97}</span>
                  </div>
                  <div className="flex justify-between font-mono text-sm">
                    <span className="opacity-50 uppercase">Method</span>
                    <span className="font-bold">{selectedCurrency} ({selectedNetwork})</span>
                  </div>
                </div>
                <button
                  onClick={handleCreateInvoice}
                  disabled={loading}
                  className="w-full bg-[#141414] text-[#E4E3E0] py-6 font-mono text-xs uppercase tracking-[0.2em] hover:bg-[#141414]/90 transition-all flex items-center justify-center gap-3 mt-8"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Generate Invoice'}
                  {!loading && <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </motion.div>
        )}
        
        <div className="text-center">
          <button onClick={logout} className="font-mono text-[10px] uppercase tracking-widest opacity-30 hover:opacity-100 transition-opacity underline underline-offset-4">
            Sign out and return to landing
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-24 px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="border border-[#141414] bg-white p-12 space-y-8 text-center shadow-2xl"
      >
        <header className="space-y-2">
          <h2 className="font-serif italic text-4xl">Complete Payment</h2>
          <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Send the exact amount to the address below</p>
        </header>

        <div className="flex flex-col items-center space-y-6">
          <div className="p-4 border border-[#141414]/10 bg-white">
            <img src={invoice.qrCode} alt="QR Code" className="w-48 h-48" />
          </div>
          <div className="space-y-2 w-full">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Amount to send</label>
            <div className="p-4 bg-[#141414]/5 font-mono text-xl font-bold border border-[#141414]/10">
              {invoice.amount} {invoice.currency}
            </div>
          </div>
          <div className="space-y-2 w-full">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Deposit Address ({invoice.network})</label>
            <div className="p-4 bg-[#141414]/5 font-mono text-[10px] break-all border border-[#141414]/10 select-all cursor-pointer" title="Click to copy">
              {invoice.address}
            </div>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <button
            onClick={handleVerifyPayment}
            disabled={verifying}
            className="w-full bg-[#141414] text-[#E4E3E0] py-6 font-mono text-xs uppercase tracking-[0.2em] hover:bg-[#141414]/90 transition-all flex items-center justify-center gap-3"
          >
            {verifying ? <Loader2 className="w-4 h-4 animate-spin" /> : 'I have sent the payment'}
          </button>
          <button
            onClick={() => setStep('plan')}
            className="w-full py-4 font-mono text-[10px] uppercase tracking-widest opacity-50 hover:opacity-100 transition-opacity"
          >
            Cancel and change plan
          </button>
        </div>

        <footer className="pt-8 border-t border-[#141414]/10">
          <p className="font-mono text-[10px] opacity-40 leading-relaxed uppercase">
            Payments are processed securely. Once confirmed on the blockchain, your access will be granted automatically.
            This usually takes 1-5 minutes depending on the network.
          </p>
        </footer>
      </motion.div>
    </div>
  );
}
