import React from 'react';
import { useAuth } from './AuthContext';
import { Database, LogIn } from 'lucide-react';
import { motion } from 'motion/react';

export default function LandingPage() {
  const { login, error } = useAuth();

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-xl w-full space-y-12"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Database className="w-10 h-10" />
            <span className="font-mono font-bold text-3xl tracking-tighter uppercase">LP ANALYTICS</span>
          </div>
          <h1 className="font-serif italic text-6xl tracking-tight leading-none">
            Precision Liquidity Management.
          </h1>
          <p className="font-mono text-sm opacity-60 leading-relaxed uppercase tracking-widest">
            A high-performance monitoring and strategy suite for concentrated liquidity positions. 
            Track fees, simulate rebalances, and optimize capital efficiency across multiple networks.
          </p>
        </div>

        <div className="space-y-4">
          <div className="flex justify-center">
            <button 
              onClick={login}
              className="w-full max-w-sm flex items-center justify-center gap-3 bg-[#141414] text-[#E4E3E0] py-6 font-mono text-sm uppercase tracking-widest hover:opacity-90 transition-opacity"
            >
              <LogIn className="w-5 h-5" />
              Authorize with Google
            </button>
          </div>

          {error && (
            <div className="p-4 bg-rose-500/10 border border-rose-500 text-rose-600 font-mono text-[10px] uppercase tracking-widest leading-relaxed">
              {error}
            </div>
          )}
        </div>

        <div className="pt-12 border-t border-[#141414]/10">
          <div className="font-mono text-[10px] opacity-40 uppercase tracking-[0.3em]">
            Institutional Grade Analytics • Multi-Chain Support • Real-time Sync
          </div>
        </div>
      </motion.div>
    </div>
  );
}
