import React from 'react';
import { Pool } from '../types';
import { Save, X } from 'lucide-react';

interface PoolFormProps {
  onSave: (pool: Partial<Pool>) => void;
  onCancel: () => void;
}

export default function PoolForm({ onSave, onCancel }: PoolFormProps) {
  const [formData, setFormData] = React.useState({
    name: '',
    network: 'Base',
    pair: '',
    fee_percent: '0.05',
    min_range: '0',
    max_range: '0',
    start_liquidity_usd: '0',
    start_price: '0',
    start_date: new Date().toISOString().slice(0, 16)
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericData: Partial<Pool> = {
      name: formData.name,
      network: formData.network,
      pair: formData.pair,
      fee_percent: parseFloat(formData.fee_percent),
      min_range: parseFloat(formData.min_range),
      max_range: parseFloat(formData.max_range),
      start_liquidity_usd: parseFloat(formData.start_liquidity_usd),
      start_price: parseFloat(formData.start_price),
      start_date: new Date(formData.start_date).toISOString()
    };
    onSave(numericData);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="font-serif italic text-4xl mb-2">Register New Pool</h1>
        <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Define parameters for a new liquidity position</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 border border-[#141414] p-6 sm:p-8 bg-white/30">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Pool Name</label>
            <input 
              required
              type="text" 
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              placeholder="e.g. Aerodrome ETH/USDC"
            />
          </div>
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Network</label>
            <select 
              value={formData.network}
              onChange={e => setFormData({...formData, network: e.target.value})}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            >
              <option value="Base">Base</option>
              <option value="Arbitrum">Arbitrum</option>
              <option value="Monad">Monad</option>
              <option value="BNB">BNB</option>
              <option value="Avalanche">Avalanche</option>
              <option value="Ethereum">Ethereum</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Pair</label>
            <input 
              required
              type="text" 
              value={formData.pair}
              onChange={e => setFormData({...formData, pair: e.target.value})}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              placeholder="ETH/USDC"
            />
          </div>
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Fee Percent (%)</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={formData.fee_percent}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setFormData({...formData, fee_percent: val as any});
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Min Range</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={formData.min_range}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setFormData({...formData, min_range: val as any});
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Max Range</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={formData.max_range}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setFormData({...formData, max_range: val as any});
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Start Liquidity ($)</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={formData.start_liquidity_usd}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setFormData({...formData, start_liquidity_usd: val as any});
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Start Price ($)</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={formData.start_price}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setFormData({...formData, start_price: val as any});
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              placeholder="Price at creation"
            />
          </div>
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Start Date & Time</label>
            <input 
              required
              type="datetime-local" 
              value={formData.start_date}
              onChange={e => setFormData({...formData, start_date: e.target.value})}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <button 
            type="submit"
            className="flex-1 bg-[#141414] text-[#E4E3E0] py-4 font-mono text-sm uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" /> Save Position
          </button>
          <button 
            type="button"
            onClick={onCancel}
            className="px-8 border border-[#141414] py-4 font-mono text-sm uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2"
          >
            <X className="w-4 h-4" /> Cancel
          </button>
        </div>
      </form>
    </div>
  );
}
