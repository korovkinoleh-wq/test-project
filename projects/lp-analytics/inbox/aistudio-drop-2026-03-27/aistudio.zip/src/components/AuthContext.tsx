import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { auth, db } from '../firebase';
import { 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  acceptDisclaimer: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);

  const syncUserWithFirestore = async (firebaseUser: FirebaseUser) => {
    try {
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);

      if (!userDoc.exists()) {
        const newUser: User = {
          id: firebaseUser.uid,
          email: firebaseUser.email || '',
          name: firebaseUser.displayName || '',
          picture: firebaseUser.photoURL || '',
          role: firebaseUser.email === 'olegglasstrader@gmail.com' ? 'admin' : 'approved',
          subscription_type: 'free_test',
          has_accepted_disclaimer: false,
        };
        await setDoc(userDocRef, {
          ...newUser,
          created_at: serverTimestamp(),
        });
        setUser(newUser);
      } else {
        const userData = userDoc.data() as User;
        // Update basic info if changed
        if (userData.name !== firebaseUser.displayName || userData.picture !== firebaseUser.photoURL) {
          await updateDoc(userDocRef, {
            name: firebaseUser.displayName,
            picture: firebaseUser.photoURL,
          });
        }
        setUser({ ...userData, id: firebaseUser.uid });
      }
    } catch (err: any) {
      console.error('Sync error:', err);
      setError(`Failed to sync user data: ${err.message}`);
      throw err;
    }
  };

  const syncWithBackend = async (firebaseUser: FirebaseUser) => {
    try {
      const idToken = await firebaseUser.getIdToken();
      const res = await fetch('/api/auth/firebase-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken })
      });
      if (!res.ok) {
        console.error('Failed to sync with backend');
      }
    } catch (err) {
      console.error('Backend sync error:', err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          await syncUserWithFirestore(firebaseUser);
          await syncWithBackend(firebaseUser);
        } catch (err) {
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const refreshUser = async () => {
    if (auth.currentUser) {
      await syncUserWithFirestore(auth.currentUser);
    }
  };

  const login = async () => {
    setError(null);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.error('Login failed:', err);
      if (err.code === 'auth/unauthorized-domain') {
        setError(`Error: Domain ${window.location.hostname} is not authorized in Firebase Console. Please add it to Authentication -> Settings -> Authorized domains.`);
      } else {
        setError(`Login failed: ${err.message}. Please ensure popups are allowed and Google Auth is enabled in Firebase Console.`);
      }
    }
  };

  const logout = async () => {
    setError(null);
    try {
      await signOut(auth);
      setUser(null);
    } catch (err: any) {
      console.error('Logout failed:', err);
      setError(`Logout failed: ${err.message}`);
    }
  };

  const acceptDisclaimer = async () => {
    setError(null);
    if (!auth.currentUser) return;
    try {
      const userDocRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userDocRef, {
        has_accepted_disclaimer: true
      });
      setUser(prev => prev ? { ...prev, has_accepted_disclaimer: true } : null);
    } catch (err: any) {
      console.error('Failed to accept disclaimer:', err);
      setError(`Failed to save disclaimer acceptance: ${err.message}`);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, refreshUser, acceptDisclaimer, error }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
