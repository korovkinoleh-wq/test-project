import React from 'react';
import { Pool } from '../types';
import { Calculator as CalcIcon, Info, Lock } from 'lucide-react';
import { useAuth } from './AuthContext';

interface YieldCalculatorProps {
  pools: Pool[];
}

export default function YieldCalculator({ pools }: YieldCalculatorProps) {
  const { user, login } = useAuth();
  const isGuest = user?.role === 'guest';
  
  const [selectedPoolId, setSelectedPoolId] = React.useState<number | string>('');
  const [userLiquidity, setUserLiquidity] = React.useState<string>('1000');
  const [userRange, setUserRange] = React.useState<string>('100');
  const [prices, setPrices] = React.useState<Record<string, number>>({});

  React.useEffect(() => {
    const fetchPrices = async () => {
      try {
        const symbols = ['ETHUSDC', 'BTCUSDC', 'AVAXUSDC'];
        const results = await Promise.all(
          symbols.map(s => fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${s}`).then(r => r.json()))
        );
        const newPrices: Record<string, number> = {};
        results.forEach(r => {
          if (r.symbol && r.price) {
            const asset = r.symbol.replace('USDC', '');
            newPrices[asset] = parseFloat(r.price);
          }
        });
        setPrices(newPrices);
      } catch (err) {
        console.error('Failed to fetch prices for calculator:', err);
      }
    };
    fetchPrices();
    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, []);

  // Calculate averages for guests
  const getAveragePool = (type: 'ETH' | 'BTC' | 'AVAX') => {
    const filtered = pools.filter(p => {
      const pair = p.pair.toUpperCase();
      if (type === 'BTC') return pair.includes('BTC') || pair.includes('cbBTC');
      if (type === 'AVAX') return pair.includes('AVAX') || p.network === 'Avalanche';
      return pair.includes('ETH') || pair.includes('WETH');
    });

    if (filtered.length === 0) return null;

    const avgApr = filtered.reduce((acc, p) => acc + (p.aprSinceStart || 0), 0) / filtered.length;
    const avgRange = filtered.reduce((acc, p) => acc + (p.max_range - p.min_range), 0) / filtered.length;
    const avgFeesPerDay = filtered.reduce((acc, p) => acc + (p.feesPerDayAvg || 0), 0) / filtered.length;
    const avgStartLiq = filtered.reduce((acc, p) => acc + p.start_liquidity_usd, 0) / filtered.length;

    return {
      id: `avg-${type}`,
      name: `Average ${type} Pool`,
      aprSinceStart: avgApr,
      apr7D: avgApr,
      max_range: avgRange,
      min_range: 0,
      feesPerDayAvg: avgFeesPerDay,
      feesPerDay7D: avgFeesPerDay,
      start_liquidity_usd: avgStartLiq,
      network: 'Multiple',
      pair: type === 'ETH' ? 'ETH/USDC' : type === 'BTC' ? 'BTC/USDC' : 'AVAX/USDC',
      fee_percent: 0.05,
      start_date: new Date().toISOString()
    } as any;
  };

  const ethAvg = getAveragePool('ETH');
  const btcAvg = getAveragePool('BTC');
  const avaxAvg = getAveragePool('AVAX');

  const selectedPool = isGuest 
    ? (selectedPoolId === 'avg-ETH' ? ethAvg : selectedPoolId === 'avg-BTC' ? btcAvg : selectedPoolId === 'avg-AVAX' ? avaxAvg : null)
    : pools.find(p => String(p.id) === String(selectedPoolId));

  const poolRange = selectedPool ? (selectedPool.max_range - selectedPool.min_range) : 0;
  
  const liquidityNum = parseFloat(userLiquidity) || 0;
  const rangeNum = parseFloat(userRange) || 0;

  const asset = selectedPool ? selectedPool.pair.split('/')[0].toUpperCase() : '';
  const currentPrice = prices[asset] || prices[asset.replace('W', '')] || 0;

  // Price scaling factor: ranges should scale with price to maintain relative width
  // Use Geometric Mean for more accurate reference price in Uniswap V3
  const refPrice = selectedPool ? Math.sqrt(selectedPool.min_range * selectedPool.max_range) : 0;
  const priceScale = selectedPool && refPrice > 0 && currentPrice > 0
    ? currentPrice / refPrice
    : 1;

  const feesPerDay = selectedPool ? (selectedPool.feesPerDay7D || selectedPool.feesPerDayAvg || 0) : 0;
  
  const predictedFees7D = selectedPool && rangeNum > 0 
    ? feesPerDay * 7 * (liquidityNum / selectedPool.start_liquidity_usd) * ((poolRange * priceScale) / rangeNum)
    : 0;

  const predictedAPR = selectedPool && liquidityNum > 0
    ? (predictedFees7D / liquidityNum) * (365.25 / 7) * 100
    : 0;

  const MONTH_DAYS = 365.25 / 12;
  const predictedMonthly = (predictedFees7D / 7) * MONTH_DAYS;

  const referenceAPR = selectedPool ? (selectedPool.apr7D || selectedPool.aprSinceStart || 0) : 0;

  const selectBestPool = (type: 'BTC' | 'ETH' | 'AVAX') => {
    if (isGuest) {
      setSelectedPoolId(`avg-${type}`);
      const avg = type === 'ETH' ? ethAvg : type === 'BTC' ? btcAvg : avaxAvg;
      if (avg) setUserRange((avg.max_range - avg.min_range).toFixed(2));
      return;
    }

    const filtered = pools.filter(p => {
      const pair = p.pair.toUpperCase();
      if (type === 'BTC') return pair.includes('BTC') || pair.includes('cbBTC');
      if (type === 'AVAX') return pair.includes('AVAX') || p.network === 'Avalanche';
      return pair.includes('ETH') || pair.includes('WETH');
    });

    if (filtered.length > 0) {
      const best = filtered.reduce((prev, current) => 
        (prev.aprSinceStart || 0) > (current.aprSinceStart || 0) ? prev : current
      );
      setSelectedPoolId(best.id);
      setUserRange((best.max_range - best.min_range).toString());
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="font-serif italic text-4xl mb-2">Yield Projection</h1>
        <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Simulate returns based on historical pool performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6 border border-[#141414] p-8 bg-white/30">
          <div className="space-y-4">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50 block">
              {isGuest ? 'Select Asset Class' : 'Quick Select Best Yield'}
            </label>
            <div className="grid grid-cols-3 gap-4">
              <button 
                onClick={() => selectBestPool('ETH')}
                className="border border-[#141414] py-3 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors"
              >
                ETH {isGuest ? 'Avg' : 'Pool'}
              </button>
              <button 
                onClick={() => selectBestPool('BTC')}
                className="border border-[#141414] py-3 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors"
              >
                BTC {isGuest ? 'Avg' : 'Pool'}
              </button>
              <button 
                onClick={() => selectBestPool('AVAX')}
                className="border border-[#141414] py-3 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors"
              >
                AVAX {isGuest ? 'Avg' : 'Pool'}
              </button>
            </div>
          </div>

          {!isGuest ? (
            <div className="space-y-2">
              <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Manual Reference Pool</label>
              <select 
                value={selectedPoolId}
                onChange={e => {
                  const id = e.target.value;
                  setSelectedPoolId(id);
                  const pool = pools.find(p => String(p.id) === id);
                  if (pool) setUserRange((pool.max_range - pool.min_range).toString());
                }}
                className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              >
                <option value="">Choose a pool...</option>
                {pools.map(p => (
                  <option key={p.id} value={p.id}>{p.name} ({p.network})</option>
                ))}
              </select>
              {selectedPool && (
                <div className="flex justify-between font-mono text-[9px] uppercase opacity-40 px-1">
                  <span>Ref APR: {referenceAPR.toFixed(2)}%</span>
                  <span>Ref Range: {poolRange.toFixed(2)}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="p-4 border border-dashed border-[#141414]/30 bg-[#141414]/5 flex flex-col items-center justify-center gap-2 text-center">
              <Lock className="w-4 h-4 opacity-30" />
              <p className="font-mono text-[9px] uppercase tracking-widest opacity-50">
                Log in to select specific pools
              </p>
              <button 
                onClick={login}
                className="text-[9px] font-mono uppercase underline hover:opacity-100 opacity-70"
              >
                Authorize with Google
              </button>
            </div>
          )}

          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Your Liquidity (USD)</label>
            <input 
              type="text" 
              inputMode="decimal"
              value={userLiquidity}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setUserLiquidity(val);
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Your Range Width (Price Units)</label>
            <div className="flex gap-2">
              <input 
                type="text" 
                inputMode="decimal"
                value={userRange}
                onChange={e => {
                  const val = e.target.value.replace(',', '.');
                  if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                    setUserRange(val);
                  }
                }}
                className="flex-1 bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              />
              <div className="border border-[#141414] p-3 font-mono text-[10px] flex items-center opacity-50">
                POOL: {poolRange.toFixed(2)}
              </div>
            </div>
            <p className="text-[10px] font-mono opacity-50 italic flex items-center gap-1 mt-1">
              <Info className="w-3 h-3" /> Narrower range increases yield but also risk of going out-of-range.
            </p>
          </div>
        </div>

        <div className="border border-[#141414] p-6 sm:p-8 bg-[#141414] text-[#E4E3E0] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-6 sm:mb-8 opacity-50">
              <CalcIcon className="w-4 h-4" />
              <span className="font-mono text-[10px] uppercase tracking-widest">Projection Results</span>
            </div>

            <div className="space-y-6 sm:space-y-8">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest opacity-50 mb-1">Daily Fees</div>
                <div className="text-5xl sm:text-6xl font-bold tracking-tighter">${(predictedFees7D / 7).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
              </div>

              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest opacity-50 mb-1">Projected APR</div>
                <div className="text-5xl sm:text-6xl font-bold tracking-tighter text-emerald-400">{predictedAPR.toFixed(2)}%</div>
                {selectedPool && rangeNum > 0 && (
                  <div className="font-mono text-[9px] opacity-30 mt-1 uppercase">
                    Yield Multiplier: {((poolRange * priceScale) / rangeNum).toFixed(2)}x (vs Ref Pool)
                  </div>
                )}
                <div className="font-mono text-[9px] opacity-30 mt-1 uppercase">
                  Current Price: ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                {selectedPool && rangeNum > 0 && (
                  <div className="font-mono text-[9px] opacity-30 mt-1 uppercase">
                    Relative Range: {((rangeNum / currentPrice) * 100).toFixed(2)}% of price
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-8 sm:mt-12 pt-6 sm:pt-8 border-t border-[#E4E3E0]/20">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest opacity-30">7-Day Est.</div>
                <div className="font-mono text-base sm:text-lg">${predictedFees7D.toFixed(2)}</div>
              </div>
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest opacity-30">Monthly Est.</div>
                <div className="font-mono text-base sm:text-lg">${predictedMonthly.toFixed(2)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
