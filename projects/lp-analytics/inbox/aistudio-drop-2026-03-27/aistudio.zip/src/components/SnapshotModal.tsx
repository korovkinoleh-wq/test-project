import React from 'react';
import { Save, X } from 'lucide-react';

interface SnapshotModalProps {
  poolId: number;
  onSave: (data: { pool_id: number; total_fees: number; snapshot_datetime: string }) => void;
  onClose: () => void;
}

export default function SnapshotModal({ poolId, onSave, onClose }: SnapshotModalProps) {
  const [totalFees, setTotalFees] = React.useState<string>('0');
  const [datetime, setDatetime] = React.useState<string>(new Date().toISOString().slice(0, 16));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      pool_id: poolId,
      total_fees: parseFloat(totalFees),
      snapshot_datetime: new Date(datetime).toISOString()
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#141414]/80 backdrop-blur-sm">
      <div className="bg-[#E4E3E0] border border-[#141414] w-full max-w-md p-8 shadow-2xl">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="font-serif italic text-2xl">New Snapshot</h2>
            <p className="font-mono text-[10px] uppercase tracking-widest opacity-50">Record current fee accumulation</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Total Accumulated Fees ($)</label>
            <input 
              required
              type="text" 
              inputMode="decimal"
              value={totalFees}
              onChange={e => {
                const val = e.target.value.replace(',', '.');
                if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                  setTotalFees(val as any);
                }
              }}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <label className="font-mono text-[10px] uppercase tracking-widest opacity-50">Snapshot Date & Time</label>
            <input 
              required
              type="datetime-local" 
              value={datetime}
              onChange={e => setDatetime(e.target.value)}
              className="w-full bg-transparent border border-[#141414] p-3 font-mono text-sm focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors"
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-[#141414] text-[#E4E3E0] py-4 font-mono text-sm uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" /> Commit Snapshot
          </button>
        </form>
      </div>
    </div>
  );
}
