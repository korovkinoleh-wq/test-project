import React from 'react';
import { Pool, Snapshot } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { format } from 'date-fns';
import { ArrowLeft, Plus, Trash2, Edit3, TrendingUp, DollarSign, Calendar, Percent, Database } from 'lucide-react';
import { useAuth } from './AuthContext';
import { cn } from '../lib/utils';

interface PoolDetailProps {
  pool: Pool;
  snapshots: Snapshot[];
  onBack: () => void;
  onAddSnapshot: (poolId: string | number) => void;
  onDelete: (poolId: string | number) => void;
  onDeleteSnapshot: (snapshotId: string | number) => void;
}

export default function PoolDetail({ pool, snapshots, onBack, onAddSnapshot, onDelete, onDeleteSnapshot }: PoolDetailProps) {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [currentPrice, setCurrentPrice] = React.useState<number | null>(null);

  React.useEffect(() => {
    const fetchPrice = async () => {
      try {
        const asset = pool.pair.split('/')[0].toUpperCase().replace('W', '');
        const res = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${asset}USDC`);
        const data = await res.json();
        if (data.price) setCurrentPrice(parseFloat(data.price));
      } catch (err) {
        console.error('Failed to fetch price for detail:', err);
      }
    };
    fetchPrice();
  }, [pool.pair]);

  const priceNeutralApr = (() => {
    if (!pool.aprSinceStart || !pool.start_price || !currentPrice || currentPrice <= 0) return null;
    const priceRatio = pool.start_price / currentPrice;
    const neutralFactor = (0.5 + 0.5 * priceRatio);
    return pool.aprSinceStart * neutralFactor;
  })();

  const sortedSnapshots = [...snapshots].sort((a, b) => 
    new Date(a.snapshot_datetime).getTime() - new Date(b.snapshot_datetime).getTime()
  );

  const chartData = sortedSnapshots.map(s => ({
    date: format(new Date(s.snapshot_datetime), 'MMM dd'),
    fees: s.total_fees,
    timestamp: new Date(s.snapshot_datetime).getTime()
  }));

  // Calculate APR dynamics if we have enough snapshots
  const aprData = sortedSnapshots.map((s, i) => {
    if (i === 0) return { date: format(new Date(s.snapshot_datetime), 'MMM dd'), apr: 0 };
    
    const prev = sortedSnapshots[i - 1];
    const days = (new Date(s.snapshot_datetime).getTime() - new Date(prev.snapshot_datetime).getTime()) / (1000 * 60 * 60 * 24);
    if (days <= 0) return { date: format(new Date(s.snapshot_datetime), 'MMM dd'), apr: 0 };
    
    const feeDiff = s.total_fees - prev.total_fees;
    const apr = (feeDiff / pool.start_liquidity_usd) * (365.25 / days) * 100;
    
    return {
      date: format(new Date(s.snapshot_datetime), 'MMM dd'),
      apr: apr
    };
  }).slice(1);

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-6">
        <div className="space-y-1">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest opacity-50 hover:opacity-100 transition-opacity mb-4"
          >
            <ArrowLeft className="w-3 h-3" /> Back to Dashboard
          </button>
          <h1 className="font-serif italic text-4xl sm:text-5xl tracking-tight">{pool.name}</h1>
          <div className="flex flex-wrap items-center gap-3 font-mono text-[10px] uppercase tracking-widest opacity-50">
            <span className="bg-[#141414] text-[#E4E3E0] px-2 py-0.5">{pool.network}</span>
            <span>{pool.pair}</span>
            <span className="hidden sm:inline">•</span>
            <span>Started {format(new Date(pool.start_date), 'MMM dd, yyyy')}</span>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
          {isAdmin && (
            <>
              <button 
                onClick={() => onAddSnapshot(pool.id)}
                className="flex items-center justify-center gap-2 border border-[#141414] px-4 py-3 sm:py-2 font-mono text-xs uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors w-full sm:w-auto"
              >
                <Plus className="w-4 h-4" /> New Snapshot
              </button>
              <button 
                type="button"
                onClick={() => {
                  console.log('[UI] Delete Pool clicked for ID:', pool.id);
                  onDelete(pool.id);
                }}
                className="flex items-center justify-center gap-2 bg-rose-500 text-white px-4 py-3 sm:py-2 font-mono text-xs uppercase tracking-widest hover:bg-rose-600 transition-colors shadow-lg w-full sm:w-auto"
              >
                <Trash2 className="w-4 h-4" /> Delete Pool
              </button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <DollarSign className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Total Fees</span>
          </div>
          <div className="text-3xl font-bold tracking-tight">${pool.totalFees?.toFixed(2)}</div>
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <TrendingUp className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">APR (Start)</span>
          </div>
          <div className="text-3xl font-bold tracking-tight text-emerald-600">{pool.aprSinceStart?.toFixed(2)}%</div>
          {priceNeutralApr !== null && (
            <div className="font-mono text-[8px] opacity-40 uppercase mt-1">Neutral: {priceNeutralApr.toFixed(2)}%</div>
          )}
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <Database className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Start Liq / Price</span>
          </div>
          <div className="text-xl font-bold tracking-tight">${pool.start_liquidity_usd?.toLocaleString()}</div>
          <div className="font-mono text-[10px] opacity-50">@ ${pool.start_price?.toLocaleString() || 'N/A'}</div>
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <TrendingUp className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Price Range</span>
          </div>
          <div className="text-sm font-mono font-bold">
            {pool.min_range?.toLocaleString()} — {pool.max_range?.toLocaleString()}
          </div>
          <div className="font-mono text-[8px] opacity-30 mt-1 uppercase">Min — Max</div>
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <Calendar className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Days Active</span>
          </div>
          <div className="text-3xl font-bold tracking-tight">{(pool.daysActive || 0).toFixed(2)}d</div>
          <div className="font-mono text-[8px] opacity-30 mt-1">Created: {new Date(pool.start_date).toLocaleString()}</div>
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <Percent className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Fee Growth (Delta)</span>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center">
              <span className="font-mono text-[8px] opacity-40 uppercase">1D</span>
              <span className={cn("text-lg font-bold", (pool.delta_1 || 0) > 0 ? "text-emerald-600" : "text-rose-600")}>
                {((pool.delta_1 || 0) > 0 ? "+" : "")}{(pool.delta_1 || 0).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-[8px] opacity-40 uppercase">3D</span>
              <span className={cn("text-lg font-bold", (pool.delta_3 || 0) > 0 ? "text-emerald-600" : "text-rose-600")}>
                {((pool.delta_3 || 0) > 0 ? "+" : "")}{(pool.delta_3 || 0).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-mono text-[8px] opacity-40 uppercase">7D</span>
              <span className={cn("text-lg font-bold", (pool.delta_7 || 0) > 0 ? "text-emerald-600" : "text-rose-600")}>
                {((pool.delta_7 || 0) > 0 ? "+" : "")}{(pool.delta_7 || 0).toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
        <div className="border border-[#141414] p-6 bg-white/50">
          <div className="flex items-center gap-2 opacity-50 mb-2">
            <Percent className="w-3 h-3" />
            <span className="font-mono text-[10px] uppercase tracking-widest">Fee Tier</span>
          </div>
          <div className="text-3xl font-bold tracking-tight">{pool.fee_percent}%</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="border border-[#141414] p-8 bg-white/30">
          <h3 className="font-serif italic text-xl mb-6">Fee Accumulation</h3>
          <div className="h-[300px] w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorFees" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#141414" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#141414" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#141414" strokeOpacity={0.1} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontFamily: 'monospace' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontFamily: 'monospace' }}
                  tickFormatter={(val) => `$${val}`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#141414', border: 'none', color: '#E4E3E0', fontFamily: 'monospace', fontSize: '10px' }}
                  itemStyle={{ color: '#E4E3E0' }}
                />
                <Area type="monotone" dataKey="fees" stroke="#141414" fillOpacity={1} fill="url(#colorFees)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="border border-[#141414] p-8 bg-white/30">
          <h3 className="font-serif italic text-xl mb-6">APR Dynamics (7D Moving)</h3>
          <div className="h-[300px] w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={aprData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#141414" strokeOpacity={0.1} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontFamily: 'monospace' }}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fontFamily: 'monospace' }}
                  tickFormatter={(val) => `${val}%`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#141414', border: 'none', color: '#E4E3E0', fontFamily: 'monospace', fontSize: '10px' }}
                  itemStyle={{ color: '#E4E3E0' }}
                />
                <Line type="stepAfter" dataKey="apr" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="border border-[#141414]">
        <div className="p-4 bg-[#141414] text-[#E4E3E0] font-mono text-xs uppercase tracking-widest">
          Snapshot History
        </div>
        <div className="divide-y divide-[#141414]">
          {sortedSnapshots.slice().reverse().map((s) => (
            <div key={s.id} className="flex flex-col sm:grid sm:grid-cols-[1fr_1fr_auto] p-4 font-mono text-sm hover:bg-[#141414]/5 transition-colors items-center gap-4">
              <div className="opacity-50 w-full sm:w-auto">
                <span className="sm:hidden mr-2 uppercase text-[10px] opacity-50">Date:</span>
                {format(new Date(s.snapshot_datetime), 'yyyy-MM-dd HH:mm:ss')}
                <span className="ml-2 text-[8px] opacity-30">#{s.id}</span>
              </div>
              <div className="text-left sm:text-right font-bold w-full sm:w-auto">
                <span className="sm:hidden mr-2 uppercase text-[10px] font-normal opacity-50">Total Fees:</span>
                ${s.total_fees.toFixed(4)}
              </div>
              {isAdmin && (
                <button 
                  type="button"
                  onClick={(e) => {
                    console.log('[UI] Delete clicked for snapshot ID:', s.id);
                    e.preventDefault();
                    e.stopPropagation();
                    onDeleteSnapshot(s.id);
                  }}
                  className="p-3 sm:p-2 text-rose-500 hover:bg-rose-500 hover:text-white transition-all cursor-pointer flex items-center justify-center rounded border border-rose-200 w-full sm:w-auto"
                  title={`Delete Snapshot #${s.id}`}
                >
                  <Trash2 className="w-4 h-4 mr-2 sm:mr-0" />
                  <span className="sm:hidden uppercase text-[10px]">Delete Snapshot</span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
