import React, { useState, useRef } from 'react';
import { Pool } from '../types';
import { Save, Search, Filter, TrendingUp, Database, Clock, DollarSign, RefreshCw, Download, History, X, Wallet, Trash2 } from 'lucide-react';
import { useAuth } from './AuthContext';
import { format } from 'date-fns';
import { syncPoolsWithWallet } from '../services/blockchainService';
import { cn } from '../lib/utils';

interface DashboardProps {
  pools: Pool[];
  onSelectPool: (pool: Pool) => void;
  onBulkSave: (snapshots: { pool_id: string | number, total_fees: number }[]) => Promise<boolean>;
  onRefresh: () => void;
}

interface PoolRowProps {
  pool: Pool;
  onSelectPool: (pool: Pool) => void;
  inputValue: string;
  onInputChange: (poolId: string | number, value: string) => void;
  isMaxDelta?: boolean;
  isMaxApr?: boolean;
  isAdmin: boolean;
  deltaPeriod: 1 | 3 | 7;
  currentPrice?: number;
}

const PoolRow: React.FC<PoolRowProps> = ({ pool, onSelectPool, inputValue, onInputChange, isMaxDelta, isMaxApr, isAdmin, deltaPeriod, currentPrice }) => {
  // Use flattened properties with fallback to deltas object
  const deltaVal = (() => {
    // If there's a new input value, calculate a "live" delta against the current total fees
    if (inputValue && typeof inputValue === 'string' && inputValue.trim() !== '') {
      const newVal = parseFloat(inputValue.replace(',', '.'));
      const oldVal = pool.totalFees || 0;
      
      if (!isNaN(newVal)) {
        if (oldVal === 0) return 0; // Fix: show 0% if baseline is 0
        const d = ((newVal - oldVal) / oldVal) * 100;
        return isFinite(d) ? d : 0;
      }
      return 0;
    }

    const d1 = pool.delta_1 !== undefined ? pool.delta_1 : (pool.deltas?.["1"] ?? pool.lastDeltaPct ?? 0);
    const d3 = pool.delta_3 !== undefined ? pool.delta_3 : (pool.deltas?.["3"] ?? 0);
    const d7 = pool.delta_7 !== undefined ? pool.delta_7 : (pool.deltas?.["7"] ?? 0);

    if (deltaPeriod === 1) return d1;
    if (deltaPeriod === 3) return d3;
    if (deltaPeriod === 7) return d7;
    return 0;
  })();

  const aprVal = (() => {
    if (inputValue && typeof inputValue === 'string' && inputValue.trim() !== '') {
      const newVal = parseFloat(inputValue.replace(',', '.'));
      if (!isNaN(newVal) && pool.start_liquidity_usd > 0) {
        return (newVal / pool.start_liquidity_usd) * (365 / pool.daysActive) * 100;
      }
    }
    return pool.aprSinceStart || 0;
  })();

  // Price Neutral APR calculation
  const priceNeutralApr = (() => {
    if (!aprVal || !pool.start_price || !currentPrice || currentPrice <= 0) return null;
    
    const priceRatio = pool.start_price / currentPrice;
    const neutralFactor = (0.5 + 0.5 * priceRatio);
    return aprVal * neutralFactor;
  })();

  React.useEffect(() => {
    // Diagnostic log removed
  }, [pool, deltaPeriod]);

  return (
    <div className={`flex flex-col lg:grid ${isAdmin ? 'lg:grid-cols-[2fr_1fr_1fr_1fr_1fr_1.5fr]' : 'lg:grid-cols-[2fr_1fr_1fr_1fr]'} hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors group border-b border-[#141414]`}>
      <div className="p-4 flex flex-col cursor-pointer" onClick={() => onSelectPool(pool)}>
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-[10px] uppercase tracking-widest opacity-50">
            {pool.name.toLowerCase().includes('trader joe') ? 'Trader Joe' : pool.name.split(' ')[0]}
          </span>
          {pool.snapshots_count !== undefined && (
            <span className="text-[8px] px-1 bg-[#141414] text-white/40 font-mono" title="Total snapshots recorded">
              {pool.snapshots_count} SNAPS
            </span>
          )}
          {pool.name.toLowerCase().includes('uniswap') && (
            <img 
              src="https://icon.horse/icon/uniswap.org" 
              className="w-4 h-4 rounded-full object-contain" 
              alt="Uniswap" 
              referrerPolicy="no-referrer"
              onError={(e) => (e.currentTarget.style.display = 'none')}
            />
          )}
          {pool.name.toLowerCase().includes('aerodrome') && (
            <img 
              src="https://icon.horse/icon/aerodrome.finance" 
              className="w-4 h-4 rounded-full object-contain" 
              alt="Aerodrome" 
              referrerPolicy="no-referrer"
              onError={(e) => (e.currentTarget.style.display = 'none')}
            />
          )}
          {(pool.name.toLowerCase().includes('trader joe') || pool.name.toLowerCase().includes('lfj')) && (
            <img 
              src="https://icon.horse/icon/traderjoe.xyz" 
              className="w-4 h-4 rounded-full object-contain" 
              alt="LFJ" 
              referrerPolicy="no-referrer"
              onError={(e) => (e.currentTarget.style.display = 'none')}
            />
          )}
          <span className="font-mono text-[10px] font-bold opacity-70">
            {pool.pair} {pool.fee_percent !== null && pool.fee_percent !== undefined ? `${pool.fee_percent}%` : ''}
          </span>
        </div>
        <span className="font-serif font-bold text-base leading-tight">{pool.network}</span>
        <div className="flex items-center gap-2 mt-1">
          <span className="font-mono text-[10px] opacity-40 uppercase tracking-tighter">Range:</span>
          <span className="font-mono text-[10px] font-bold opacity-60 italic">
            {pool.min_range}–{pool.max_range}
          </span>
        </div>
      </div>
      
      <div className="flex lg:contents">
        <div className="p-4 font-mono text-sm flex items-center flex-1 lg:flex-none">
          <span className="lg:hidden opacity-50 mr-2 uppercase text-[10px]">Days:</span>
          {(pool.daysActive || 0).toFixed(2)}d
        </div>
        {isAdmin && (
          <div className="p-4 font-mono text-sm flex items-center flex-1 lg:flex-none">
            <span className="lg:hidden opacity-50 mr-2 uppercase text-[10px]">Fees:</span>
            ${(inputValue && !isNaN(parseFloat(inputValue.replace(',', '.')))) 
              ? parseFloat(inputValue.replace(',', '.')).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
              : pool.totalFees?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        )}
      </div>

      <div className="flex lg:contents">
        <div className="p-4 font-mono text-sm flex items-center flex-1 lg:flex-none">
          <span className="lg:hidden opacity-50 mr-2 uppercase text-[10px]">APR:</span>
          <div className={cn(
            "flex flex-col",
            isMaxApr && "border-2 border-emerald-600 px-2 py-0.5 rounded-sm bg-emerald-500/5"
          )}>
            <span className={cn(
              "font-bold",
              (aprVal > 20) || isMaxApr ? 'text-emerald-600 group-hover:text-emerald-400' : ''
            )}>
              {aprVal.toFixed(2)}%
            </span>
            {priceNeutralApr !== null && (
              <span className="text-[8px] opacity-40 uppercase tracking-tighter" title="APR adjusted to starting price (removes market rally/crash impact)">
                Neutral: {priceNeutralApr.toFixed(2)}%
              </span>
            )}
          </div>
        </div>
        <div className="p-4 font-mono text-sm flex items-center flex-1 lg:flex-none">
          <span className="lg:hidden opacity-50 mr-2 uppercase text-[10px]">Delta:</span>
          <div className="flex flex-col">
            <span className={`font-bold ${isMaxDelta ? 'text-emerald-500' : 'opacity-50 group-hover:opacity-100'}`}>
              {deltaVal > 0 ? '+' : ''}{deltaVal.toFixed(2)}%
            </span>
            <span className="text-[8px] font-mono opacity-30 uppercase tracking-tighter">Period: {deltaPeriod}D</span>
          </div>
        </div>
      </div>

      {isAdmin && (
        <div className="p-4 flex items-center gap-2 relative">
          <input 
            type="text" 
            inputMode="decimal"
            placeholder="NEW TOTAL FEES..."
            value={inputValue}
            onChange={(e) => {
              const val = e.target.value.replace(',', '.');
              if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
                onInputChange(pool.id, val);
              }
            }}
            className={`bg-transparent border ${!inputValue ? 'border-amber-500/30' : 'border-[#141414]'} group-hover:border-[#E4E3E0]/30 px-3 py-2 lg:py-1 font-mono text-xs w-full focus:outline-none focus:bg-[#E4E3E0] focus:text-[#141414] transition-colors`}
          />
          {!inputValue && (
            <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none">
              <span className="font-mono text-[8px] text-amber-600 uppercase font-bold animate-pulse">Required</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

interface CategorySectionProps {
  title: string;
  pools: Pool[];
  onSelectPool: (pool: Pool) => void;
  bulkInputs: Record<number, string>;
  onInputChange: (poolId: number, value: string) => void;
  maxDeltaId?: number;
  maxAprId?: number;
  isAdmin: boolean;
  headerRight?: React.ReactNode;
  deltaPeriod: 1 | 3 | 7;
  onDeltaPeriodChange: (period: 1 | 3 | 7) => void;
  prices: Record<string, number>;
}

const CategorySection: React.FC<CategorySectionProps> = ({ title, pools, onSelectPool, bulkInputs, onInputChange, maxDeltaId, maxAprId, isAdmin, headerRight, deltaPeriod, onDeltaPeriodChange, prices }) => (
  <div className="mb-12">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 border-b border-[#141414] pb-2">
      <div className="flex items-center gap-3">
        <h2 className="font-serif italic text-2xl">{title}</h2>
        <span className="font-mono text-[10px] opacity-50 uppercase tracking-widest bg-[#141414] text-[#E4E3E0] px-2 py-0.5 w-fit">{pools.length} POOLS</span>
      </div>
      {headerRight}
    </div>
    
    <div className="border border-[#141414] border-b-0">
      <div className={`hidden lg:grid ${isAdmin ? 'lg:grid-cols-[2fr_1fr_1fr_1fr_1fr_1.5fr]' : 'lg:grid-cols-[2fr_1fr_1fr_1fr]'} bg-[#141414]/5 border-b border-[#141414]`}>
        {['POOL NAME', 'DAYS ACTIVE', ...(isAdmin ? ['TOTAL FEES'] : []), 'APR START', 'DELTA (%)', ...(isAdmin ? ['NEW SNAPSHOT ($)'] : [])].map((label) => (
          <div key={label} className="p-4 font-mono text-[10px] uppercase tracking-widest opacity-50">
            {label}
          </div>
        ))}
      </div>
      {pools.map(pool => {
        const asset = pool.pair.split('/')[0].toUpperCase();
        const price = prices[asset] || prices[asset.replace('W', '')] || 0;
        
        return (
          <PoolRow 
            key={pool.id} 
            pool={pool} 
            onSelectPool={onSelectPool}
            inputValue={bulkInputs[pool.id] || ''}
            onInputChange={onInputChange}
            isMaxDelta={pool.id === maxDeltaId}
            isMaxApr={pool.id === maxAprId}
            isAdmin={isAdmin}
            deltaPeriod={deltaPeriod}
            currentPrice={price}
          />
        );
      })}
    </div>
  </div>
);

export default function Dashboard({ pools, onSelectPool, onBulkSave, onRefresh }: DashboardProps) {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const [bulkInputs, setBulkInputs] = React.useState<Record<number, string>>({});
  const [deltaPeriod, setDeltaPeriod] = React.useState<1 | 3 | 7>(1);
  const [sortBy, setSortBy] = React.useState<'name' | 'apr' | 'delta'>('delta');
  const [prices, setPrices] = React.useState<Record<string, number>>({});

  React.useEffect(() => {
    const fetchPrices = async () => {
      try {
        const symbols = ['ETHUSDT', 'BTCUSDT', 'AVAXUSDT'];
        const results = await Promise.all(
          symbols.map(s => fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${s}`).then(r => r.json()))
        );
        const newPrices: Record<string, number> = {};
        results.forEach(r => {
          if (r.symbol && r.price) {
            const asset = r.symbol.replace('USDT', '');
            newPrices[asset] = parseFloat(r.price);
          }
        });
        setPrices(newPrices);
      } catch (err) {
        console.error('Failed to fetch prices for dashboard:', err);
      }
    };
    fetchPrices();
    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    // Diagnostic log removed
  }, [deltaPeriod]);
  const [isRestoring, setIsRestoring] = React.useState(false);
  const [isClearing, setIsClearing] = React.useState(false);
  const [isSyncing, setIsSyncing] = React.useState(false);
  const [isRecalculating, setIsRecalculating] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const [statusMessage, setStatusMessage] = React.useState<{message: string, type: 'success' | 'error'} | null>(null);
  const [showImportConfirm, setShowImportConfirm] = React.useState<{data: any} | null>(null);
  const [restoreOptions, setRestoreOptions] = React.useState({ pools: true, admin: true, suggestions: true });

  const handleExport = async () => {
    try {
      const res = await fetch('/api/export', { credentials: 'include' });
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lp_analytics_full_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export failed:', err);
      setStatusMessage({ message: 'Failed to export backup', type: 'error' });
    }
  };

  const handleClearDatabase = async () => {
    if (!window.confirm('WARNING: This will permanently delete ALL data from the database (pools, snapshots, users, payments). Are you absolutely sure?')) {
      return;
    }

    setIsClearing(true);
    setStatusMessage(null);
    try {
      const res = await fetch('/api/clear-database', {
        method: 'POST',
        credentials: 'include'
      });

      if (res.ok) {
        setStatusMessage({ message: 'Database cleared successfully!', type: 'success' });
        onRefresh();
      } else {
        const err = await res.json();
        setStatusMessage({ message: `Clear failed: ${err.error || 'Unknown error'}`, type: 'error' });
      }
    } catch (err) {
      console.error('Clear process error:', err);
      setStatusMessage({ message: `An unexpected error occurred: ${(err as Error).message}`, type: 'error' });
    } finally {
      setIsClearing(false);
    }
  };

  const handleSyncWallet = async () => {
    if (!user?.wallet_address) {
      alert('Please set your wallet address in the Admin Panel first.');
      return;
    }

    console.log('Testing API health...');
    try {
      const healthRes = await fetch('/api/health');
      const healthData = await healthRes.json();
      console.log('API Health Response:', JSON.stringify(healthData, null, 2));
    } catch (e) {
      console.warn('API Health check failed:', e);
    }

    setIsSyncing(true);
    try {
      const updates = await syncPoolsWithWallet();
      const count = Object.keys(updates).length;
      
      if (count === 0) {
        alert('No matching active positions found for your wallet in the supported networks.');
      } else {
        setBulkInputs(prev => ({ ...prev, ...updates }));
        alert(`Successfully synced ${count} positions! Review the values in the "NEW SNAPSHOT" column and click Commit to save.`);
      }
    } catch (err) {
      console.error('Sync failed:', err);
      const errorMessage = err instanceof Error ? err.message : String(err);
      alert(`Failed to sync with wallet: ${errorMessage}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRecalculateDeltas = async () => {
    setIsRecalculating(true);
    try {
      const res = await fetch('/api/admin/recalculate-deltas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      if (res.ok) {
        setStatusMessage({ message: 'Delta recalculation started. Data will update in Firestore shortly.', type: 'success' });
        // Give it a moment then refresh
        setTimeout(onRefresh, 2000);
      } else {
        setStatusMessage({ message: 'Failed to start recalculation.', type: 'error' });
      }
    } catch (err) {
      console.error('Recalculate error:', err);
      setStatusMessage({ message: 'An error occurred.', type: 'error' });
    } finally {
      setIsRecalculating(false);
    }
  };

  const executeRestore = async (backupData: any) => {
    setIsRestoring(true);
    setStatusMessage(null);
    try {
      // Filter backup data based on selected options
      const filteredData: any = {};
      if (restoreOptions.pools) {
        filteredData.pools = backupData.pools;
        filteredData.snapshots = backupData.snapshots;
      }
      if (restoreOptions.admin) {
        filteredData.users = backupData.users;
        filteredData.payments = backupData.payments;
      }
      if (restoreOptions.suggestions) {
        filteredData.suggestions = backupData.suggestions;
        filteredData.suggestion_replies = backupData.suggestion_replies;
      }

      const res = await fetch('/api/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(filteredData),
        credentials: 'include'
      });

      if (res.ok) {
        const result = await res.json();
        let msg = 'Database restored successfully!';
        const parts = [];
        if (result.poolsInserted) parts.push(`${result.poolsInserted} pools`);
        if (result.snapshotsInserted) parts.push(`${result.snapshotsInserted} snapshots`);
        if (result.usersInserted) parts.push(`${result.usersInserted} users`);
        if (result.paymentsInserted) parts.push(`${result.paymentsInserted} payments`);
        if (result.suggestionsInserted) parts.push(`${result.suggestionsInserted} suggestions`);
        
        if (parts.length > 0) msg += ` Inserted: ${parts.join(', ')}.`;
        
        setStatusMessage({ message: msg, type: 'success' });
        onRefresh();
      } else {
        let errorMessage = 'Unknown error';
        let errorDetail = '';
        try {
          const err = await res.json();
          errorMessage = err.error || errorMessage;
          errorDetail = err.details || '';
        } catch (e) {
          errorMessage = `Server returned status ${res.status}`;
        }
        console.error('Restore failed:', errorMessage, errorDetail);
        setStatusMessage({ 
          message: `Restore failed: ${errorMessage}${errorDetail ? ` (${errorDetail})` : ''}`, 
          type: 'error' 
        });
      }
    } catch (err) {
      console.error('Restore process error:', err);
      setStatusMessage({ message: `An unexpected error occurred: ${(err as Error).message}`, type: 'error' });
    } finally {
      setIsRestoring(false);
      setShowImportConfirm(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        let backupData;
        try {
          backupData = JSON.parse(content);
        } catch (parseErr) {
          console.error('JSON Parse Error:', parseErr);
          setStatusMessage({ message: 'Invalid file format: Not a valid JSON file.', type: 'error' });
          return;
        }

        setShowImportConfirm({ data: backupData });
      } catch (err) {
        console.error('Import file read error:', err);
        setStatusMessage({ message: 'Failed to read backup file', type: 'error' });
      }
    };
    reader.readAsText(file);
  };

  const getPoolDelta = (p: Pool, period: number) => {
    if (period === 1) return p.delta_1 ?? p.deltas?.["1"] ?? p.lastDeltaPct ?? 0;
    if (period === 3) return p.delta_3 ?? p.deltas?.["3"] ?? 0;
    if (period === 7) return p.delta_7 ?? p.deltas?.["7"] ?? 0;
    return 0;
  };

  const sortPools = (poolList: Pool[]) => {
    return [...poolList].sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'apr') return (b.aprSinceStart || 0) - (a.aprSinceStart || 0);
      if (sortBy === 'delta') {
        const deltaA = getPoolDelta(a, deltaPeriod);
        const deltaB = getPoolDelta(b, deltaPeriod);
        return deltaB - deltaA;
      }
      return 0;
    });
  };

  const ethPools = sortPools(pools.filter(p => 
    p.pair.toUpperCase().includes('ETH') || 
    p.pair.toUpperCase().includes('WETH')
  ));
  
  const btcPools = sortPools(pools.filter(p => 
    p.pair.toUpperCase().includes('BTC') || 
    p.pair.toUpperCase().includes('WBTC') ||
    p.pair.toUpperCase().includes('BTC.B')
  ));
  
  const avaxPools = sortPools(pools.filter(p => 
    p.pair.toUpperCase().includes('AVAX') || 
    p.pair.toUpperCase().includes('WAVAX')
  ));
  
  const categorizedIds = new Set([...ethPools, ...btcPools, ...avaxPools].map(p => p.id));
  const otherPools = sortPools(pools.filter(p => !categorizedIds.has(p.id)));

  const getMaxDeltaId = (poolList: Pool[]) => {
    if (poolList.length === 0) return undefined;
    const maxDeltaPool = poolList.reduce((prev, current) => {
      const prevVal = getPoolDelta(prev, deltaPeriod);
      const currVal = getPoolDelta(current, deltaPeriod);
      return prevVal > currVal ? prev : current;
    }, poolList[0]);
    
    const maxVal = getPoolDelta(maxDeltaPool, deltaPeriod);
    return maxVal > 0 ? maxDeltaPool.id : undefined;
  };

  const ethMaxDeltaId = getMaxDeltaId(ethPools);
  const btcMaxDeltaId = getMaxDeltaId(btcPools);
  const avaxMaxDeltaId = getMaxDeltaId(avaxPools);
  const otherMaxDeltaId = getMaxDeltaId(otherPools);

  const getMaxAprId = (poolList: Pool[]) => {
    if (poolList.length === 0) return undefined;
    const maxAprPool = poolList.reduce((prev, current) => {
      return (prev.aprSinceStart || 0) > (current.aprSinceStart || 0) ? prev : current;
    }, poolList[0]);
    return (maxAprPool.aprSinceStart || 0) > 0 ? maxAprPool.id : undefined;
  };

  const ethMaxAprId = getMaxAprId(ethPools);
  const btcMaxAprId = getMaxAprId(btcPools);
  const avaxMaxAprId = getMaxAprId(avaxPools);
  const otherMaxAprId = getMaxAprId(otherPools);

  const latestUpdate = pools.length > 0 
    ? pools.reduce((max, p) => (p.lastUpdate && (!max || p.lastUpdate > max) ? p.lastUpdate : max), undefined as string | undefined)
    : undefined;

  const handleInputChange = (poolId: string | number, value: string) => {
    setBulkInputs(prev => ({ ...prev, [poolId]: value }));
  };

  const [isCommitting, setIsCommitting] = useState(false);

  const handleCommit = async () => {
    const snapshots = Object.entries(bulkInputs)
      .filter(([_, val]) => val !== '')
      .map(([id, val]) => ({
        pool_id: id, // Keep as string (stable ID)
        total_fees: parseFloat(val as string)
      }));
    
    const totalPools = pools.length;
    const filledPools = snapshots.length;

    if (filledPools === 0) {
      setStatusMessage({ message: 'Please enter fee data for all pools before committing.', type: 'error' });
      return;
    }

    if (filledPools < totalPools) {
      setStatusMessage({ 
        message: `Incomplete Data: You have filled ${filledPools} out of ${totalPools} pools. All pools must be recorded en masse. Please fill in the remaining ${totalPools - filledPools} pools.`, 
        type: 'error' 
      });
      return;
    }

    setIsCommitting(true);
    try {
      const success = await onBulkSave(snapshots);
      if (success) {
        setBulkInputs({});
        setStatusMessage({ message: 'All snapshots recorded successfully!', type: 'success' });
      }
    } catch (err) {
      console.error('[DASHBOARD] Commit error:', err);
      setStatusMessage({ 
        message: `Failed to save snapshots: ${err instanceof Error ? err.message : 'Unknown error'}`, 
        type: 'error' 
      });
    } finally {
      setIsCommitting(false);
    }
  };

  const forceRefresh = () => {
    onRefresh();
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-end gap-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div>
            <h1 className="font-serif italic text-4xl sm:text-5xl mb-2">LP Analytics</h1>
            <p className="font-mono text-xs opacity-50 uppercase tracking-widest">Cloud-based tracking & yield dynamics</p>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 px-3 py-1 bg-[#141414] text-[#E4E3E0] font-mono text-[10px] uppercase tracking-widest">
              <Clock className="w-3 h-3" />
              <span className="text-[10px] font-mono opacity-50 uppercase tracking-widest">
                Delta Period: {deltaPeriod} {deltaPeriod === 1 ? 'Day' : 'Days'}
              </span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 border border-[#141414] font-mono text-[10px] uppercase tracking-widest">
              <span>Sort By:</span>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'name' | 'apr' | 'delta')}
                className="bg-transparent focus:outline-none cursor-pointer font-bold"
              >
                <option value="delta">Delta %</option>
                <option value="apr">APR %</option>
                <option value="name">Name</option>
              </select>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 border border-[#141414] font-mono text-[10px] uppercase tracking-widest">
              <span>Change Period:</span>
              <select 
                value={deltaPeriod}
                onChange={(e) => setDeltaPeriod(Number(e.target.value) as 1 | 3 | 7)}
                className="bg-transparent focus:outline-none cursor-pointer font-bold"
              >
                <option value={1}>1 Snap</option>
                <option value={3}>3 Snaps</option>
                <option value={7}>7 Snaps</option>
              </select>
            </div>
          </div>
        </div>
        
          <div className="flex flex-col sm:flex-row gap-4">
          <button 
            onClick={forceRefresh}
            className="flex-1 sm:flex-none border border-[#141414] px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-3 h-3" /> Refresh Data
          </button>
          
          {isAdmin && (
            <div className="flex gap-2">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImport} 
                accept=".json" 
                className="hidden" 
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={isRestoring}
                className="flex-1 sm:flex-none border border-[#141414] px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <History className="w-3 h-3" /> {isRestoring ? 'Restoring...' : 'Import'}
              </button>
              <button 
                onClick={handleExport}
                className="flex-1 sm:flex-none border border-[#141414] px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2"
              >
                <Download className="w-3 h-3" /> Export
              </button>
              <button 
                onClick={handleRecalculateDeltas}
                disabled={isRecalculating}
                className="flex-1 sm:flex-none border border-[#141414] px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <RefreshCw className={cn("w-3 h-3", isRecalculating && "animate-spin")} /> {isRecalculating ? 'Calculating...' : 'Recalc Deltas'}
              </button>
              <button 
                onClick={handleClearDatabase}
                disabled={isClearing || isRestoring}
                className="flex-1 sm:flex-none border border-red-500 text-red-500 px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-red-500 hover:text-white transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Trash2 className="w-3 h-3" /> {isClearing ? 'Clearing...' : 'Clear All'}
              </button>
              {user?.wallet_address && (
                <button 
                  onClick={handleSyncWallet}
                  disabled={isSyncing}
                  className="flex-1 sm:flex-none border border-emerald-600 text-emerald-600 px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-emerald-600 hover:text-white transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Wallet className={`w-3 h-3 ${isSyncing ? 'animate-pulse' : ''}`} /> {isSyncing ? 'Syncing...' : 'Sync Wallet'}
                </button>
              )}
            </div>
          )}
          <div className="flex-1" />
          {isAdmin && (
            <div className="flex gap-2">
              <button 
                onClick={() => setBulkInputs({})}
                disabled={!Object.values(bulkInputs).some(val => val !== '') || isCommitting}
                className="border border-[#141414] px-4 py-2 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors disabled:opacity-20"
              >
                Clear All
              </button>
              <button 
                onClick={handleCommit}
                disabled={!Object.values(bulkInputs).some(val => val !== '') || isCommitting}
                className="bg-[#141414] text-[#E4E3E0] px-6 py-3 font-mono text-xs uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center justify-center gap-2 disabled:opacity-20"
              >
                {isCommitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#E4E3E0]/30 border-t-[#E4E3E0] rounded-full animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" /> Commit
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Status Message */}
      {statusMessage && (
        <div className={cn(
          "p-4 border font-mono text-[10px] flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-300",
          statusMessage.type === 'success' ? "bg-emerald-50 border-emerald-200 text-emerald-700" : "bg-red-50 border-red-200 text-red-700"
        )}>
          <div className="flex items-center gap-3">
            <div className={cn("w-2 h-2 rounded-full", statusMessage.type === 'success' ? "bg-emerald-500" : "bg-red-500")} />
            <span>{statusMessage.message}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="opacity-50 hover:opacity-100 p-1">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Custom Confirmation Modal */}
      {showImportConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#E4E3E0]/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white border border-[#141414] shadow-2xl max-w-md w-full p-8 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-[#141414] text-[#E4E3E0]">
                <History className="w-5 h-5" />
              </div>
              <h3 className="font-serif italic text-xl">Confirm Restore</h3>
            </div>
            
            <p className="font-mono text-[10px] uppercase tracking-wider mb-4 opacity-70">
              Select data to restore from backup:
            </p>

            <div className="space-y-3 mb-8">
              {showImportConfirm.data.pools && (
                <label className="flex items-center gap-3 p-3 border border-[#141414]/10 hover:bg-[#141414]/5 cursor-pointer transition-colors">
                  <input 
                    type="checkbox" 
                    checked={restoreOptions.pools}
                    onChange={(e) => setRestoreOptions(prev => ({ ...prev, pools: e.target.checked }))}
                    className="w-4 h-4 accent-[#141414]"
                  />
                  <div>
                    <div className="font-mono text-[10px] uppercase font-bold">Liquidity Pools</div>
                    <div className="text-[9px] opacity-50 uppercase">{showImportConfirm.data.pools.length} pools, {showImportConfirm.data.snapshots?.length || 0} snapshots</div>
                  </div>
                </label>
              )}

              {(showImportConfirm.data.users || showImportConfirm.data.payments) && (
                <label className="flex items-center gap-3 p-3 border border-[#141414]/10 hover:bg-[#141414]/5 cursor-pointer transition-colors">
                  <input 
                    type="checkbox" 
                    checked={restoreOptions.admin}
                    onChange={(e) => setRestoreOptions(prev => ({ ...prev, admin: e.target.checked }))}
                    className="w-4 h-4 accent-[#141414]"
                  />
                  <div>
                    <div className="font-mono text-[10px] uppercase font-bold">Administration Data</div>
                    <div className="text-[9px] opacity-50 uppercase">{showImportConfirm.data.users?.length || 0} users, {showImportConfirm.data.payments?.length || 0} payments</div>
                  </div>
                </label>
              )}

              {(showImportConfirm.data.suggestions || showImportConfirm.data.suggestion_replies) && (
                <label className="flex items-center gap-3 p-3 border border-[#141414]/10 hover:bg-[#141414]/5 cursor-pointer transition-colors">
                  <input 
                    type="checkbox" 
                    checked={restoreOptions.suggestions}
                    onChange={(e) => setRestoreOptions(prev => ({ ...prev, suggestions: e.target.checked }))}
                    className="w-4 h-4 accent-[#141414]"
                  />
                  <div>
                    <div className="font-mono text-[10px] uppercase font-bold">Suggestions & Replies</div>
                    <div className="text-[9px] opacity-50 uppercase">{showImportConfirm.data.suggestions?.length || 0} messages</div>
                  </div>
                </label>
              )}
            </div>

            <p className="font-mono text-[9px] leading-relaxed mb-8 opacity-50 italic">
              * SELECTED CATEGORIES WILL BE <span className="font-bold underline">OVERWRITTEN</span>. THIS ACTION CANNOT BE UNDONE.
            </p>

            <div className="flex gap-3">
              <button 
                onClick={() => setShowImportConfirm(null)}
                className="flex-1 border border-[#141414] py-3 font-mono text-[10px] uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={() => executeRestore(showImportConfirm.data)}
                disabled={isRestoring || (!restoreOptions.pools && !restoreOptions.admin && !restoreOptions.suggestions)}
                className="flex-1 bg-[#141414] text-[#E4E3E0] py-3 font-mono text-[10px] uppercase tracking-widest hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isRestoring ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Restoring...
                  </>
                ) : (
                  'Confirm Restore'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {isAdmin && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
          <div className="border border-[#141414] p-6 bg-white/50">
            <div className="flex items-center gap-2 opacity-50 mb-2">
              <Database className="w-3 h-3" />
              <span className="font-mono text-[10px] uppercase tracking-widest">Active Pools</span>
            </div>
            <div className="text-3xl font-bold tracking-tight">{pools.length}</div>
          </div>
          <div className="border border-[#141414] p-6 bg-white/50">
            <div className="flex items-center gap-2 opacity-50 mb-2">
              <DollarSign className="w-3 h-3" />
              <span className="font-mono text-[10px] uppercase tracking-widest">Total Fees Collected</span>
            </div>
            <div className="text-3xl font-bold tracking-tight">
              ${pools.reduce((acc, p) => acc + (p.totalFees || 0), 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
          </div>
          <div className="border border-[#141414] p-6 bg-white/50">
            <div className="flex items-center gap-2 opacity-50 mb-2">
              <TrendingUp className="w-3 h-3" />
              <span className="font-mono text-[10px] uppercase tracking-widest">Avg. APR</span>
            </div>
            <div className="text-3xl font-bold tracking-tight text-emerald-600">
              {(pools.reduce((acc, p) => acc + (p.aprSinceStart || 0), 0) / (pools.length || 1)).toFixed(2)}%
            </div>
          </div>
        </div>
      )}

      <CategorySection 
        key={`eth-${deltaPeriod}`}
        title="Ethereum Pools" 
        pools={ethPools} 
        onSelectPool={onSelectPool}
        bulkInputs={bulkInputs}
        onInputChange={handleInputChange}
        maxDeltaId={ethMaxDeltaId}
        maxAprId={ethMaxAprId}
        isAdmin={isAdmin}
        deltaPeriod={deltaPeriod}
        onDeltaPeriodChange={setDeltaPeriod}
        prices={prices}
        headerRight={
          <div className="font-mono text-xl uppercase tracking-[0.1em] text-emerald-600 font-bold">
            LAST UPDATE: {latestUpdate ? format(new Date(latestUpdate), "do MMMM, HH:mm") : 'N/A'}
          </div>
        }
      />
      <CategorySection 
        key={`btc-${deltaPeriod}`}
        title="Bitcoin Pools" 
        pools={btcPools} 
        onSelectPool={onSelectPool}
        bulkInputs={bulkInputs}
        onInputChange={handleInputChange}
        maxDeltaId={btcMaxDeltaId}
        maxAprId={btcMaxAprId}
        isAdmin={isAdmin}
        deltaPeriod={deltaPeriod}
        onDeltaPeriodChange={setDeltaPeriod}
        prices={prices}
      />
      <CategorySection 
        key={`avax-${deltaPeriod}`}
        title="Avalanche Pools" 
        pools={avaxPools} 
        onSelectPool={onSelectPool}
        bulkInputs={bulkInputs}
        onInputChange={handleInputChange}
        maxDeltaId={avaxMaxDeltaId}
        maxAprId={avaxMaxAprId}
        isAdmin={isAdmin}
        deltaPeriod={deltaPeriod}
        onDeltaPeriodChange={setDeltaPeriod}
        prices={prices}
      />
      {otherPools.length > 0 && (
        <CategorySection 
          key={`other-${deltaPeriod}`}
          title="Other Networks & Pairs" 
          pools={otherPools} 
          onSelectPool={onSelectPool}
          bulkInputs={bulkInputs}
          onInputChange={handleInputChange}
          maxDeltaId={otherMaxDeltaId}
          maxAprId={otherMaxAprId}
          isAdmin={isAdmin}
          deltaPeriod={deltaPeriod}
          onDeltaPeriodChange={setDeltaPeriod}
          prices={prices}
        />
      )}
    </div>
  );
}
