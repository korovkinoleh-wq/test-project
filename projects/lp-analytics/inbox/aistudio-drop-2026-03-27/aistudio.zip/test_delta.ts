import Database from "better-sqlite3";
const db = new Database("lp_analytics.db");

const poolId = 1;
const fees1 = 100;
const ts1 = new Date(Date.now() - 10000).toISOString();
const fees2 = 150;
const ts2 = new Date().toISOString();

console.log(`Adding snapshots for pool ${poolId}...`);

db.prepare(`
  INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
  VALUES (?, ?, ?)
`).run(poolId, fees1, ts1);

db.prepare(`
  INSERT INTO snapshots (pool_id, total_fees, snapshot_datetime)
  VALUES (?, ?, ?)
`).run(poolId, fees2, ts2);

// Recalculate deltas logic from server.ts
function calculatePoolDeltas(snapshots: any[]) {
  const getDelta = (offset: number) => {
    if (!snapshots || snapshots.length < 2) return 0;
    const latest = snapshots[0];
    const latestFees = typeof latest.total_fees === 'number' ? latest.total_fees : parseFloat(String(latest.total_fees).replace(',', '.'));
    let baselineIndex = Math.min(offset, snapshots.length - 1);
    let prev: any = snapshots[baselineIndex];
    let prevFees = prev ? (typeof prev.total_fees === 'number' ? prev.total_fees : parseFloat(String(prev.total_fees).replace(',', '.'))) : 0;
    while (baselineIndex < snapshots.length - 1 && (isNaN(prevFees) || prevFees <= 0)) {
      baselineIndex++;
      prev = snapshots[baselineIndex];
      prevFees = prev ? (typeof prev.total_fees === 'number' ? prev.total_fees : parseFloat(String(prev.total_fees).replace(',', '.'))) : 0;
    }
    if (!isNaN(prevFees) && !isNaN(latestFees)) {
      if (prevFees === 0) {
        return latestFees > 0 ? 100 : 0;
      }
      const d = ((latestFees - prevFees) / prevFees) * 100;
      return isFinite(d) ? d : 0;
    }
    return 0;
  };
  return {
    delta_1: getDelta(1),
    delta_3: getDelta(3),
    delta_7: getDelta(7)
  };
}

const snapshots = db.prepare("SELECT * FROM snapshots WHERE pool_id = ? ORDER BY snapshot_datetime DESC, id DESC").all(poolId);
console.log(`Snapshots found: ${snapshots.length}`);
const deltas = calculatePoolDeltas(snapshots);
console.log(`Calculated Deltas:`, deltas);

db.prepare(`
  UPDATE pools 
  SET latest_total_fees = ?, 
      latest_snapshot_datetime = ?,
      delta_1 = ?,
      delta_3 = ?,
      delta_7 = ?
  WHERE id = ?
`).run(fees2, ts2, deltas.delta_1, deltas.delta_3, deltas.delta_7, poolId);

console.log("Pool updated.");

const pool = db.prepare("SELECT * FROM pools WHERE id = ?").get(poolId);
console.log("Updated Pool:", JSON.stringify(pool, null, 2));
