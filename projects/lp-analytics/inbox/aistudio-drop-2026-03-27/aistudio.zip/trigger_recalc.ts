import jwt from 'jsonwebtoken';

const JWT_SECRET = "lp-analytics-secret-key-2026";
const token = jwt.sign(
  { 
    id: "EBWPiMfNuZZACirKwPn2Jw7cp6F2", 
    email: "olegglasstrader@gmail.com", 
    role: "admin" 
  }, 
  JWT_SECRET, 
  { expiresIn: '1h' }
);

async function callRecalculate() {
  const response = await fetch('http://localhost:3000/api/admin/recalculate-deltas', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  const data = await response.json();
  console.log('Recalculate Response:', data);
}

callRecalculate();
