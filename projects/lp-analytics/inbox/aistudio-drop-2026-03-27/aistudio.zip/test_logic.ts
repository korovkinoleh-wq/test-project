
function getField(obj: any, keys: string[]): any {
  if (!obj || typeof obj !== 'object') return undefined;
  
  // Try direct keys first
  for (const key of keys) {
    if (obj[key] !== undefined && obj[key] !== null) {
      const val = obj[key];
      if (val && typeof val === 'object' && !Array.isArray(val)) {
        if (val.stringValue !== undefined) return val.stringValue;
        if (val.doubleValue !== undefined) return parseFloat(val.doubleValue);
        if (val.integerValue !== undefined) return parseInt(val.integerValue);
        if (val.timestampValue !== undefined) return val.timestampValue;
        if (val.booleanValue !== undefined) return val.booleanValue;
      }
      return val;
    }
  }

  // Try inside 'fields', 'data', '_data', 'value'
  const wrappers = ['fields', 'data', '_data', 'value'];
  for (const wrapper of wrappers) {
    if (obj[wrapper] && typeof obj[wrapper] === 'object') {
      const result = getField(obj[wrapper], keys);
      if (result !== undefined) return result;
    }
  }

  // Try case-insensitive
  const objKeys = Object.keys(obj);
  for (const key of keys) {
    const match = objKeys.find(k => k.toLowerCase() === key.toLowerCase());
    if (match) {
      const val = obj[match];
      if (val && typeof val === 'object' && !Array.isArray(val)) {
        if (val.stringValue !== undefined) return val.stringValue;
        if (val.doubleValue !== undefined) return parseFloat(val.doubleValue);
        if (val.integerValue !== undefined) return parseInt(val.integerValue);
      }
      return val;
    }
  }

  return undefined;
}

const parseNum = (val: any): number => {
  if (val === null || val === undefined) return 0;
  if (typeof val === 'number') return val;
  if (typeof val === 'string') {
    let cleaned = val.replace(/[^\d.,-]/g, '');
    if (cleaned.includes(',') && cleaned.includes('.')) {
      if (cleaned.lastIndexOf(',') > cleaned.lastIndexOf('.')) {
        cleaned = cleaned.replace(/\./g, '').replace(',', '.');
      } else {
        cleaned = cleaned.replace(/,/g, '');
      }
    } else if (cleaned.includes(',')) {
      const parts = cleaned.split(',');
      if (parts[1] && parts[1].length === 3) {
        cleaned = cleaned.replace(/,/g, '');
      } else {
        cleaned = cleaned.replace(',', '.');
      }
    }
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  }
  if (typeof val === 'object') {
    const inner = getField(val, ['value', 'amount', 'integerValue', 'doubleValue', 'numberValue', 'stringValue']);
    if (inner !== undefined && inner !== val) return parseNum(inner);
    for (const key in val) {
      if (typeof val[key] === 'number') return val[key];
      if (typeof val[key] === 'string' && !isNaN(parseFloat(val[key]))) return parseFloat(val[key]);
    }
  }
  return 0;
};

// Test cases
const testData = [
  {
    name: "Firestore style",
    data: { fields: { total_fees: { doubleValue: 123.45 } } },
    expected: 123.45
  },
  {
    name: "Nested data",
    data: { data: { fees: "1,234.56" } },
    expected: 1234.56
  },
  {
    name: "Direct",
    data: { total_fees: 50 },
    expected: 50
  }
];

for (const test of testData) {
  const val = getField(test.data, ['total_fees', 'fees']);
  const num = parseNum(val);
  console.log(`${test.name}: expected ${test.expected}, got ${num} (${num === test.expected ? 'PASS' : 'FAIL'})`);
}
