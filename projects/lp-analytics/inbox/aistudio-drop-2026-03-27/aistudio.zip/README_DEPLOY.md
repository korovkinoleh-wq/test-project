# Руководство по развертыванию в Google Cloud

Это приложение готово к развертыванию в **Google Cloud Run**.

## 1. Подготовка Google Cloud
1. Перейдите в [Google Cloud Console](https://console.cloud.google.com/).
2. Создайте новый проект.
3. Включите API: **Cloud Run**, **Artifact Registry**, **Cloud Build**.
4. Создайте учетные данные OAuth 2.0 в разделе **APIs & Services > Credentials**:
   - Тип: Web Application.
   - Authorized Redirect URIs: `https://your-domain.com/auth/callback` (замените на ваш домен).
   - Сохраните `Client ID` и `Client Secret`.

## 2. Установка инструментов
Установите [Google Cloud CLI](https://cloud.google.com/sdk/docs/install) на ваш компьютер.

## 3. Развертывание (через терминал)
Выполните следующие команды в папке с проектом:

```bash
# Авторизация
gcloud auth login

# Установка проекта
gcloud config set project [PROJECT_ID]

# Сборка и деплой (одной командой)
gcloud run deploy lp-analytics \
  --source . \
  --platform managed \
  --region europe-west2 \
  --allow-unauthenticated \
  --port 3000 \
  --set-env-vars="VITE_GOOGLE_CLIENT_ID=ваш_id,GOOGLE_CLIENT_SECRET=ваш_secret,JWT_SECRET=любая_длинная_строка,APP_URL=https://ваш-домен.com"
```

## 4. Настройка своего домена
1. В консоли Cloud Run выберите ваш сервис `lp-analytics`.
2. Нажмите **Manage Custom Domains**.
3. Следуйте инструкциям для подтверждения владения доменом и обновления DNS-записей (A/AAAA или CNAME).

## 6. Автоматическое обновление (CI/CD через GitHub)
Чтобы не вводить команды каждый раз, настройте авто-деплой:
1. Создайте репозиторий на GitHub и загрузите туда код.
2. В консоли Google Cloud Run выберите ваш сервис `lp-analytics`.
3. Нажмите **SET UP CONTINUOUS DEPLOYMENT**.
4. Выберите GitHub в качестве источника и укажите ваш репозиторий.
5. Выберите ветку (обычно `main`).
6. Теперь при каждом `git push` ваш сайт будет обновляться автоматически!

## 7. Локальный запуск для разработки
1. Установите Node.js (версия 20+).
2. В папке проекта: `npm install`.
3. Создайте файл `.env` на основе `.env.example` и заполните ключи.
4. Запуск: `npm run dev`.
5. Сайт будет доступен по адресу `http://localhost:3000`.
