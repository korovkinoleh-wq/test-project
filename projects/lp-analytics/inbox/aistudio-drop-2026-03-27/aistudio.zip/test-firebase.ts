import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function test() {
  console.log("Starting Firebase Admin SDK test...");
  
  let firebaseConfig: any = {};
  try {
    const configPath = path.join(__dirname, "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
      firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
      console.log("Loaded config:", JSON.stringify(firebaseConfig, null, 2));
    }
  } catch (e) {
    console.error("Config load failed:", e);
  }

  const projectId = firebaseConfig.projectId;
  const dbId = firebaseConfig.firestoreDatabaseId;

  process.env.GOOGLE_CLOUD_PROJECT = projectId;
  process.env.GCLOUD_PROJECT = projectId;

  console.log(`Project ID: ${projectId}`);
  console.log(`Database ID: ${dbId}`);

  try {
    const app = admin.initializeApp({
      projectId: projectId
    }, "test-app-" + Date.now());
    
    console.log("Admin SDK initialized.");
    
    const db = getFirestore(app, dbId);
    console.log("Firestore instance obtained.");
    
    const healthRef = db.collection('_health').doc('test');
    console.log("Attempting write to _health/test...");
    
    await healthRef.set({ 
      timestamp: new Date().toISOString(),
      test: true
    });
    
    console.log("Write SUCCESSFUL!");
    
    const doc = await healthRef.get();
    console.log("Read SUCCESSFUL:", doc.data());
    
    await healthRef.delete();
    console.log("Delete SUCCESSFUL!");
    
  } catch (err: any) {
    console.error("TEST FAILED:", err);
    if (err.stack) console.error(err.stack);
  }
}

test();
