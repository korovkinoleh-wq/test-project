import Database from "better-sqlite3";
try {
  const db = new Database("lp_analytics.db");
  const count = db.prepare("SELECT COUNT(*) as count FROM pools").get() as any;
  console.log("Database connection successful. Pool count:", count.count);
  db.close();
} catch (err) {
  console.error("Database connection failed:", err);
}
